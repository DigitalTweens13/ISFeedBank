"""Контракты между компонентами брокера.

Компоненты не импортируют друг друга: обработчик соединений знает только
протоколы ``MessageRouter`` и ``MessageQueue``, маршрутизатор — только
``MessageQueue``. Конкретные объекты подставляются при сборке
(см. ``message_broker.assembly``).
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from .message import Delivery, Message


@runtime_checkable
class MessageQueue(Protocol):
    """Очередь, в которую маршрутизатор кладёт сообщения (связи 4, 9),
    а обработчик соединений извлекает их для потребителей (связи 6, 11)."""

    @property
    def name(self) -> str: ...

    def put(self, message: Message) -> None: ...

    def get(self) -> Delivery | None: ...

    def ack(self, delivery_tag: int) -> None: ...

    def nack(self, delivery_tag: int, requeue: bool = True) -> None: ...

    def __len__(self) -> int: ...


@runtime_checkable
class MessageRouter(Protocol):
    """Маршрутизатор, которому обработчик соединений передаёт
    опубликованные сообщения (связи 3, 8)."""

    def route(self, message: Message) -> list[str]:
        """Помещает сообщение в очереди и возвращает их имена."""
        ...
