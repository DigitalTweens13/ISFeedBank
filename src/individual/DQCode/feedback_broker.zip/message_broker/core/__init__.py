"""Ядро брокера: модель сообщений, контракты, исключения и базовая очередь.

Это единственная общая зависимость компонентов; друг друга компоненты
не импортируют.
"""

from .base_queue import BaseQueue, DeadLetter, QueueStats
from .errors import (
    AccessDeniedError,
    AuthenticationError,
    BrokerError,
    ConnectionClosedError,
    ConnectionLimitError,
    ExchangeConflictError,
    ExchangeNotFoundError,
    MessageValidationError,
    QueueNotFoundError,
    QueueOverflowError,
    UnknownDeliveryTagError,
    UnroutableMessageError,
)
from .interfaces import MessageQueue, MessageRouter
from .message import Delivery, Message
from .queue_strategies import (
    AcceptAllValidation,
    DropHeadOverflow,
    FifoStorage,
    MessagePriorityPolicy,
    OverflowStrategy,
    PriorityPolicy,
    PriorityStorage,
    RejectPublishOverflow,
    RequiredFieldsValidation,
    StorageStrategy,
    ValidationStrategy,
)
