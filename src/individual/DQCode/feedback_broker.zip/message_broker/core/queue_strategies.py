"""Абстрактные стратегии очередей и их универсальные реализации.

Паттерн «Стратегия»: очередь (контекст) делегирует три вида решений
сменяемым объектам-стратегиям:

* ``StorageStrategy``   — в каком порядке хранить и выдавать сообщения;
* ``OverflowStrategy``  — что делать, когда очередь заполнена;
* ``ValidationStrategy``— какие сообщения очередь вообще принимает.

Порядок выдачи внутри ``PriorityStorage`` дополнительно задаётся
стратегией ``PriorityPolicy``. Предметные стратегии (приоритет негативных
отзывов, схема события «обращение создано» и т. п.) реализованы
в модулях конкретных очередей.
"""

from __future__ import annotations

import heapq
import itertools
from abc import ABC, abstractmethod
from collections import deque
from typing import Any, Mapping

from .errors import MessageValidationError, QueueOverflowError
from .message import Message


# --------------------------------------------------------------------------
# Приоритет сообщений
# --------------------------------------------------------------------------
class PriorityPolicy(ABC):
    """Стратегия вычисления приоритета: чем больше число, тем раньше выдача."""

    @abstractmethod
    def priority_of(self, message: Message) -> int:
        ...


class MessagePriorityPolicy(PriorityPolicy):
    """Берёт приоритет из свойства ``priority``, заданного публикатором."""

    def priority_of(self, message: Message) -> int:
        return message.priority


# --------------------------------------------------------------------------
# Хранение
# --------------------------------------------------------------------------
class StorageStrategy(ABC):
    """Стратегия хранения сообщений, готовых к выдаче."""

    @abstractmethod
    def push(self, message: Message) -> None:
        """Добавляет новое сообщение."""

    @abstractmethod
    def push_front(self, message: Message) -> None:
        """Возвращает сообщение в голову очереди (повторная доставка)."""

    @abstractmethod
    def pop(self) -> Message | None:
        """Извлекает следующее сообщение или ``None``, если очередь пуста."""

    @abstractmethod
    def evict(self) -> Message | None:
        """Удаляет наименее ценное сообщение, чтобы освободить место."""

    @abstractmethod
    def drain(self) -> list[Message]:
        """Извлекает все сообщения в порядке выдачи (для смены стратегии)."""

    @abstractmethod
    def __len__(self) -> int:
        ...


class FifoStorage(StorageStrategy):
    """Строгий порядок поступления. Вытесняется самое старое сообщение."""

    def __init__(self) -> None:
        self._items: deque[Message] = deque()

    def push(self, message: Message) -> None:
        self._items.append(message)

    def push_front(self, message: Message) -> None:
        self._items.appendleft(message)

    def pop(self) -> Message | None:
        return self._items.popleft() if self._items else None

    def evict(self) -> Message | None:
        return self._items.popleft() if self._items else None

    def drain(self) -> list[Message]:
        items = list(self._items)
        self._items.clear()
        return items

    def __len__(self) -> int:
        return len(self._items)


class PriorityStorage(StorageStrategy):
    """Выдача по приоритету, при равном приоритете — в порядке поступления.

    Приоритет вычисляет подключаемая ``PriorityPolicy``.
    Вытесняется сообщение с наименьшим приоритетом.
    """

    def __init__(self, policy: PriorityPolicy | None = None) -> None:
        self._policy = policy or MessagePriorityPolicy()
        self._heap: list[tuple[int, int, Message]] = []
        self._seq = itertools.count()
        self._front_seq = itertools.count(-1, -1)

    @property
    def policy(self) -> PriorityPolicy:
        return self._policy

    def push(self, message: Message) -> None:
        heapq.heappush(self._heap, (-self._policy.priority_of(message), next(self._seq), message))

    def push_front(self, message: Message) -> None:
        heapq.heappush(self._heap, (-self._policy.priority_of(message), next(self._front_seq), message))

    def pop(self) -> Message | None:
        return heapq.heappop(self._heap)[2] if self._heap else None

    def evict(self) -> Message | None:
        if not self._heap:
            return None
        worst = max(range(len(self._heap)), key=lambda i: self._heap[i][:2])
        _, _, message = self._heap.pop(worst)
        heapq.heapify(self._heap)
        return message

    def drain(self) -> list[Message]:
        items = [entry[2] for entry in sorted(self._heap, key=lambda e: e[:2])]
        self._heap.clear()
        return items

    def __len__(self) -> int:
        return len(self._heap)


# --------------------------------------------------------------------------
# Переполнение
# --------------------------------------------------------------------------
class OverflowStrategy(ABC):
    """Стратегия поведения заполненной очереди.

    ``amqp_overflow`` — значение аргумента ``x-overflow`` для настоящего
    RabbitMQ: так одна и та же стратегия задаёт поведение и модели
    в памяти, и очереди на сервере.
    """

    amqp_overflow: str | None = None

    @abstractmethod
    def make_room(self, queue_name: str, storage: StorageStrategy, incoming: Message) -> list[Message]:
        """Освобождает место для ``incoming`` или запрещает приём исключением.

        Возвращает вытесненные сообщения — очередь отправит их в dead letter.
        """


class RejectPublishOverflow(OverflowStrategy):
    """Аналог ``x-overflow=reject-publish``: новое сообщение отклоняется,
    публикатор получает ошибку и может повторить попытку позже."""

    amqp_overflow = "reject-publish"

    def make_room(self, queue_name: str, storage: StorageStrategy, incoming: Message) -> list[Message]:
        raise QueueOverflowError(
            f"Очередь {queue_name} заполнена ({len(storage)} сообщ.), публикация отклонена"
        )


class DropHeadOverflow(OverflowStrategy):
    """Аналог ``x-overflow=drop-head``: вытесняется наименее ценное
    сообщение, новое принимается."""

    amqp_overflow = "drop-head"

    def make_room(self, queue_name: str, storage: StorageStrategy, incoming: Message) -> list[Message]:
        evicted = storage.evict()
        return [evicted] if evicted is not None else []


# --------------------------------------------------------------------------
# Валидация
# --------------------------------------------------------------------------
class ValidationStrategy(ABC):
    """Стратегия проверки сообщения перед постановкой в очередь."""

    @abstractmethod
    def validate(self, message: Message) -> None:
        """Ничего не возвращает; при ошибке бросает ``MessageValidationError``."""


class AcceptAllValidation(ValidationStrategy):
    """Принимает любое сообщение (например, для отладки)."""

    def validate(self, message: Message) -> None:
        return None


class RequiredFieldsValidation(ValidationStrategy):
    """Проверяет наличие и тип обязательных полей тела сообщения.

    Базовый класс для предметных схем очередей.
    """

    def __init__(self, required: Mapping[str, type | tuple[type, ...]]) -> None:
        self._required = dict(required)

    def validate(self, message: Message) -> None:
        body = message.body
        if not isinstance(body, Mapping):
            raise MessageValidationError("Тело сообщения должно быть словарём")
        for field_name, expected in self._required.items():
            if field_name not in body:
                raise MessageValidationError(f"Не заполнено обязательное поле «{field_name}»")
            if not isinstance(body[field_name], expected):
                raise MessageValidationError(
                    f"Поле «{field_name}» имеет тип {type(body[field_name]).__name__}, "
                    f"ожидался {_type_name(expected)}"
                )
        self.validate_extra(body)

    def validate_extra(self, body: Mapping[str, Any]) -> None:
        """Дополнительные проверки в наследниках."""


def _type_name(expected: type | tuple[type, ...]) -> str:
    if isinstance(expected, tuple):
        return " | ".join(t.__name__ for t in expected)
    return expected.__name__
