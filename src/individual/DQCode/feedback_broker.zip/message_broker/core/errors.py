"""Иерархия исключений брокера сообщений.

Общие для всех компонентов исключения вынесены в ядро, чтобы компоненты
могли сообщать об ошибках, не импортируя друг друга.
"""


class BrokerError(Exception):
    """Базовая ошибка брокера сообщений."""


class AuthenticationError(BrokerError):
    """Клиент не прошёл аутентификацию при открытии AMQP-соединения."""


class AccessDeniedError(BrokerError):
    """У клиента нет прав на публикацию или чтение указанного ресурса."""


class ConnectionClosedError(BrokerError):
    """Операция выполняется на закрытом соединении или канале."""


class ConnectionLimitError(BrokerError):
    """Превышено допустимое число одновременных соединений."""


class ExchangeNotFoundError(BrokerError):
    """Обмен (exchange) с указанным именем не объявлен."""


class ExchangeConflictError(BrokerError):
    """Обмен уже объявлен с другим типом маршрутизации."""


class UnroutableMessageError(BrokerError):
    """Сообщение не удалось направить ни в одну очередь."""


class QueueNotFoundError(BrokerError):
    """Очередь с указанным именем не зарегистрирована."""


class QueueOverflowError(BrokerError):
    """Очередь заполнена, и стратегия переполнения запрещает приём."""


class MessageValidationError(BrokerError):
    """Сообщение не соответствует формату, который принимает очередь."""


class UnknownDeliveryTagError(BrokerError):
    """Подтверждение (ack/nack) для неизвестного или уже подтверждённого тега."""
