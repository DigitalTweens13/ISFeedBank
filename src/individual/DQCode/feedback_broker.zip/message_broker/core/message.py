"""Модель данных, которой обмениваются компоненты брокера."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from typing import Any, Mapping


@dataclass(frozen=True)
class Message:
    """Сообщение AMQP: тело, ключ маршрутизации и свойства.

    Объект неизменяемый: при повторной доставке создаётся копия
    с увеличенным счётчиком доставок.
    """

    body: Mapping[str, Any]
    routing_key: str
    exchange: str = ""
    priority: int = 0
    headers: Mapping[str, Any] = field(default_factory=dict)
    publisher_id: str = ""
    message_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    delivery_count: int = 0

    @property
    def redelivered(self) -> bool:
        """Сообщение уже выдавалось потребителю и было возвращено в очередь."""
        return self.delivery_count > 0

    def as_redelivered(self) -> "Message":
        """Копия сообщения для повторной постановки в очередь."""
        return replace(self, delivery_count=self.delivery_count + 1)


@dataclass(frozen=True)
class Delivery:
    """Выданное потребителю сообщение, ожидающее подтверждения.

    ``delivery_tag`` уникален в пределах выдавшего его объекта
    (очереди или канала) и используется для ack/nack.
    """

    delivery_tag: int
    queue: str
    message: Message

    @property
    def body(self) -> Mapping[str, Any]:
        return self.message.body

    @property
    def redelivered(self) -> bool:
        return self.message.redelivered
