"""Базовый класс очереди — контекст паттерна «Стратегия».

Реализует общую для обеих очередей механику AMQP-очереди: выдачу
с ожиданием подтверждения, ack/nack, возврат в очередь, dead letter
и статистику. Решения о порядке хранения, переполнении и допустимом
формате сообщений делегируются сменяемым стратегиям.
"""

from __future__ import annotations

import itertools
import logging
import threading
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone

from .errors import UnknownDeliveryTagError
from .message import Delivery, Message
from .queue_strategies import OverflowStrategy, StorageStrategy, ValidationStrategy

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class DeadLetter:
    """Сообщение, исключённое из очереди без обработки."""

    message: Message
    reason: str
    queue: str
    at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass(frozen=True)
class QueueStats:
    """Снимок состояния очереди."""

    name: str
    ready: int
    unacked: int
    published: int
    delivered: int
    acked: int
    requeued: int
    dead_lettered: int


class BaseQueue:
    """Очередь сообщений со сменяемыми стратегиями. Потокобезопасна."""

    def __init__(
        self,
        name: str,
        *,
        storage: StorageStrategy,
        overflow: OverflowStrategy,
        validation: ValidationStrategy,
        max_length: int | None = None,
        dead_letter_limit: int = 1000,
    ) -> None:
        if not name:
            raise ValueError("Имя очереди не может быть пустым")
        if max_length is not None and max_length <= 0:
            raise ValueError("max_length должен быть положительным")
        self._name = name
        self._storage = storage
        self._overflow = overflow
        self._validation = validation
        self._max_length = max_length
        self._lock = threading.RLock()
        self._tags = itertools.count(1)
        self._unacked: dict[int, Message] = {}
        self._dead_letters: deque[DeadLetter] = deque(maxlen=dead_letter_limit)
        self._published = self._delivered = self._acked = self._requeued = self._dead = 0

    # ------------------------------------------------------------------
    # Свойства
    # ------------------------------------------------------------------
    @property
    def name(self) -> str:
        return self._name

    @property
    def max_length(self) -> int | None:
        return self._max_length

    @property
    def storage_strategy(self) -> StorageStrategy:
        return self._storage

    @property
    def overflow_strategy(self) -> OverflowStrategy:
        return self._overflow

    @property
    def validation_strategy(self) -> ValidationStrategy:
        return self._validation

    # ------------------------------------------------------------------
    # Смена стратегий во время работы
    # ------------------------------------------------------------------
    def set_storage_strategy(self, storage: StorageStrategy) -> None:
        """Меняет порядок выдачи; накопленные сообщения переносятся."""
        with self._lock:
            for message in self._storage.drain():
                storage.push(message)
            self._storage = storage
        logger.info("Очередь %s: стратегия хранения -> %s", self._name, type(storage).__name__)

    def set_overflow_strategy(self, overflow: OverflowStrategy) -> None:
        with self._lock:
            self._overflow = overflow
        logger.info("Очередь %s: стратегия переполнения -> %s", self._name, type(overflow).__name__)

    def set_validation_strategy(self, validation: ValidationStrategy) -> None:
        with self._lock:
            self._validation = validation
        logger.info("Очередь %s: стратегия валидации -> %s", self._name, type(validation).__name__)

    def set_max_length(self, max_length: int | None) -> None:
        if max_length is not None and max_length <= 0:
            raise ValueError("max_length должен быть положительным")
        with self._lock:
            self._max_length = max_length

    # ------------------------------------------------------------------
    # Операции очереди (протокол MessageQueue)
    # ------------------------------------------------------------------
    def put(self, message: Message) -> None:
        """Принимает сообщение от маршрутизатора."""
        with self._lock:
            self._validation.validate(message)
            if self._max_length is not None and len(self._storage) >= self._max_length:
                for evicted in self._overflow.make_room(self._name, self._storage, message):
                    self._to_dead_letter(evicted, "overflow")
            self._storage.push(message)
            self._published += 1
        logger.debug("Очередь %s: принято сообщение %s", self._name, message.message_id)

    def get(self) -> Delivery | None:
        """Выдаёт следующее сообщение; до ack оно остаётся неподтверждённым."""
        with self._lock:
            message = self._storage.pop()
            if message is None:
                return None
            tag = next(self._tags)
            self._unacked[tag] = message
            self._delivered += 1
            return Delivery(delivery_tag=tag, queue=self._name, message=message)

    def ack(self, delivery_tag: int) -> None:
        """Подтверждает обработку — сообщение удаляется окончательно."""
        with self._lock:
            if self._unacked.pop(delivery_tag, None) is None:
                raise UnknownDeliveryTagError(f"{self._name}: неизвестный тег доставки {delivery_tag}")
            self._acked += 1

    def nack(self, delivery_tag: int, requeue: bool = True) -> None:
        """Отказ от сообщения: вернуть в голову очереди или в dead letter."""
        with self._lock:
            message = self._unacked.pop(delivery_tag, None)
            if message is None:
                raise UnknownDeliveryTagError(f"{self._name}: неизвестный тег доставки {delivery_tag}")
            if requeue:
                self._storage.push_front(message.as_redelivered())
                self._requeued += 1
            else:
                self._to_dead_letter(message, "rejected")

    def purge(self) -> int:
        """Удаляет все готовые к выдаче сообщения, возвращает их число."""
        with self._lock:
            return len(self._storage.drain())

    # ------------------------------------------------------------------
    # Наблюдение
    # ------------------------------------------------------------------
    def __len__(self) -> int:
        with self._lock:
            return len(self._storage)

    @property
    def unacked_count(self) -> int:
        with self._lock:
            return len(self._unacked)

    def dead_letters(self) -> tuple[DeadLetter, ...]:
        with self._lock:
            return tuple(self._dead_letters)

    def stats(self) -> QueueStats:
        with self._lock:
            return QueueStats(
                name=self._name,
                ready=len(self._storage),
                unacked=len(self._unacked),
                published=self._published,
                delivered=self._delivered,
                acked=self._acked,
                requeued=self._requeued,
                dead_lettered=self._dead,
            )

    def __repr__(self) -> str:
        return f"{type(self).__name__}(name={self._name!r}, ready={len(self)}, unacked={self.unacked_count})"

    # ------------------------------------------------------------------
    def _to_dead_letter(self, message: Message, reason: str) -> None:
        self._dead_letters.append(DeadLetter(message=message, reason=reason, queue=self._name))
        self._dead += 1
        logger.warning("Очередь %s: сообщение %s -> dead letter (%s)", self._name, message.message_id, reason)
