"""Компонент connection_handler — обработчик AMQP-соединений.

Принимает AMQP-сессии всех трёх внешних контейнеров (связи 1, 2, 5, 7, 10),
передаёт опубликованные сообщения маршрутизатору (связи 3, 8) и выдаёт
потребителям сообщения из очередей (связи 6, 11).

API каналов повторяет имена методов ``pika`` (``basic_publish``,
``basic_get``, ``basic_consume``, ``basic_ack``, ``basic_nack``,
``basic_qos``), поэтому код воркеров переносится на настоящий RabbitMQ
с минимальными правками.

Стратегии (меняются во время работы):

* ``AuthenticationStrategy`` — проверка клиента при подключении:
  ``AnonymousAuthentication``, ``SharedSecretAuthentication``;
* ``AccessPolicy`` — кто что может публиковать и читать:
  ``PermitAllPolicy``, ``PermissionTablePolicy``;
* ``AcknowledgementStrategy`` — когда подтверждать доставку:
  ``AckAfterProcessing`` (по умолчанию, как в отчёте — ack после
  обработки, при сбое — возврат в очередь), ``AutoAck``, ``ManualAck``.

Модуль зависит только от ``message_broker.core``; маршрутизатор
и очереди он знает через протоколы ``MessageRouter`` и ``MessageQueue``.
"""

from __future__ import annotations

import fnmatch
import hashlib
import hmac
import itertools
import logging
import threading
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Mapping

from .core import (
    AccessDeniedError,
    AuthenticationError,
    ConnectionClosedError,
    ConnectionLimitError,
    Delivery,
    Message,
    MessageQueue,
    MessageRouter,
    QueueNotFoundError,
    UnknownDeliveryTagError,
)

logger = logging.getLogger(__name__)


# --------------------------------------------------------------------------
# Аутентификация
# --------------------------------------------------------------------------
@dataclass(frozen=True)
class Credentials:
    """Учётные данные клиента (контейнера) при открытии соединения."""

    client_id: str
    secret: str | None = field(default=None, repr=False)


@dataclass(frozen=True)
class ClientIdentity:
    """Удостоверенный клиент, от имени которого работает соединение."""

    client_id: str
    authenticated_by: str


class AuthenticationStrategy(ABC):
    """Стратегия проверки клиента при подключении."""

    @abstractmethod
    def authenticate(self, credentials: Credentials) -> ClientIdentity:
        """Возвращает удостоверение или бросает ``AuthenticationError``."""


class AnonymousAuthentication(AuthenticationStrategy):
    """Пускает любого клиента с непустым идентификатором (разработка, тесты)."""

    def authenticate(self, credentials: Credentials) -> ClientIdentity:
        if not credentials.client_id:
            raise AuthenticationError("Не указан идентификатор клиента")
        return ClientIdentity(credentials.client_id, "anonymous")


class SharedSecretAuthentication(AuthenticationStrategy):
    """Проверка по секрету, выданному каждому контейнеру.

    Секреты хранятся только в виде хэшей SHA-256, сравнение —
    за постоянное время.
    """

    def __init__(self, secrets: Mapping[str, str]) -> None:
        self._hashes = {client: self._hash(secret) for client, secret in secrets.items()}

    @staticmethod
    def _hash(secret: str) -> bytes:
        return hashlib.sha256(secret.encode("utf-8")).digest()

    def authenticate(self, credentials: Credentials) -> ClientIdentity:
        expected = self._hashes.get(credentials.client_id)
        if expected is None or credentials.secret is None:
            raise AuthenticationError(f"Клиент «{credentials.client_id}» не прошёл аутентификацию")
        if not hmac.compare_digest(expected, self._hash(credentials.secret)):
            raise AuthenticationError(f"Клиент «{credentials.client_id}» не прошёл аутентификацию")
        return ClientIdentity(credentials.client_id, "shared_secret")


# --------------------------------------------------------------------------
# Авторизация
# --------------------------------------------------------------------------
@dataclass(frozen=True)
class Permissions:
    """Права клиента: шаблоны ключей для публикации и имён очередей для чтения.

    Шаблоны в стиле ``fnmatch``: ``"*"`` — всё, ``"cases.*"`` — по префиксу.
    """

    publish: frozenset[str] = frozenset()
    consume: frozenset[str] = frozenset()

    @classmethod
    def of(cls, *, publish: Iterable[str] = (), consume: Iterable[str] = ()) -> "Permissions":
        return cls(frozenset(publish), frozenset(consume))


class AccessPolicy(ABC):
    """Стратегия авторизации операций клиента."""

    @abstractmethod
    def can_publish(self, identity: ClientIdentity, exchange: str, routing_key: str) -> bool:
        ...

    @abstractmethod
    def can_consume(self, identity: ClientIdentity, queue: str) -> bool:
        ...


class PermitAllPolicy(AccessPolicy):
    """Разрешает всё (разработка, тесты)."""

    def can_publish(self, identity: ClientIdentity, exchange: str, routing_key: str) -> bool:
        return True

    def can_consume(self, identity: ClientIdentity, queue: str) -> bool:
        return True


class PermissionTablePolicy(AccessPolicy):
    """Права по таблице «клиент → Permissions». Чего нет в таблице — запрещено."""

    def __init__(self, table: Mapping[str, Permissions]) -> None:
        self._table = dict(table)

    def can_publish(self, identity: ClientIdentity, exchange: str, routing_key: str) -> bool:
        perms = self._table.get(identity.client_id)
        return perms is not None and _matches_any(routing_key, perms.publish)

    def can_consume(self, identity: ClientIdentity, queue: str) -> bool:
        perms = self._table.get(identity.client_id)
        return perms is not None and _matches_any(queue, perms.consume)


def _matches_any(value: str, patterns: Iterable[str]) -> bool:
    return any(fnmatch.fnmatchcase(value, pattern) for pattern in patterns)


# --------------------------------------------------------------------------
# Подтверждение доставки
# --------------------------------------------------------------------------
class AcknowledgementStrategy(ABC):
    """Стратегия подтверждения сообщений, выданных подписчикам ``basic_consume``.

    Канал вызывает хуки в порядке: ``on_delivered`` → обработчик
    потребителя → ``on_processed`` либо ``on_failed``.
    """

    def on_delivered(self, channel: "AmqpChannel", delivery: Delivery) -> None:
        """До вызова обработчика."""

    def on_processed(self, channel: "AmqpChannel", delivery: Delivery) -> None:
        """Обработчик завершился успешно."""

    def on_failed(self, channel: "AmqpChannel", delivery: Delivery, error: Exception) -> None:
        """Обработчик бросил исключение."""


class AckAfterProcessing(AcknowledgementStrategy):
    """Подтверждение только после успешной обработки (at-least-once).

    При ошибке сообщение возвращается в очередь; после ``max_attempts``
    неудачных доставок отклоняется в dead letter, чтобы «ядовитое»
    сообщение не блокировало очередь.
    """

    def __init__(self, max_attempts: int = 3) -> None:
        if max_attempts < 1:
            raise ValueError("max_attempts должен быть не меньше 1")
        self._max_attempts = max_attempts

    def on_processed(self, channel: "AmqpChannel", delivery: Delivery) -> None:
        if channel.is_pending(delivery.delivery_tag):
            channel.basic_ack(delivery.delivery_tag)

    def on_failed(self, channel: "AmqpChannel", delivery: Delivery, error: Exception) -> None:
        if not channel.is_pending(delivery.delivery_tag):
            return
        attempts = delivery.message.delivery_count + 1
        requeue = attempts < self._max_attempts
        channel.basic_nack(delivery.delivery_tag, requeue=requeue)
        logger.warning(
            "Ошибка обработки %s (попытка %d/%d): %s — %s",
            delivery.message.message_id, attempts, self._max_attempts, error,
            "возврат в очередь" if requeue else "в dead letter",
        )


class AutoAck(AcknowledgementStrategy):
    """Подтверждение сразу при выдаче (at-most-once): быстрее,
    но при сбое обработчика сообщение теряется."""

    def on_delivered(self, channel: "AmqpChannel", delivery: Delivery) -> None:
        channel.basic_ack(delivery.delivery_tag)

    def on_failed(self, channel: "AmqpChannel", delivery: Delivery, error: Exception) -> None:
        logger.error("Сообщение %s потеряно (auto-ack): %s", delivery.message.message_id, error)


class ManualAck(AcknowledgementStrategy):
    """Подтверждает сам потребитель через ``basic_ack``/``basic_nack``.
    Неподтверждённые сообщения возвращаются в очередь при закрытии канала."""

    def on_failed(self, channel: "AmqpChannel", delivery: Delivery, error: Exception) -> None:
        logger.error("Ошибка обработки %s (ручное подтверждение): %s", delivery.message.message_id, error)


# --------------------------------------------------------------------------
# Канал и соединение
# --------------------------------------------------------------------------
OnMessage = Callable[["AmqpChannel", Delivery], None]


@dataclass
class _Consumer:
    tag: str
    queue: str
    callback: OnMessage
    ack_strategy: AcknowledgementStrategy | None


@dataclass(frozen=True)
class _Pending:
    queue: str
    queue_tag: int


class AmqpChannel:
    """Канал AMQP внутри соединения. Не создаётся напрямую — см.
    ``AmqpConnection.channel()``."""

    def __init__(self, connection: "AmqpConnection", number: int) -> None:
        self._connection = connection
        self._number = number
        self._lock = threading.RLock()
        self._open = True
        self._tags = itertools.count(1)
        self._consumer_tags = itertools.count(1)
        self._pending: dict[int, _Pending] = {}
        self._consumers: dict[str, _Consumer] = {}
        self._prefetch = 0

    # ------------------------------------------------------------------
    @property
    def number(self) -> int:
        return self._number

    @property
    def is_open(self) -> bool:
        return self._open and self._connection.is_open

    @property
    def unacked_count(self) -> int:
        with self._lock:
            return len(self._pending)

    def is_pending(self, delivery_tag: int) -> bool:
        with self._lock:
            return delivery_tag in self._pending

    def basic_qos(self, prefetch_count: int) -> None:
        """Ограничивает число неподтверждённых сообщений у подписчиков (0 — без лимита)."""
        if prefetch_count < 0:
            raise ValueError("prefetch_count не может быть отрицательным")
        self._ensure_open()
        with self._lock:
            self._prefetch = prefetch_count

    # ------------------------------------------------------------------
    # Публикация (связи 1, 2, 7)
    # ------------------------------------------------------------------
    def basic_publish(
        self,
        routing_key: str,
        body: Mapping[str, Any],
        *,
        exchange: str = "",
        priority: int = 0,
        headers: Mapping[str, Any] | None = None,
    ) -> list[str]:
        """Публикует сообщение. Возвращает очереди, в которые оно попало."""
        self._ensure_open()
        message = Message(
            body=dict(body),
            routing_key=routing_key,
            exchange=exchange,
            priority=priority,
            headers=dict(headers or {}),
            publisher_id=self._connection.identity.client_id,
        )
        return self._connection.handler._route_published(self._connection.identity, message)

    # ------------------------------------------------------------------
    # Получение (связи 5, 10)
    # ------------------------------------------------------------------
    def basic_get(self, queue: str, *, auto_ack: bool = False) -> Delivery | None:
        """Забирает одно сообщение из очереди или ``None``."""
        self._ensure_open()
        delivery = self._fetch(queue)
        if delivery is not None and auto_ack:
            self.basic_ack(delivery.delivery_tag)
        return delivery

    def basic_consume(
        self,
        queue: str,
        on_message: OnMessage,
        *,
        ack_strategy: AcknowledgementStrategy | None = None,
        consumer_tag: str | None = None,
    ) -> str:
        """Подписывает обработчик на очередь. Без ``ack_strategy`` используется
        стратегия обработчика соединений, действующая на момент доставки."""
        self._ensure_open()
        handler = self._connection.handler
        handler._check_consume(self._connection.identity, queue)
        with self._lock:
            tag = consumer_tag or f"ctag-{self._number}.{next(self._consumer_tags)}"
            if tag in self._consumers:
                raise ValueError(f"Подписчик {tag} уже существует")
            self._consumers[tag] = _Consumer(tag, queue, on_message, ack_strategy)
        return tag

    def basic_cancel(self, consumer_tag: str) -> None:
        with self._lock:
            self._consumers.pop(consumer_tag, None)

    def drain_events(self, max_messages: int | None = None) -> int:
        """Раздаёт накопленные сообщения подписчикам по кругу.

        Возвращает число обработанных сообщений. Останавливается, когда
        очереди пусты, исчерпан ``prefetch`` или достигнут ``max_messages``.
        """
        processed = 0
        while True:
            progressed = False
            with self._lock:
                consumers = list(self._consumers.values())
            for consumer in consumers:
                if max_messages is not None and processed >= max_messages:
                    return processed
                if not self.is_open:
                    return processed
                with self._lock:
                    if self._prefetch and len(self._pending) >= self._prefetch:
                        return processed
                delivery = self._fetch(consumer.queue)
                if delivery is None:
                    continue
                progressed = True
                processed += 1
                self._dispatch(consumer, delivery)
            if not progressed:
                return processed

    # ------------------------------------------------------------------
    # Подтверждения
    # ------------------------------------------------------------------
    def basic_ack(self, delivery_tag: int) -> None:
        pending = self._take_pending(delivery_tag)
        self._connection.handler._queue(pending.queue).ack(pending.queue_tag)

    def basic_nack(self, delivery_tag: int, *, requeue: bool = True) -> None:
        pending = self._take_pending(delivery_tag)
        self._connection.handler._queue(pending.queue).nack(pending.queue_tag, requeue=requeue)

    def basic_reject(self, delivery_tag: int, *, requeue: bool = True) -> None:
        self.basic_nack(delivery_tag, requeue=requeue)

    # ------------------------------------------------------------------
    def close(self) -> None:
        """Закрывает канал; неподтверждённые сообщения возвращаются в очереди."""
        with self._lock:
            if not self._open:
                return
            self._open = False
            pending = list(self._pending.items())
            self._pending.clear()
            self._consumers.clear()
        handler = self._connection.handler
        for _, item in pending:
            try:
                handler._queue(item.queue).nack(item.queue_tag, requeue=True)
            except (QueueNotFoundError, UnknownDeliveryTagError):  # очередь удалена
                logger.warning("Не удалось вернуть сообщение в %s при закрытии канала", item.queue)
        if pending:
            logger.info("Канал %d закрыт, возвращено в очереди: %d", self._number, len(pending))
        self._connection._forget_channel(self._number)

    def __enter__(self) -> "AmqpChannel":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # ------------------------------------------------------------------
    def _fetch(self, queue: str) -> Delivery | None:
        raw = self._connection.handler._fetch_for_consumer(self._connection.identity, queue)
        if raw is None:
            return None
        with self._lock:
            tag = next(self._tags)
            self._pending[tag] = _Pending(raw.queue, raw.delivery_tag)
        return Delivery(delivery_tag=tag, queue=raw.queue, message=raw.message)

    def _dispatch(self, consumer: _Consumer, delivery: Delivery) -> None:
        strategy = consumer.ack_strategy or self._connection.handler.ack_strategy
        strategy.on_delivered(self, delivery)
        try:
            consumer.callback(self, delivery)
        except Exception as exc:  # noqa: BLE001 — сбой потребителя не должен ронять брокер
            strategy.on_failed(self, delivery, exc)
        else:
            strategy.on_processed(self, delivery)

    def _take_pending(self, delivery_tag: int) -> _Pending:
        with self._lock:
            pending = self._pending.pop(delivery_tag, None)
        if pending is None:
            raise UnknownDeliveryTagError(f"Канал {self._number}: неизвестный тег доставки {delivery_tag}")
        return pending

    def _ensure_open(self) -> None:
        if not self.is_open:
            raise ConnectionClosedError(f"Канал {self._number} закрыт")


class AmqpConnection:
    """AMQP-соединение клиента. Создаётся ``ConnectionHandler.open_connection``."""

    def __init__(self, handler: "ConnectionHandler", connection_id: str, identity: ClientIdentity) -> None:
        self._handler = handler
        self._id = connection_id
        self._identity = identity
        self._open = True
        self._lock = threading.RLock()
        self._channel_numbers = itertools.count(1)
        self._channels: dict[int, AmqpChannel] = {}

    @property
    def connection_id(self) -> str:
        return self._id

    @property
    def identity(self) -> ClientIdentity:
        return self._identity

    @property
    def handler(self) -> "ConnectionHandler":
        return self._handler

    @property
    def is_open(self) -> bool:
        return self._open

    def channel(self) -> AmqpChannel:
        with self._lock:
            if not self._open:
                raise ConnectionClosedError(f"Соединение {self._id} закрыто")
            number = next(self._channel_numbers)
            channel = AmqpChannel(self, number)
            self._channels[number] = channel
            return channel

    def close(self) -> None:
        with self._lock:
            if not self._open:
                return
            channels = list(self._channels.values())
        for channel in channels:
            channel.close()
        with self._lock:
            self._open = False
        self._handler._unregister(self._id)
        logger.info("Соединение %s (%s) закрыто", self._id, self._identity.client_id)

    def _forget_channel(self, number: int) -> None:
        with self._lock:
            self._channels.pop(number, None)

    def __enter__(self) -> "AmqpConnection":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"AmqpConnection(id={self._id!r}, client={self._identity.client_id!r}, open={self._open})"


# --------------------------------------------------------------------------
# Компонент
# --------------------------------------------------------------------------
class ConnectionHandler:
    """Обработчик AMQP-соединений — точка входа брокера для всех клиентов."""

    def __init__(
        self,
        router: MessageRouter,
        *,
        authentication: AuthenticationStrategy | None = None,
        access_policy: AccessPolicy | None = None,
        ack_strategy: AcknowledgementStrategy | None = None,
        max_connections: int | None = None,
    ) -> None:
        self._router = router
        self._auth = authentication or AnonymousAuthentication()
        self._access = access_policy or PermitAllPolicy()
        self._ack = ack_strategy or AckAfterProcessing()
        self._max_connections = max_connections
        self._queues: dict[str, MessageQueue] = {}
        self._connections: dict[str, AmqpConnection] = {}
        self._ids = itertools.count(1)
        self._lock = threading.RLock()

    # ------------------------------------------------------------------
    # Конфигурация
    # ------------------------------------------------------------------
    def register_queue(self, queue: MessageQueue) -> None:
        """Регистрирует очередь, из которой обработчик выдаёт сообщения."""
        with self._lock:
            self._queues[queue.name] = queue

    def unregister_queue(self, name: str) -> None:
        with self._lock:
            self._queues.pop(name, None)

    def set_authentication_strategy(self, strategy: AuthenticationStrategy) -> None:
        with self._lock:
            self._auth = strategy
        logger.info("Стратегия аутентификации -> %s", type(strategy).__name__)

    def set_access_policy(self, policy: AccessPolicy) -> None:
        with self._lock:
            self._access = policy
        logger.info("Политика доступа -> %s", type(policy).__name__)

    def set_ack_strategy(self, strategy: AcknowledgementStrategy) -> None:
        with self._lock:
            self._ack = strategy
        logger.info("Стратегия подтверждения -> %s", type(strategy).__name__)

    @property
    def ack_strategy(self) -> AcknowledgementStrategy:
        with self._lock:
            return self._ack

    # ------------------------------------------------------------------
    # Соединения
    # ------------------------------------------------------------------
    def open_connection(self, credentials: Credentials) -> AmqpConnection:
        with self._lock:
            auth = self._auth
        identity = auth.authenticate(credentials)
        with self._lock:
            if self._max_connections is not None and len(self._connections) >= self._max_connections:
                raise ConnectionLimitError(f"Достигнут лимит соединений: {self._max_connections}")
            connection = AmqpConnection(self, f"conn-{next(self._ids)}", identity)
            self._connections[connection.connection_id] = connection
        logger.info("Открыто соединение %s для %s", connection.connection_id, identity.client_id)
        return connection

    def active_connections(self) -> tuple[AmqpConnection, ...]:
        with self._lock:
            return tuple(self._connections.values())

    def close_all(self) -> None:
        for connection in self.active_connections():
            connection.close()

    # ------------------------------------------------------------------
    # Внутренний API для каналов
    # ------------------------------------------------------------------
    def _route_published(self, identity: ClientIdentity, message: Message) -> list[str]:
        """Связи 3 и 8: проверка прав и передача сообщения маршрутизатору."""
        with self._lock:
            access = self._access
        if not access.can_publish(identity, message.exchange, message.routing_key):
            raise AccessDeniedError(
                f"Клиенту «{identity.client_id}» запрещена публикация с ключом «{message.routing_key}»"
            )
        return self._router.route(message)

    def _fetch_for_consumer(self, identity: ClientIdentity, queue: str) -> Delivery | None:
        """Связи 6 и 11: проверка прав и извлечение сообщения из очереди."""
        self._check_consume(identity, queue)
        return self._queue(queue).get()

    def _check_consume(self, identity: ClientIdentity, queue: str) -> None:
        with self._lock:
            access = self._access
        if not access.can_consume(identity, queue):
            raise AccessDeniedError(f"Клиенту «{identity.client_id}» запрещено чтение очереди «{queue}»")
        self._queue(queue)

    def _queue(self, name: str) -> MessageQueue:
        with self._lock:
            queue = self._queues.get(name)
        if queue is None:
            raise QueueNotFoundError(f"Очередь «{name}» не зарегистрирована")
        return queue

    def _unregister(self, connection_id: str) -> None:
        with self._lock:
            self._connections.pop(connection_id, None)
