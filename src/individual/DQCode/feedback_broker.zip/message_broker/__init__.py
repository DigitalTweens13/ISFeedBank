"""Брокер сообщений ИС управления обратной связью клиентов банка.

Компоненты (диаграмма C4 L3):

* ``connection_handler`` — обработчик AMQP-соединений;
* ``exchange_manager``   — маршрутизатор сообщений;
* ``queue_labeling``     — очередь задач разметки ``reviews.labeling``;
* ``queue_cases``        — очередь событий обращений ``cases.events``.

Компоненты зависят только от ``message_broker.core``; связывает их
``message_broker.assembly.build_feedback_broker``.
"""

from .assembly import FeedbackBroker, build_feedback_broker

__all__ = ["FeedbackBroker", "build_feedback_broker"]
