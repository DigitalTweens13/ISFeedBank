"""Сборка контейнера «Брокер сообщений» из независимых компонентов.

Это единственное место, которое знает обо всех четырёх компонентах
и связывает их через контракты ядра (composition root).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

from .connection_handler import (
    AccessPolicy,
    AckAfterProcessing,
    AcknowledgementStrategy,
    AmqpConnection,
    AnonymousAuthentication,
    AuthenticationStrategy,
    ConnectionHandler,
    Credentials,
    Permissions,
    PermissionTablePolicy,
    SharedSecretAuthentication,
)
from .exchange_manager import ExchangeManager
from .queue_cases import CaseEventsQueue
from .queue_cases import QUEUE_NAME as CASES_QUEUE
from .queue_labeling import QUEUE_NAME as LABELING_QUEUE
from .queue_labeling import ReviewsLabelingQueue

# Клиенты брокера — контейнеры с диаграммы.
API_BACKEND = "api_backend"
LABELING_WORKER = "labeling_worker"
BACKGROUND_WORKER = "background_worker"

#: Права клиентов строго по связям диаграммы L3 (таблица 2.3 отчёта).
FEEDBACK_PERMISSIONS: Mapping[str, Permissions] = {
    # связь 1
    API_BACKEND: Permissions.of(publish=[LABELING_QUEUE]),
    # связи 5 и 7
    LABELING_WORKER: Permissions.of(publish=[CASES_QUEUE], consume=[LABELING_QUEUE]),
    # связи 2 и 10
    BACKGROUND_WORKER: Permissions.of(publish=[LABELING_QUEUE], consume=[CASES_QUEUE]),
}


@dataclass
class FeedbackBroker:
    """Собранный брокер: доступ к компонентам и удобное подключение."""

    connection_handler: ConnectionHandler
    exchange_manager: ExchangeManager
    labeling_queue: ReviewsLabelingQueue
    cases_queue: CaseEventsQueue

    def connect(self, client_id: str, secret: str | None = None) -> AmqpConnection:
        return self.connection_handler.open_connection(Credentials(client_id, secret))

    def shutdown(self) -> None:
        self.connection_handler.close_all()


def build_feedback_broker(
    *,
    secrets: Mapping[str, str] | None = None,
    authentication: AuthenticationStrategy | None = None,
    access_policy: AccessPolicy | None = None,
    ack_strategy: AcknowledgementStrategy | None = None,
) -> FeedbackBroker:
    """Создаёт брокер в конфигурации из отчёта.

    * direct-обмен ``feedback.direct``, ключ маршрутизации = имя очереди;
    * две очереди со стратегиями по умолчанию;
    * права клиентов по таблице ``FEEDBACK_PERMISSIONS``;
    * подтверждение после обработки.

    Если переданы ``secrets`` («клиент → секрет»), включается проверка
    секретов, иначе — анонимное подключение по идентификатору.
    """
    labeling_queue = ReviewsLabelingQueue()
    cases_queue = CaseEventsQueue()

    exchange_manager = ExchangeManager()
    exchange_manager.bind_queue(labeling_queue)  # связь 4
    exchange_manager.bind_queue(cases_queue)     # связь 9

    if authentication is None:
        authentication = SharedSecretAuthentication(secrets) if secrets else AnonymousAuthentication()

    handler = ConnectionHandler(
        exchange_manager,  # связи 3, 8
        authentication=authentication,
        access_policy=access_policy or PermissionTablePolicy(FEEDBACK_PERMISSIONS),
        ack_strategy=ack_strategy or AckAfterProcessing(),
    )
    handler.register_queue(labeling_queue)  # связь 6
    handler.register_queue(cases_queue)     # связь 11

    return FeedbackBroker(handler, exchange_manager, labeling_queue, cases_queue)
