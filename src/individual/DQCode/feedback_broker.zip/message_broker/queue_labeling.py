"""Компонент queue_labeling — очередь задач разметки ``reviews.labeling``.

Хранит задачи разметки отзывов, опубликованные Backend API (связь 1)
и воркером фоновых задач (связь 2), до их получения воркером разметки
(связи 5–6). Сообщения в очередь кладёт маршрутизатор (связь 4).

Стратегии, применяемые очередью:

* порядок выдачи — ``PriorityStorage(NegativeReviewsFirstPolicy())``
  по умолчанию: отзывы с низкой оценкой размечаются раньше; можно
  переключить на ``FifoStorage`` или ``PriorityStorage(SourcePriorityPolicy())``;
* валидация — ``StrictLabelingTaskValidation`` (по умолчанию) или
  ``LenientLabelingTaskValidation``;
* переполнение — ``RejectPublishOverflow`` (по умолчанию) или
  ``DropHeadOverflow``.

Модуль зависит только от ``message_broker.core``.
"""

from __future__ import annotations

from typing import Any, Mapping

from .core import (
    BaseQueue,
    Message,
    MessageValidationError,
    OverflowStrategy,
    PriorityPolicy,
    PriorityStorage,
    RejectPublishOverflow,
    RequiredFieldsValidation,
    StorageStrategy,
    ValidationStrategy,
)

QUEUE_NAME = "reviews.labeling"

#: Источники задач: пакет, принятый Backend API, и отзывы, собранные
#: воркером фоновых задач.
SOURCE_API_BATCH = "api_batch"
SOURCE_COLLECTOR = "collector"
ALLOWED_SOURCES = frozenset({SOURCE_API_BATCH, SOURCE_COLLECTOR})

MAX_TEXT_LENGTH = 10_000


# --------------------------------------------------------------------------
# Стратегии валидации задачи разметки
# --------------------------------------------------------------------------
class StrictLabelingTaskValidation(RequiredFieldsValidation):
    """Полная схема задачи разметки.

    Обязательные поля: ``review_id`` (str), ``text`` (str, непустой),
    ``source`` (одно из ``ALLOWED_SOURCES``).
    Необязательные: ``rating`` (int 1–5), ``batch_id`` (str),
    ``channel`` (str).
    """

    def __init__(self, allowed_sources: frozenset[str] = ALLOWED_SOURCES) -> None:
        super().__init__({"review_id": str, "text": str, "source": str})
        self._allowed_sources = allowed_sources

    def validate_extra(self, body: Mapping[str, Any]) -> None:
        if not body["review_id"].strip():
            raise MessageValidationError("review_id не может быть пустым")
        text = body["text"].strip()
        if not text:
            raise MessageValidationError("Текст отзыва пуст")
        if len(text) > MAX_TEXT_LENGTH:
            raise MessageValidationError(f"Текст отзыва длиннее {MAX_TEXT_LENGTH} символов")
        if body["source"] not in self._allowed_sources:
            raise MessageValidationError(
                f"Неизвестный источник «{body['source']}», допустимы: {sorted(self._allowed_sources)}"
            )
        rating = body.get("rating")
        if rating is not None and (not isinstance(rating, int) or isinstance(rating, bool) or not 1 <= rating <= 5):
            raise MessageValidationError("rating должен быть целым числом от 1 до 5")
        for optional in ("batch_id", "channel"):
            if optional in body and not isinstance(body[optional], str):
                raise MessageValidationError(f"Поле «{optional}» должно быть строкой")


class LenientLabelingTaskValidation(RequiredFieldsValidation):
    """Мягкая схема: достаточно ``review_id`` и ``text``.

    Удобна при подключении новых источников отзывов, пока их формат
    не согласован.
    """

    def __init__(self) -> None:
        super().__init__({"review_id": (str, int), "text": str})


# --------------------------------------------------------------------------
# Стратегии приоритета задач разметки
# --------------------------------------------------------------------------
class NegativeReviewsFirstPolicy(PriorityPolicy):
    """Негативные отзывы размечаются первыми: оценка 1 → приоритет 4,
    оценка 5 → 0. Без оценки — приоритет из свойств сообщения."""

    def priority_of(self, message: Message) -> int:
        rating = message.body.get("rating")
        if isinstance(rating, int) and not isinstance(rating, bool) and 1 <= rating <= 5:
            return 5 - rating
        return message.priority


class SourcePriorityPolicy(PriorityPolicy):
    """Приоритет по источнику: пакеты, загруженные через API, раньше
    фонового сбора (пользователь ждёт результат)."""

    def __init__(self, weights: Mapping[str, int] | None = None) -> None:
        self._weights = dict(weights or {SOURCE_API_BATCH: 1, SOURCE_COLLECTOR: 0})

    def priority_of(self, message: Message) -> int:
        return self._weights.get(message.body.get("source", ""), 0)


# --------------------------------------------------------------------------
# Компонент
# --------------------------------------------------------------------------
class ReviewsLabelingQueue(BaseQueue):
    """Очередь задач разметки ``reviews.labeling``."""

    DEFAULT_MAX_LENGTH = 10_000

    def __init__(
        self,
        *,
        storage: StorageStrategy | None = None,
        overflow: OverflowStrategy | None = None,
        validation: ValidationStrategy | None = None,
        max_length: int | None = DEFAULT_MAX_LENGTH,
    ) -> None:
        super().__init__(
            QUEUE_NAME,
            storage=PriorityStorage(NegativeReviewsFirstPolicy()) if storage is None else storage,
            overflow=RejectPublishOverflow() if overflow is None else overflow,
            validation=StrictLabelingTaskValidation() if validation is None else validation,
            max_length=max_length,
        )
