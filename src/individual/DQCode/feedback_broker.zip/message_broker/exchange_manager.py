"""Компонент exchange_manager — маршрутизатор сообщений (RabbitMQ Exchanges).

Получает от обработчика соединений опубликованные сообщения (связи 3, 8)
и по ключу маршрутизации направляет их в очереди: задачи разметки —
в ``reviews.labeling`` (связь 4), события по обращениям — в
``cases.events`` (связь 9).

Стратегии:

* ``RoutingStrategy`` — правило сопоставления ключа сообщения с ключом
  привязки: ``DirectRoutingStrategy`` (по умолчанию, допущение отчёта:
  точечный обмен, ключ = имя очереди), ``TopicRoutingStrategy``
  (шаблоны ``*`` и ``#``), ``FanoutRoutingStrategy`` (во все очереди);
  задаётся для каждого обмена и меняется во время работы;
* ``UnroutablePolicy`` — что делать с сообщением, которое никуда не
  попало: ``RaiseOnUnroutable`` (по умолчанию, публикатор узнаёт об
  ошибке), ``DiscardUnroutable``, ``AlternateQueueUnroutable``.

Модуль зависит только от ``message_broker.core``; очереди он знает
через протокол ``MessageQueue``.
"""

from __future__ import annotations

import logging
import threading
from abc import ABC, abstractmethod
from dataclasses import dataclass

from .core import (
    BrokerError,
    ExchangeConflictError,
    ExchangeNotFoundError,
    Message,
    MessageQueue,
    UnroutableMessageError,
)

logger = logging.getLogger(__name__)

DEFAULT_EXCHANGE = "feedback.direct"


# --------------------------------------------------------------------------
# Стратегии маршрутизации
# --------------------------------------------------------------------------
class RoutingStrategy(ABC):
    """Правило, по которому обмен выбирает очереди."""

    #: Тип обмена в терминах AMQP — для диагностики и проверки конфликтов.
    exchange_type: str = ""

    @abstractmethod
    def matches(self, binding_key: str, message: Message) -> bool:
        """Подходит ли привязка с ключом ``binding_key`` для сообщения."""


class DirectRoutingStrategy(RoutingStrategy):
    """Точное совпадение ключа маршрутизации с ключом привязки."""

    exchange_type = "direct"

    def matches(self, binding_key: str, message: Message) -> bool:
        return binding_key == message.routing_key


class TopicRoutingStrategy(RoutingStrategy):
    """Шаблоны AMQP: ``*`` — ровно одно слово, ``#`` — ноль и более слов.

    Например, привязка ``cases.#`` принимает ``cases.events`` и
    ``cases.events.escalated``.
    """

    exchange_type = "topic"

    def matches(self, binding_key: str, message: Message) -> bool:
        return topic_matches(binding_key, message.routing_key)


class FanoutRoutingStrategy(RoutingStrategy):
    """Копия сообщения в каждую привязанную очередь, ключ игнорируется."""

    exchange_type = "fanout"

    def matches(self, binding_key: str, message: Message) -> bool:
        return True


def topic_matches(pattern: str, routing_key: str) -> bool:
    """Сопоставление ключа с шаблоном topic-обмена."""
    p, k = pattern.split("."), routing_key.split(".")
    memo: dict[tuple[int, int], bool] = {}

    def match(i: int, j: int) -> bool:
        if (i, j) in memo:
            return memo[(i, j)]
        if i == len(p):
            result = j == len(k)
        elif p[i] == "#":
            result = match(i + 1, j) or (j < len(k) and match(i, j + 1))
        elif j == len(k):
            result = False
        else:
            result = (p[i] == "*" or p[i] == k[j]) and match(i + 1, j + 1)
        memo[(i, j)] = result
        return result

    return match(0, 0)


# --------------------------------------------------------------------------
# Стратегии обработки немаршрутизируемых сообщений
# --------------------------------------------------------------------------
class UnroutablePolicy(ABC):
    """Что делать с сообщением, для которого не нашлось очереди."""

    @abstractmethod
    def handle(self, message: Message, exchange: str) -> list[str]:
        """Возвращает имена очередей, куда сообщение всё же попало."""


class RaiseOnUnroutable(UnroutablePolicy):
    """Аналог флага ``mandatory``: публикатор получает ошибку."""

    def handle(self, message: Message, exchange: str) -> list[str]:
        raise UnroutableMessageError(
            f"Обмен «{exchange}»: нет очереди для ключа «{message.routing_key}»"
        )


class DiscardUnroutable(UnroutablePolicy):
    """Сообщение отбрасывается с записью в журнал."""

    def handle(self, message: Message, exchange: str) -> list[str]:
        logger.warning(
            "Обмен %s: сообщение %s с ключом %s отброшено — нет очереди",
            exchange, message.message_id, message.routing_key,
        )
        return []


class AlternateQueueUnroutable(UnroutablePolicy):
    """Аналог alternate exchange: сообщение уходит в резервную очередь
    для последующего разбора."""

    def __init__(self, queue: MessageQueue) -> None:
        self._queue = queue

    def handle(self, message: Message, exchange: str) -> list[str]:
        self._queue.put(message)
        return [self._queue.name]


# --------------------------------------------------------------------------
# Обмен и привязки
# --------------------------------------------------------------------------
@dataclass(frozen=True)
class Binding:
    """Привязка очереди к обмену по ключу."""

    queue: MessageQueue
    binding_key: str


class Exchange:
    """Обмен: набор привязок и сменяемая стратегия маршрутизации."""

    def __init__(self, name: str, routing: RoutingStrategy) -> None:
        self._name = name
        self._routing = routing
        self._bindings: list[Binding] = []
        self._lock = threading.RLock()

    @property
    def name(self) -> str:
        return self._name

    @property
    def routing_strategy(self) -> RoutingStrategy:
        return self._routing

    @property
    def bindings(self) -> tuple[Binding, ...]:
        with self._lock:
            return tuple(self._bindings)

    def set_routing_strategy(self, routing: RoutingStrategy) -> None:
        with self._lock:
            self._routing = routing

    def bind(self, queue: MessageQueue, binding_key: str) -> None:
        with self._lock:
            if any(b.queue.name == queue.name and b.binding_key == binding_key for b in self._bindings):
                return
            self._bindings.append(Binding(queue, binding_key))

    def unbind(self, queue_name: str, binding_key: str | None = None) -> int:
        with self._lock:
            before = len(self._bindings)
            self._bindings = [
                b for b in self._bindings
                if not (b.queue.name == queue_name and (binding_key is None or b.binding_key == binding_key))
            ]
            return before - len(self._bindings)

    def resolve(self, message: Message) -> list[MessageQueue]:
        """Очереди, подходящие сообщению, без повторов, в порядке привязки."""
        with self._lock:
            routing, bindings = self._routing, list(self._bindings)
        targets: dict[str, MessageQueue] = {}
        for binding in bindings:
            if binding.queue.name not in targets and routing.matches(binding.binding_key, message):
                targets[binding.queue.name] = binding.queue
        return list(targets.values())


# --------------------------------------------------------------------------
# Компонент
# --------------------------------------------------------------------------
class ExchangeManager:
    """Маршрутизатор сообщений. Реализует протокол ``MessageRouter``."""

    def __init__(
        self,
        *,
        default_exchange: str = DEFAULT_EXCHANGE,
        default_routing: RoutingStrategy | None = None,
        unroutable_policy: UnroutablePolicy | None = None,
    ) -> None:
        self._exchanges: dict[str, Exchange] = {}
        self._default_exchange = default_exchange
        self._unroutable = unroutable_policy or RaiseOnUnroutable()
        self._lock = threading.RLock()
        self.declare_exchange(default_exchange, default_routing or DirectRoutingStrategy())

    # ------------------------------------------------------------------
    # Управление обменами
    # ------------------------------------------------------------------
    @property
    def default_exchange(self) -> str:
        return self._default_exchange

    def declare_exchange(self, name: str, routing: RoutingStrategy) -> Exchange:
        """Объявляет обмен. Повторное объявление с тем же типом идемпотентно."""
        if not name:
            raise ValueError("Имя обмена не может быть пустым")
        with self._lock:
            existing = self._exchanges.get(name)
            if existing is not None:
                if existing.routing_strategy.exchange_type != routing.exchange_type:
                    raise ExchangeConflictError(
                        f"Обмен «{name}» уже объявлен с типом {existing.routing_strategy.exchange_type}"
                    )
                return existing
            exchange = Exchange(name, routing)
            self._exchanges[name] = exchange
            logger.info("Объявлен обмен %s (%s)", name, routing.exchange_type)
            return exchange

    def delete_exchange(self, name: str) -> None:
        with self._lock:
            if name == self._default_exchange:
                raise BrokerError("Обмен по умолчанию удалить нельзя")
            if self._exchanges.pop(name, None) is None:
                raise ExchangeNotFoundError(f"Обмен «{name}» не объявлен")

    def get_exchange(self, name: str | None = None) -> Exchange:
        key = self._resolve_name(name)
        with self._lock:
            exchange = self._exchanges.get(key)
        if exchange is None:
            raise ExchangeNotFoundError(f"Обмен «{key}» не объявлен")
        return exchange

    def exchanges(self) -> tuple[str, ...]:
        with self._lock:
            return tuple(self._exchanges)

    # ------------------------------------------------------------------
    # Привязки
    # ------------------------------------------------------------------
    def bind_queue(self, queue: MessageQueue, *, exchange: str | None = None, binding_key: str | None = None) -> None:
        """Привязывает очередь. По умолчанию ключ привязки = имя очереди."""
        key = binding_key if binding_key is not None else queue.name
        self.get_exchange(exchange).bind(queue, key)
        logger.info("Очередь %s привязана к %s по ключу %s", queue.name, self._resolve_name(exchange), key)

    def unbind_queue(self, queue_name: str, *, exchange: str | None = None, binding_key: str | None = None) -> int:
        return self.get_exchange(exchange).unbind(queue_name, binding_key)

    # ------------------------------------------------------------------
    # Смена стратегий
    # ------------------------------------------------------------------
    def set_routing_strategy(self, routing: RoutingStrategy, *, exchange: str | None = None) -> None:
        self.get_exchange(exchange).set_routing_strategy(routing)
        logger.info("Обмен %s: стратегия маршрутизации -> %s", self._resolve_name(exchange), type(routing).__name__)

    def set_unroutable_policy(self, policy: UnroutablePolicy) -> None:
        with self._lock:
            self._unroutable = policy

    @property
    def unroutable_policy(self) -> UnroutablePolicy:
        return self._unroutable

    # ------------------------------------------------------------------
    # Маршрутизация (протокол MessageRouter, связи 3→4 и 8→9)
    # ------------------------------------------------------------------
    def route(self, message: Message) -> list[str]:
        exchange = self.get_exchange(message.exchange or None)
        targets = exchange.resolve(message)
        if not targets:
            with self._lock:
                policy = self._unroutable
            return policy.handle(message, exchange.name)
        for queue in targets:
            queue.put(message)
        names = [q.name for q in targets]
        logger.debug("Сообщение %s (%s) -> %s", message.message_id, message.routing_key, names)
        return names

    def _resolve_name(self, name: str | None) -> str:
        return name or self._default_exchange
