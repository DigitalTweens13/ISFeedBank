"""Компонент connection_handler над RabbitMQ — обработчик AMQP-соединений.

Открывает настоящие соединения с сервером через ``pika`` для всех трёх
контейнеров (связи 1, 2, 5, 7, 10), передаёт публикуемые сообщения
маршрутизатору (3, 8) и выдаёт сообщения из очередей потребителям (6, 11).

Интерфейс канала тот же, что у модели в памяти (``basic_publish``,
``basic_get``, ``basic_consume``, ``basic_ack``, ``basic_nack``, ``basic_qos``),
поэтому код воркеров не зависит от того, с чем он работает.

Стратегии (меняются на лету):

* ``CredentialsProvider`` — откуда брать логин и пароль RabbitMQ:
  ``StaticCredentials``, ``PerClientCredentials``, ``EnvironmentCredentials``;
* ``ReconnectStrategy`` — как переподключаться при недоступности сервера
  и обрыве соединения: ``NoRetry``, ``FixedDelayRetry``, ``ExponentialBackoff``;
* ``AccessPolicy`` — кто что может публиковать и читать (как в модели
  в памяти, по связям диаграммы);
* ``AcknowledgementStrategy`` — когда подтверждать: ``AckAfterProcessing``
  (по умолчанию), ``AutoAck``, ``ManualAck``.

Надёжность: сообщения публикуются как persistent в durable-очереди,
с подтверждениями издателя (publisher confirms) и флагом ``mandatory``.
Неподтверждённое сообщение при падении воркера сервер возвращает в очередь сам.

Ограничение ``pika.BlockingConnection``: одно соединение — один поток.
"""

from __future__ import annotations

import importlib
import itertools
import logging
import os
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, replace
from typing import Any, Callable, Iterator, Mapping

from ..connection_handler import (
    AccessPolicy,
    AckAfterProcessing,
    AcknowledgementStrategy,
    AutoAck,
    ClientIdentity,
    ManualAck,
    Permissions,
    PermissionTablePolicy,
    PermitAllPolicy,
)
from ..core import (
    AccessDeniedError,
    AuthenticationError,
    BrokerError,
    ConnectionClosedError,
    Delivery,
    Message,
    QueueNotFoundError,
    QueueOverflowError,
    UnknownDeliveryTagError,
    UnroutableMessageError,
)
from .contracts import PublishRouter, QueueInfo, ServerQueue, decode, encode

__all__ = [
    "RabbitSettings",
    "CredentialsProvider", "StaticCredentials", "PerClientCredentials", "EnvironmentCredentials",
    "ReconnectStrategy", "NoRetry", "FixedDelayRetry", "ExponentialBackoff",
    "AccessPolicy", "PermitAllPolicy", "PermissionTablePolicy", "Permissions",
    "AcknowledgementStrategy", "AckAfterProcessing", "AutoAck", "ManualAck",
    "RabbitConnectionHandler", "RabbitConnection", "RabbitChannel",
]

logger = logging.getLogger(__name__)


# --------------------------------------------------------------------------
# Настройки сервера
# --------------------------------------------------------------------------
@dataclass(frozen=True)
class RabbitSettings:
    """Адрес сервера RabbitMQ."""

    host: str = "localhost"
    port: int = 5672
    virtual_host: str = "/"
    heartbeat: int = 30
    blocked_connection_timeout: float = 30.0

    @classmethod
    def from_env(cls) -> "RabbitSettings":
        """Из переменных ``RABBITMQ_HOST``, ``RABBITMQ_PORT``, ``RABBITMQ_VHOST``."""
        return cls(
            host=os.environ.get("RABBITMQ_HOST", cls.host),
            port=int(os.environ.get("RABBITMQ_PORT", cls.port)),
            virtual_host=os.environ.get("RABBITMQ_VHOST", cls.virtual_host),
        )


# --------------------------------------------------------------------------
# Учётные данные
# --------------------------------------------------------------------------
class CredentialsProvider(ABC):
    """Стратегия получения логина и пароля RabbitMQ для клиента.
    Проверяет их сам сервер; неверные данные дают ``AuthenticationError``."""

    @abstractmethod
    def credentials_for(self, client_id: str) -> tuple[str, str]:
        ...


@dataclass(frozen=True)
class StaticCredentials(CredentialsProvider):
    """Один пользователь для всех клиентов (разработка, демонстрация)."""

    username: str = "feedback"
    password: str = field(default="feedback", repr=False)

    def credentials_for(self, client_id: str) -> tuple[str, str]:
        return self.username, self.password


class PerClientCredentials(CredentialsProvider):
    """Свой пользователь RabbitMQ у каждого контейнера: права можно
    дополнительно ограничить на сервере."""

    def __init__(self, table: Mapping[str, tuple[str, str]]) -> None:
        self._table = dict(table)

    def credentials_for(self, client_id: str) -> tuple[str, str]:
        try:
            return self._table[client_id]
        except KeyError:
            raise AuthenticationError(f"Нет учётных данных для клиента «{client_id}»") from None


class EnvironmentCredentials(CredentialsProvider):
    """Из переменных окружения — так пароли не хранятся в коде.

    Сначала ищутся ``RABBITMQ_USER_<CLIENT>`` / ``RABBITMQ_PASSWORD_<CLIENT>``,
    затем общие ``RABBITMQ_USER`` / ``RABBITMQ_PASSWORD``.
    """

    def __init__(self, default_user: str = "feedback", default_password: str = "feedback") -> None:
        self._default = (default_user, default_password)

    def credentials_for(self, client_id: str) -> tuple[str, str]:
        suffix = client_id.upper()
        user = os.environ.get(f"RABBITMQ_USER_{suffix}") or os.environ.get("RABBITMQ_USER") or self._default[0]
        password = (os.environ.get(f"RABBITMQ_PASSWORD_{suffix}") or os.environ.get("RABBITMQ_PASSWORD")
                    or self._default[1])
        return user, password


# --------------------------------------------------------------------------
# Переподключение
# --------------------------------------------------------------------------
class ReconnectStrategy(ABC):
    """Паузы между попытками подключения (после первой неудачной)."""

    @abstractmethod
    def delays(self) -> Iterator[float]:
        ...


class NoRetry(ReconnectStrategy):
    """Одна попытка — ошибка сразу (тесты, отладка)."""

    def delays(self) -> Iterator[float]:
        return iter(())


@dataclass(frozen=True)
class FixedDelayRetry(ReconnectStrategy):
    attempts: int = 5
    delay: float = 2.0

    def delays(self) -> Iterator[float]:
        return iter([self.delay] * max(0, self.attempts - 1))


@dataclass(frozen=True)
class ExponentialBackoff(ReconnectStrategy):
    """1, 2, 4, 8 … секунд, но не больше ``max_delay``: сервер, который
    перезапускается, не заваливают попытками."""

    attempts: int = 8
    base: float = 1.0
    max_delay: float = 30.0

    def delays(self) -> Iterator[float]:
        return (min(self.max_delay, self.base * 2 ** i) for i in range(max(0, self.attempts - 1)))


# --------------------------------------------------------------------------
# Канал
# --------------------------------------------------------------------------
OnMessage = Callable[["RabbitChannel", Delivery], None]


@dataclass
class _Consumer:
    tag: str
    queue: str
    callback: OnMessage
    ack_strategy: AcknowledgementStrategy | None
    server_tag: str | None = None


@dataclass(frozen=True)
class _Pending:
    queue: str
    message: Message
    priority: int


class RabbitChannel:
    """Канал клиента. Создаётся ``RabbitConnection.channel()``."""

    DEFAULT_CONSUMER_PREFETCH = 1

    def __init__(self, connection: "RabbitConnection", number: int) -> None:
        self._connection = connection
        self._number = number
        self._open = True
        self._pending: dict[int, _Pending] = {}
        self._consumers: dict[str, _Consumer] = {}
        self._consumer_seq = itertools.count(1)
        self._prefetch = 0
        self._processed = 0
        self._limit: int | None = None
        self._paused = False
        self._raw: Any = None
        self._open_raw()

    # ------------------------------------------------------------------
    @property
    def number(self) -> int:
        return self._number

    @property
    def is_open(self) -> bool:
        return self._open and self._connection.is_open

    @property
    def unacked_count(self) -> int:
        return len(self._pending)

    def is_pending(self, delivery_tag: int) -> bool:
        return delivery_tag in self._pending

    def basic_qos(self, prefetch_count: int) -> None:
        """Сколько неподтверждённых сообщений сервер может выдать воркеру сразу."""
        if prefetch_count < 0:
            raise ValueError("prefetch_count не может быть отрицательным")
        self._ensure_open()
        self._prefetch = prefetch_count
        self._raw.basic_qos(prefetch_count=prefetch_count)

    # ------------------------------------------------------------------
    # Публикация (связи 1, 2, 7 → 3 → 4 / 8 → 9)
    # ------------------------------------------------------------------
    def basic_publish(self, routing_key: str, body: Mapping[str, Any], *,
                      headers: Mapping[str, Any] | None = None) -> list[str]:
        """Публикует сообщение. ``routing_key`` — логическое назначение
        (имя очереди); обмен, итоговый ключ и приоритет выбирают
        маршрутизатор и очередь. Возвращает имена очередей."""
        self._ensure_open()
        message = Message(body=dict(body), routing_key=routing_key, headers=dict(headers or {}),
                          publisher_id=self._connection.identity.client_id)
        handler = self._connection.handler
        handler._check_publish(self._connection.identity, message)
        targets = handler.router.plan(message)
        for target in targets:
            payload, properties = encode(message, target.priority)
            self._with_reconnect(lambda: self._publish_raw(target.exchange, target.routing_key, payload, properties))
        return [t.queue for t in targets]

    # ------------------------------------------------------------------
    # Получение (связи 5, 10 → 6, 11)
    # ------------------------------------------------------------------
    def basic_get(self, queue: str, *, auto_ack: bool = False) -> Delivery | None:
        """Забирает одно сообщение или ``None``, если очередь пуста."""
        self._ensure_open()
        self._connection.handler._check_consume(self._connection.identity, queue)
        method, properties, body = self._with_reconnect(lambda: self._raw.basic_get(queue=queue, auto_ack=False))
        if method is None:
            return None
        delivery = self._register(queue, method, properties, body)
        if auto_ack:
            self.basic_ack(delivery.delivery_tag)
        return delivery

    def basic_consume(self, queue: str, on_message: OnMessage, *,
                      ack_strategy: AcknowledgementStrategy | None = None,
                      consumer_tag: str | None = None) -> str:
        """Подписка на очередь. Если ``basic_qos`` не вызывался, ставится
        prefetch = 1: сообщения честно делятся между несколькими воркерами."""
        self._ensure_open()
        self._connection.handler._check_consume(self._connection.identity, queue)
        if self._prefetch == 0:
            self.basic_qos(self.DEFAULT_CONSUMER_PREFETCH)
        tag = consumer_tag or f"{self._connection.identity.client_id}.{self._number}.{next(self._consumer_seq)}"
        if tag in self._consumers:
            raise ValueError(f"Подписчик {tag} уже существует")
        consumer = _Consumer(tag, queue, on_message, ack_strategy)
        self._subscribe(consumer)
        self._consumers[tag] = consumer
        return tag

    def basic_cancel(self, consumer_tag: str) -> None:
        consumer = self._consumers.pop(consumer_tag, None)
        if consumer is not None and consumer.server_tag and self.is_open:
            self._raw.basic_cancel(consumer.server_tag)

    def start_consuming(self, *, max_messages: int | None = None,
                        inactivity_timeout: float | None = None, poll_interval: float = 0.2) -> int:
        """Цикл обработки сообщений подписчиков.

        Без параметров работает бесконечно (обычный режим воркера).
        ``max_messages`` — остановиться после N сообщений,
        ``inactivity_timeout`` — после N секунд без сообщений.
        При обрыве соединения переподключается по стратегии и
        восстанавливает подписки. Возвращает число обработанных сообщений.
        """
        start = self._processed
        self._limit = None if max_messages is None else start + max_messages
        idle_since = time.monotonic()
        try:
            return self._consume_loop(start, max_messages, inactivity_timeout, poll_interval, idle_since)
        finally:
            self._limit = None
            if self._paused and self.is_open:
                self._paused = False
                for consumer in self._consumers.values():  # подписки остаются для следующего вызова
                    self._subscribe(consumer)

    def _consume_loop(self, start: int, max_messages: int | None, inactivity_timeout: float | None,
                      poll_interval: float, idle_since: float) -> int:
        while self.is_open and self._consumers:
            before = self._processed
            try:
                self._connection.raw.process_data_events(time_limit=poll_interval)
            except self._connection.handler.connection_errors as exc:
                logger.warning("Соединение потеряно во время обработки: %s", exc)
                self._connection.reconnect()
                idle_since = time.monotonic()
                continue
            now = time.monotonic()
            if max_messages is not None and self._processed - start >= max_messages:
                break
            if self._processed > before:
                idle_since = now
            elif inactivity_timeout is not None and now - idle_since >= inactivity_timeout:
                break
        return self._processed - start

    # ------------------------------------------------------------------
    # Подтверждения
    # ------------------------------------------------------------------
    def basic_ack(self, delivery_tag: int) -> None:
        self._take(delivery_tag)
        self._raw.basic_ack(delivery_tag=delivery_tag)

    def basic_nack(self, delivery_tag: int, *, requeue: bool = True) -> None:
        """Отказ от сообщения.

        ``requeue=True`` — повторная попытка: в очередь отправляется копия
        со счётчиком попыток +1 (заголовок ``x-attempts``), оригинал
        подтверждается. ``requeue=False`` — сервер переносит сообщение
        в dead letter очередь ``<очередь>.dlq``.
        """
        pending = self._take(delivery_tag)
        if requeue:
            retry = pending.message.as_redelivered()
            payload, properties = encode(retry, pending.priority)
            try:
                self._publish_raw("", pending.queue, payload, properties)  # обмен по умолчанию → прямо в очередь
            except BrokerError as exc:
                # повтор поставить не удалось (например, очередь переполнена):
                # не крутим сообщение по кругу, а сохраняем в dead letter
                logger.error("Повтор %s не поставлен (%s) — в dead letter", pending.message.message_id, exc)
                self._raw.basic_nack(delivery_tag=delivery_tag, requeue=False)
                return
            self._raw.basic_ack(delivery_tag=delivery_tag)
        else:
            self._raw.basic_nack(delivery_tag=delivery_tag, requeue=False)

    def basic_reject(self, delivery_tag: int, *, requeue: bool = True) -> None:
        self.basic_nack(delivery_tag, requeue=requeue)

    # ------------------------------------------------------------------
    def close(self) -> None:
        """Закрывает канал. Неподтверждённые сообщения сервер вернёт в очереди сам."""
        if not self._open:
            return
        self._open = False
        self._pending.clear()
        self._consumers.clear()
        try:
            if self._raw is not None and self._raw.is_open:
                self._raw.close()
        except Exception as exc:  # noqa: BLE001 — соединение могло уже оборваться
            logger.debug("Ошибка при закрытии канала: %s", exc)
        self._connection._forget_channel(self._number)

    def __enter__(self) -> "RabbitChannel":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Внутреннее
    # ------------------------------------------------------------------
    def _open_raw(self) -> None:
        self._raw = self._connection.raw.channel()
        self._raw.confirm_delivery()  # сервер подтверждает каждую публикацию
        if self._prefetch:
            self._raw.basic_qos(prefetch_count=self._prefetch)

    def _after_reconnect(self) -> None:
        """Новое соединение: новые теги доставки, старые сервер уже вернул в очереди."""
        self._pending.clear()
        self._paused = False
        self._open_raw()
        for consumer in self._consumers.values():
            self._subscribe(consumer)

    def _pause(self) -> None:
        if self._paused:
            return
        self._paused = True
        for consumer in self._consumers.values():
            if consumer.server_tag:
                self._raw.basic_cancel(consumer.server_tag)
                consumer.server_tag = None

    def _subscribe(self, consumer: _Consumer) -> None:
        def on_raw(_ch: Any, method: Any, properties: Any, body: bytes) -> None:
            if self._limit is not None and self._processed >= self._limit:
                # лимит start_consuming исчерпан: отписаться и вернуть лишнее серверу
                self._pause()
                self._raw.basic_nack(delivery_tag=method.delivery_tag, requeue=True)
                return
            delivery = self._register(consumer.queue, method, properties, body)
            self._dispatch(consumer, delivery)

        consumer.server_tag = self._raw.basic_consume(queue=consumer.queue, on_message_callback=on_raw,
                                                      auto_ack=False)

    def _register(self, queue: str, method: Any, properties: Any, body: bytes) -> Delivery:
        message = decode(body, properties, routing_key=method.routing_key, exchange=method.exchange)
        if method.redelivered and message.delivery_count == 0:
            # сервер вернул сообщение после падения потребителя — это была попытка
            message = replace(message, delivery_count=1)
        self._pending[method.delivery_tag] = _Pending(queue, message, getattr(properties, "priority", None) or 0)
        return Delivery(delivery_tag=method.delivery_tag, queue=queue, message=message)

    def _dispatch(self, consumer: _Consumer, delivery: Delivery) -> None:
        strategy = consumer.ack_strategy or self._connection.handler.ack_strategy
        self._processed += 1
        try:
            strategy.on_delivered(self, delivery)
            try:
                consumer.callback(self, delivery)
            except Exception as exc:  # noqa: BLE001 — сбой обработчика не должен ронять воркер
                strategy.on_failed(self, delivery, exc)
            else:
                strategy.on_processed(self, delivery)
        except BrokerError as exc:
            # не удалось подтвердить/вернуть — сообщение остаётся неподтверждённым,
            # сервер вернёт его в очередь при закрытии канала
            logger.error("Не удалось подтвердить %s: %s", delivery.message.message_id, exc)

    def _publish_raw(self, exchange: str, routing_key: str, payload: bytes, properties: Mapping[str, Any]) -> None:
        handler = self._connection.handler
        exc_mod = handler.pika.exceptions
        props = handler.pika.BasicProperties(**properties)
        try:
            self._raw.basic_publish(exchange=exchange, routing_key=routing_key, body=payload,
                                    properties=props, mandatory=True)
        except exc_mod.UnroutableError:
            raise UnroutableMessageError(
                f"Сервер не нашёл очередь для «{routing_key}» в обмене «{exchange or '(по умолчанию)'}». "
                f"Топология объявлена? (setup)"
            ) from None
        except exc_mod.NackError:
            raise QueueOverflowError(f"Сервер отклонил сообщение «{routing_key}»: очередь переполнена") from None
        except exc_mod.ChannelClosedByBroker as exc:
            self._open_raw()
            raise BrokerError(f"Сервер закрыл канал: {exc.reply_code} {exc.reply_text}") from None

    def _with_reconnect(self, operation: Callable[[], Any]) -> Any:
        """Выполняет операцию; при обрыве соединения переподключается и повторяет один раз."""
        try:
            return operation()
        except self._connection.handler.connection_errors as exc:
            logger.warning("Соединение потеряно: %s — переподключение", exc)
            self._connection.reconnect()
            return operation()

    def _take(self, delivery_tag: int) -> _Pending:
        pending = self._pending.pop(delivery_tag, None)
        if pending is None:
            raise UnknownDeliveryTagError(f"Канал {self._number}: неизвестный тег доставки {delivery_tag}")
        return pending

    def _ensure_open(self) -> None:
        if not self.is_open:
            raise ConnectionClosedError(f"Канал {self._number} закрыт")


# --------------------------------------------------------------------------
# Соединение
# --------------------------------------------------------------------------
class RabbitConnection:
    """Соединение клиента с сервером. Создаётся ``RabbitConnectionHandler.open_connection``."""

    def __init__(self, handler: "RabbitConnectionHandler", connection_id: str,
                 identity: ClientIdentity, raw: Any) -> None:
        self._handler = handler
        self._id = connection_id
        self._identity = identity
        self._raw = raw
        self._open = True
        self._numbers = itertools.count(1)
        self._channels: dict[int, RabbitChannel] = {}

    @property
    def connection_id(self) -> str:
        return self._id

    @property
    def identity(self) -> ClientIdentity:
        return self._identity

    @property
    def handler(self) -> "RabbitConnectionHandler":
        return self._handler

    @property
    def raw(self) -> Any:
        return self._raw

    @property
    def is_open(self) -> bool:
        return self._open

    def channel(self) -> RabbitChannel:
        if not self._open:
            raise ConnectionClosedError(f"Соединение {self._id} закрыто")
        number = next(self._numbers)
        channel = RabbitChannel(self, number)
        self._channels[number] = channel
        return channel

    def reconnect(self) -> None:
        """Новое соединение по стратегии переподключения, каналы и подписки восстанавливаются."""
        try:
            if self._raw.is_open:
                self._raw.close()
        except Exception:  # noqa: BLE001
            pass
        self._raw = self._handler._connect_raw(self._identity.client_id)
        for channel in list(self._channels.values()):
            channel._after_reconnect()
        logger.info("Соединение %s восстановлено", self._id)

    def close(self) -> None:
        if not self._open:
            return
        for channel in list(self._channels.values()):
            channel.close()
        self._open = False
        try:
            if self._raw.is_open:
                self._raw.close()
        except Exception as exc:  # noqa: BLE001
            logger.debug("Ошибка при закрытии соединения: %s", exc)
        self._handler._unregister(self._id)

    def _forget_channel(self, number: int) -> None:
        self._channels.pop(number, None)

    def __enter__(self) -> "RabbitConnection":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"RabbitConnection(id={self._id!r}, client={self._identity.client_id!r}, open={self._open})"


# --------------------------------------------------------------------------
# Компонент
# --------------------------------------------------------------------------
class RabbitConnectionHandler:
    """Обработчик AMQP-соединений поверх настоящего RabbitMQ."""

    def __init__(
        self,
        router: PublishRouter,
        *,
        settings: RabbitSettings | None = None,
        credentials: CredentialsProvider | None = None,
        access_policy: AccessPolicy | None = None,
        ack_strategy: AcknowledgementStrategy | None = None,
        reconnect: ReconnectStrategy | None = None,
        pika_module: Any = None,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self._router = router
        self._settings = settings or RabbitSettings()
        self._credentials = credentials or StaticCredentials()
        self._access = access_policy or PermitAllPolicy()
        self._ack = ack_strategy or AckAfterProcessing()
        self._reconnect = reconnect or ExponentialBackoff()
        self._pika = pika_module if pika_module is not None else importlib.import_module("pika")
        self._sleep = sleep
        self._queues: dict[str, ServerQueue] = {}
        self._connections: dict[str, RabbitConnection] = {}
        self._ids = itertools.count(1)

        exc_mod = self._pika.exceptions
        self.connection_errors: tuple[type[BaseException], ...] = (exc_mod.AMQPConnectionError,)
        self._auth_errors = tuple(
            getattr(exc_mod, name) for name in
            ("ProbableAuthenticationError", "ProbableAccessDeniedError", "AuthenticationError")
            if hasattr(exc_mod, name)
        )

    # ------------------------------------------------------------------
    @property
    def pika(self) -> Any:
        return self._pika

    @property
    def router(self) -> PublishRouter:
        return self._router

    @property
    def settings(self) -> RabbitSettings:
        return self._settings

    @property
    def ack_strategy(self) -> AcknowledgementStrategy:
        return self._ack

    def register_queue(self, queue: ServerQueue) -> None:
        self._queues[queue.name] = queue

    def queues(self) -> tuple[ServerQueue, ...]:
        return tuple(self._queues.values())

    # ------------------------------------------------------------------
    # Смена стратегий
    # ------------------------------------------------------------------
    def set_credentials_provider(self, provider: CredentialsProvider) -> None:
        self._credentials = provider

    def set_reconnect_strategy(self, strategy: ReconnectStrategy) -> None:
        self._reconnect = strategy

    def set_access_policy(self, policy: AccessPolicy) -> None:
        self._access = policy

    def set_ack_strategy(self, strategy: AcknowledgementStrategy) -> None:
        self._ack = strategy

    # ------------------------------------------------------------------
    # Соединения
    # ------------------------------------------------------------------
    def open_connection(self, client_id: str) -> RabbitConnection:
        """Подключает клиента (контейнер) к серверу."""
        if not client_id:
            raise AuthenticationError("Не указан идентификатор клиента")
        raw = self._connect_raw(client_id)
        connection = RabbitConnection(self, f"conn-{next(self._ids)}", ClientIdentity(client_id, "rabbitmq"), raw)
        self._connections[connection.connection_id] = connection
        logger.info("Открыто соединение %s для %s", connection.connection_id, client_id)
        return connection

    def active_connections(self) -> tuple[RabbitConnection, ...]:
        return tuple(self._connections.values())

    def close_all(self) -> None:
        for connection in self.active_connections():
            connection.close()

    # ------------------------------------------------------------------
    # Администрирование топологии
    # ------------------------------------------------------------------
    def declare_topology(self, client_id: str = "setup") -> None:
        """Объявляет на сервере обмены, очереди и привязки (идемпотентно)."""
        raw = self._connect_raw(client_id)
        try:
            channel = raw.channel()
            try:
                self._router.declare(channel)
            except self._pika.exceptions.ChannelClosedByBroker as exc:
                if exc.reply_code == 406:
                    raise BrokerError(
                        "Очередь или обмен уже существуют на сервере с другими параметрами "
                        f"({exc.reply_text}). Удалите старую топологию: python rabbit_cli.py reset"
                    ) from None
                raise
        finally:
            if raw.is_open:
                raw.close()

    def delete_topology(self, exchanges: tuple[str, ...] = (), client_id: str = "setup") -> None:
        """Удаляет очереди (вместе с сообщениями!) и указанные обмены."""
        raw = self._connect_raw(client_id)
        try:
            channel = raw.channel()
            for queue in self._queues.values():
                channel.queue_delete(queue=queue.name)
                channel.queue_delete(queue=queue.dead_letter_queue)
            for exchange in exchanges:
                channel.exchange_delete(exchange=exchange)
        finally:
            if raw.is_open:
                raw.close()

    def queue_info(self, name: str, client_id: str = "monitor") -> QueueInfo:
        """Сколько сообщений ждёт в очереди и сколько у неё подписчиков."""
        raw = self._connect_raw(client_id)
        try:
            result = raw.channel().queue_declare(queue=name, passive=True)
            return QueueInfo(name, result.method.message_count, result.method.consumer_count)
        except self._pika.exceptions.ChannelClosedByBroker as exc:
            if exc.reply_code == 404:
                raise QueueNotFoundError(f"Очереди «{name}» нет на сервере") from None
            raise
        finally:
            if raw.is_open:
                raw.close()

    # ------------------------------------------------------------------
    # Внутренний API для каналов
    # ------------------------------------------------------------------
    def _connect_raw(self, client_id: str) -> Any:
        user, password = self._credentials.credentials_for(client_id)
        params = self._pika.ConnectionParameters(
            host=self._settings.host,
            port=self._settings.port,
            virtual_host=self._settings.virtual_host,
            credentials=self._pika.PlainCredentials(user, password),
            heartbeat=self._settings.heartbeat,
            blocked_connection_timeout=self._settings.blocked_connection_timeout,
            client_properties={"connection_name": client_id},  # имя видно в панели RabbitMQ
        )
        delays = self._reconnect.delays()
        while True:
            try:
                return self._pika.BlockingConnection(params)
            except self._auth_errors:
                raise AuthenticationError(f"RabbitMQ отклонил логин/пароль клиента «{client_id}»") from None
            except self.connection_errors as exc:
                delay = next(delays, None)
                if delay is None:
                    raise ConnectionClosedError(
                        f"Не удалось подключиться к RabbitMQ {self._settings.host}:{self._settings.port} "
                        f"({type(exc).__name__}). Сервер запущен? docker compose up -d"
                    ) from None
                logger.warning("RabbitMQ недоступен (%s), повтор через %.1f с", type(exc).__name__, delay)
                self._sleep(delay)

    def _check_publish(self, identity: ClientIdentity, message: Message) -> None:
        if not self._access.can_publish(identity, message.exchange, message.routing_key):
            raise AccessDeniedError(
                f"Клиенту «{identity.client_id}» запрещена публикация с ключом «{message.routing_key}»"
            )

    def _check_consume(self, identity: ClientIdentity, queue: str) -> None:
        if not self._access.can_consume(identity, queue):
            raise AccessDeniedError(f"Клиенту «{identity.client_id}» запрещено чтение очереди «{queue}»")
        known = {q.name for q in self._queues.values()} | {q.dead_letter_queue for q in self._queues.values()}
        if self._queues and queue not in known:
            raise QueueNotFoundError(f"Очередь «{queue}» не зарегистрирована")

    def _unregister(self, connection_id: str) -> None:
        self._connections.pop(connection_id, None)
