"""Общие контракты слоя над настоящим RabbitMQ.

Как и ``message_broker.core`` для модели в памяти, этот модуль — единственная
общая зависимость четырёх компонентов слоя. Здесь:

* протоколы ``AmqpChannelLike``, ``ServerQueue`` и ``PublishRouter``,
  через которые компоненты общаются, не импортируя друг друга;
* ``PublishTarget`` — решение маршрутизатора, куда и с каким приоритетом
  отправить сообщение;
* базовый класс очереди ``RabbitQueueBase`` со стратегиями порядка выдачи,
  переполнения и валидации;
* кодирование ``Message`` в AMQP-сообщение и обратно (JSON).

Модуль не импортирует ``pika``: с сервером работает только обработчик
соединений, остальные компоненты получают от него канал.
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Mapping, Protocol

from ..core import (
    Message,
    OverflowStrategy,
    PriorityPolicy,
    RejectPublishOverflow,
    ValidationStrategy,
)

#: Обмен и суффикс очередей «мёртвых» сообщений.
DEAD_LETTER_EXCHANGE = "feedback.dlx"
DEAD_LETTER_SUFFIX = ".dlq"

#: Заголовок с числом неудачных попыток обработки.
ATTEMPTS_HEADER = "x-attempts"
PUBLISHER_HEADER = "x-publisher"

#: Предел приоритета очередей (RabbitMQ рекомендует не больше 10).
DEFAULT_MAX_PRIORITY = 10


# --------------------------------------------------------------------------
# Протоколы
# --------------------------------------------------------------------------
class AmqpChannelLike(Protocol):
    """Минимум методов канала ``pika.BlockingChannel``, нужный для
    объявления топологии."""

    def exchange_declare(self, exchange: str, exchange_type: str = ..., passive: bool = ...,
                         durable: bool = ..., auto_delete: bool = ..., internal: bool = ...,
                         arguments: Mapping[str, Any] | None = ...) -> Any: ...

    def queue_declare(self, queue: str, passive: bool = ..., durable: bool = ..., exclusive: bool = ...,
                      auto_delete: bool = ..., arguments: Mapping[str, Any] | None = ...) -> Any: ...

    def queue_bind(self, queue: str, exchange: str, routing_key: str | None = ...,
                   arguments: Mapping[str, Any] | None = ...) -> Any: ...


@dataclass(frozen=True)
class PublishTarget:
    """Куда обработчик соединений должен отправить сообщение."""

    queue: str
    exchange: str
    routing_key: str
    priority: int


@dataclass(frozen=True)
class QueueInfo:
    """Состояние очереди на сервере."""

    name: str
    ready: int
    consumers: int


class ServerQueue(Protocol):
    """Очередь, объявленная на сервере (связи 4, 9 — приём; 6, 11 — выдача)."""

    @property
    def name(self) -> str: ...

    @property
    def dead_letter_queue(self) -> str: ...

    def declare(self, channel: AmqpChannelLike) -> None: ...

    def prepare(self, message: Message) -> int:
        """Проверяет сообщение и возвращает его приоритет."""
        ...


class PublishRouter(Protocol):
    """Маршрутизатор, которому обработчик соединений передаёт сообщения (связи 3, 8)."""

    def declare(self, channel: AmqpChannelLike) -> None: ...

    def plan(self, message: Message) -> list[PublishTarget]: ...


# --------------------------------------------------------------------------
# Стратегия порядка выдачи на сервере
# --------------------------------------------------------------------------
class DeliveryOrderStrategy(ABC):
    """Как задавать приоритет сообщению перед отправкой на сервер.

    Очередь на сервере объявлена приоритетной (``x-max-priority``) один раз,
    поэтому стратегию можно менять на лету: меняется только число,
    которое ставится в свойство ``priority`` публикуемых сообщений.
    """

    @abstractmethod
    def priority_for(self, message: Message, max_priority: int) -> int:
        ...


class FifoOrder(DeliveryOrderStrategy):
    """Всем сообщениям одинаковый приоритет — строгий порядок поступления."""

    def priority_for(self, message: Message, max_priority: int) -> int:
        return 0


class PriorityOrder(DeliveryOrderStrategy):
    """Приоритет считает предметная ``PriorityPolicy`` (например,
    «негативные отзывы первыми»); значение ограничивается пределом очереди."""

    def __init__(self, policy: PriorityPolicy) -> None:
        self._policy = policy

    @property
    def policy(self) -> PriorityPolicy:
        return self._policy

    def priority_for(self, message: Message, max_priority: int) -> int:
        return max(0, min(max_priority, int(self._policy.priority_of(message))))


# --------------------------------------------------------------------------
# Базовая очередь на сервере
# --------------------------------------------------------------------------
class RabbitQueueBase:
    """Описание очереди на сервере и её стратегии.

    Сообщения хранит RabbitMQ. Компонент отвечает за то, *какой* очередь
    будет на сервере (долговечная, приоритетная, лимит и поведение при
    переполнении, dead letter), и за то, *что* в неё попадёт
    (валидация и приоритет каждого сообщения).
    """

    def __init__(
        self,
        name: str,
        *,
        order: DeliveryOrderStrategy,
        validation: ValidationStrategy,
        overflow: OverflowStrategy | None = None,
        max_length: int | None = None,
        max_priority: int = DEFAULT_MAX_PRIORITY,
    ) -> None:
        if not name:
            raise ValueError("Имя очереди не может быть пустым")
        if max_length is not None and max_length <= 0:
            raise ValueError("max_length должен быть положительным")
        if not 1 <= max_priority <= 255:
            raise ValueError("max_priority должен быть от 1 до 255")
        overflow = overflow if overflow is not None else RejectPublishOverflow()
        if overflow.amqp_overflow is None:
            raise ValueError(f"Стратегия {type(overflow).__name__} не поддерживается RabbitMQ")
        self._name = name
        self._order = order
        self._validation = validation
        self._overflow = overflow
        self._max_length = max_length
        self._max_priority = max_priority

    # ------------------------------------------------------------------
    @property
    def name(self) -> str:
        return self._name

    @property
    def dead_letter_queue(self) -> str:
        return self._name + DEAD_LETTER_SUFFIX

    @property
    def order_strategy(self) -> DeliveryOrderStrategy:
        return self._order

    @property
    def validation_strategy(self) -> ValidationStrategy:
        return self._validation

    @property
    def overflow_strategy(self) -> OverflowStrategy:
        return self._overflow

    # ------------------------------------------------------------------
    # Смена стратегий на лету
    # ------------------------------------------------------------------
    def set_order_strategy(self, order: DeliveryOrderStrategy) -> None:
        self._order = order

    def set_validation_strategy(self, validation: ValidationStrategy) -> None:
        self._validation = validation

    # Переполнение и лимит — параметры объявления очереди на сервере.
    # RabbitMQ не даёт изменить их у существующей очереди, поэтому они
    # задаются в конструкторе; для смены очередь нужно удалить и объявить заново.

    # ------------------------------------------------------------------
    def arguments(self) -> dict[str, Any]:
        """Аргументы ``queue_declare``, вычисленные из стратегий."""
        args: dict[str, Any] = {
            "x-max-priority": self._max_priority,
            "x-dead-letter-exchange": DEAD_LETTER_EXCHANGE,
            "x-dead-letter-routing-key": self.dead_letter_queue,
            "x-overflow": self._overflow.amqp_overflow,
        }
        if self._max_length is not None:
            args["x-max-length"] = self._max_length
        return args

    def declare(self, channel: AmqpChannelLike) -> None:
        """Объявляет на сервере очередь и её dead letter очередь (идемпотентно)."""
        channel.exchange_declare(exchange=DEAD_LETTER_EXCHANGE, exchange_type="direct", durable=True)
        channel.queue_declare(queue=self.dead_letter_queue, durable=True)
        channel.queue_bind(queue=self.dead_letter_queue, exchange=DEAD_LETTER_EXCHANGE,
                           routing_key=self.dead_letter_queue)
        channel.queue_declare(queue=self._name, durable=True, arguments=self.arguments())

    def prepare(self, message: Message) -> int:
        """Связь 4/9: проверка сообщения и вычисление приоритета."""
        self._validation.validate(message)
        return self._order.priority_for(message, self._max_priority)

    def __repr__(self) -> str:
        return f"{type(self).__name__}(name={self._name!r}, order={type(self._order).__name__})"


# --------------------------------------------------------------------------
# Кодирование сообщений
# --------------------------------------------------------------------------
def encode(message: Message, priority: int) -> tuple[bytes, dict[str, Any]]:
    """``Message`` → тело и свойства AMQP (для ``pika.BasicProperties``)."""
    headers = dict(message.headers)
    headers[ATTEMPTS_HEADER] = message.delivery_count
    if message.publisher_id:
        headers[PUBLISHER_HEADER] = message.publisher_id
    body = json.dumps(dict(message.body), ensure_ascii=False).encode("utf-8")
    properties = {
        "content_type": "application/json",
        "content_encoding": "utf-8",
        "delivery_mode": 2,  # persistent: сообщение пишется на диск
        "priority": priority,
        "message_id": message.message_id,
        "timestamp": int(message.timestamp.timestamp()),
        "app_id": message.publisher_id or None,
        "headers": headers,
    }
    return body, properties


def decode(body: bytes, properties: Any, *, routing_key: str, exchange: str) -> Message:
    """Тело и свойства AMQP → ``Message``. Невалидный JSON не теряется:
    он попадает в поле ``_raw``."""
    try:
        parsed = json.loads(body.decode("utf-8")) if body else {}
        payload = parsed if isinstance(parsed, dict) else {"_value": parsed}
    except (UnicodeDecodeError, json.JSONDecodeError):
        payload = {"_raw": body.decode("utf-8", errors="replace")}
    headers = dict(getattr(properties, "headers", None) or {})
    attempts = headers.pop(ATTEMPTS_HEADER, 0)
    publisher = headers.pop(PUBLISHER_HEADER, "") or getattr(properties, "app_id", "") or ""
    ts = getattr(properties, "timestamp", None)
    kwargs: dict[str, Any] = {}
    if getattr(properties, "message_id", None):
        kwargs["message_id"] = properties.message_id
    if ts:
        kwargs["timestamp"] = datetime.fromtimestamp(ts, tz=timezone.utc)
    return Message(
        body=payload,
        routing_key=routing_key,
        exchange=exchange,
        priority=getattr(properties, "priority", None) or 0,
        headers=headers,
        publisher_id=str(publisher),
        delivery_count=int(attempts) if isinstance(attempts, int) else 0,
        **kwargs,
    )
