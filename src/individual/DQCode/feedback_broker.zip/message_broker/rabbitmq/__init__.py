"""Python-слой над настоящим RabbitMQ.

Те же четыре компонента диаграммы L3, но сообщения хранит и доставляет
сервер RabbitMQ, а компоненты управляют им:

* ``connection_handler`` — соединения через ``pika``, переподключение,
  права, подтверждения;
* ``exchange_manager``   — объявление обменов и привязок, выбор обмена и ключа;
* ``queue_labeling``     — очередь ``reviews.labeling``: параметры на сервере,
  валидация, приоритет;
* ``queue_cases``        — очередь ``cases.events``: то же для событий.

Требуется ``pip install pika`` и запущенный сервер (``docker compose up -d``).
"""

from .assembly import RabbitFeedbackBroker, build_rabbit_broker

__all__ = ["RabbitFeedbackBroker", "build_rabbit_broker"]
