"""Компонент queue_cases над RabbitMQ — очередь ``cases.events``.

Стратегии:

* порядок выдачи — ``FifoOrder()`` по умолчанию (хронология событий),
  ``PriorityOrder(CriticalCasesFirstPolicy())`` или
  ``PriorityOrder(NearestSlaFirstPolicy())``, меняется на лету;
* валидация — ``CaseEventValidation(allowed_event_types)``, меняется на лету;
* переполнение — ``RejectPublishOverflow`` по умолчанию: события
  по обращениям нельзя терять; задаётся при объявлении очереди.

Предметные стратегии общие с моделью в памяти (``message_broker.queue_cases``).
"""

from __future__ import annotations

from ..core import OverflowStrategy, ValidationStrategy
from ..queue_cases import (
    EVENT_CASE_CREATED,
    QUEUE_NAME,
    CaseEventValidation,
    CriticalCasesFirstPolicy,
    NearestSlaFirstPolicy,
)
from .contracts import DeliveryOrderStrategy, FifoOrder, PriorityOrder, RabbitQueueBase

__all__ = [
    "QUEUE_NAME",
    "EVENT_CASE_CREATED",
    "RabbitCasesQueue",
    "CaseEventValidation",
    "CriticalCasesFirstPolicy",
    "NearestSlaFirstPolicy",
    "FifoOrder",
    "PriorityOrder",
]


class RabbitCasesQueue(RabbitQueueBase):
    """Очередь событий обращений на сервере RabbitMQ."""

    DEFAULT_MAX_LENGTH = 50_000

    def __init__(
        self,
        *,
        order: DeliveryOrderStrategy | None = None,
        validation: ValidationStrategy | None = None,
        overflow: OverflowStrategy | None = None,
        max_length: int | None = DEFAULT_MAX_LENGTH,
    ) -> None:
        super().__init__(
            QUEUE_NAME,
            order=FifoOrder() if order is None else order,
            validation=CaseEventValidation() if validation is None else validation,
            overflow=overflow,
            max_length=max_length,
        )
