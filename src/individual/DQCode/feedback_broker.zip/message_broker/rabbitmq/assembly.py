"""Сборка брокера над настоящим RabbitMQ (composition root).

    from message_broker.rabbitmq import build_rabbit_broker

    broker = build_rabbit_broker()   # localhost:5672, пользователь feedback
    broker.setup()                   # объявить обмены и очереди (идемпотентно)
    api = broker.connect("api_backend").channel()
    api.basic_publish("reviews.labeling", {...})
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..assembly import API_BACKEND, BACKGROUND_WORKER, FEEDBACK_PERMISSIONS, LABELING_WORKER
from ..connection_handler import AccessPolicy, AcknowledgementStrategy, PermissionTablePolicy
from .connection_handler import (
    CredentialsProvider,
    EnvironmentCredentials,
    RabbitConnection,
    RabbitConnectionHandler,
    RabbitSettings,
    ReconnectStrategy,
)
from .contracts import DEAD_LETTER_EXCHANGE, QueueInfo
from .exchange_manager import DirectRouting, RabbitExchangeManager, TopicRouting
from .queue_cases import RabbitCasesQueue
from .queue_labeling import RabbitLabelingQueue

__all__ = ["RabbitFeedbackBroker", "build_rabbit_broker", "API_BACKEND", "LABELING_WORKER", "BACKGROUND_WORKER"]


@dataclass
class RabbitFeedbackBroker:
    """Собранный слой: компоненты и удобные операции."""

    connection_handler: RabbitConnectionHandler
    exchange_manager: RabbitExchangeManager
    labeling_queue: RabbitLabelingQueue
    cases_queue: RabbitCasesQueue
    direct_routing: DirectRouting
    topic_routing: TopicRouting

    def setup(self) -> None:
        """Объявляет топологию на сервере. Безопасно вызывать при каждом старте сервиса."""
        self.connection_handler.declare_topology()

    def reset(self) -> None:
        """Удаляет очереди (с сообщениями) и обмены — для смены параметров очередей."""
        self.connection_handler.delete_topology(
            exchanges=tuple(s.exchange for s in self.exchange_manager.strategies) + (DEAD_LETTER_EXCHANGE,)
        )

    def connect(self, client_id: str) -> RabbitConnection:
        return self.connection_handler.open_connection(client_id)

    def stats(self) -> list[QueueInfo]:
        """Состояние очередей и их dead letter очередей на сервере."""
        result = []
        for queue in (self.labeling_queue, self.cases_queue):
            result.append(self.connection_handler.queue_info(queue.name))
            result.append(self.connection_handler.queue_info(queue.dead_letter_queue))
        return result

    def shutdown(self) -> None:
        self.connection_handler.close_all()


def build_rabbit_broker(
    *,
    settings: RabbitSettings | None = None,
    credentials: CredentialsProvider | None = None,
    access_policy: AccessPolicy | None = None,
    ack_strategy: AcknowledgementStrategy | None = None,
    reconnect: ReconnectStrategy | None = None,
    pika_module: Any = None,
) -> RabbitFeedbackBroker:
    """Брокер в конфигурации из отчёта: direct-обмен ``feedback.direct``
    (ключ = имя очереди), запасной topic-обмен ``feedback.topic`` для
    переключения на лету, две durable-очереди с dead letter, права
    клиентов по связям диаграммы, ack после обработки.

    Адрес и пароли по умолчанию берутся из переменных окружения
    (``RABBITMQ_HOST``, ``RABBITMQ_USER``, ``RABBITMQ_PASSWORD``), иначе
    ``localhost`` и ``feedback/feedback`` — как в ``docker-compose.yml``.
    """
    labeling_queue = RabbitLabelingQueue()
    cases_queue = RabbitCasesQueue()

    direct, topic = DirectRouting(), TopicRouting()
    router = RabbitExchangeManager(direct, alternatives=[topic])
    router.bind_queue(labeling_queue)  # связь 4
    router.bind_queue(cases_queue)     # связь 9

    handler = RabbitConnectionHandler(
        router,  # связи 3, 8
        settings=settings or RabbitSettings.from_env(),
        credentials=credentials or EnvironmentCredentials(),
        access_policy=access_policy or PermissionTablePolicy(FEEDBACK_PERMISSIONS),
        ack_strategy=ack_strategy,
        reconnect=reconnect,
        pika_module=pika_module,
    )
    handler.register_queue(labeling_queue)  # связь 6
    handler.register_queue(cases_queue)     # связь 11

    return RabbitFeedbackBroker(handler, router, labeling_queue, cases_queue, direct, topic)
