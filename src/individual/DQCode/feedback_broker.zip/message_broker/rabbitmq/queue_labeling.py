"""Компонент queue_labeling над RabbitMQ — очередь ``reviews.labeling``.

Сообщения хранит сервер; компонент задаёт параметры очереди и решает,
какие задачи принимать и с каким приоритетом.

Стратегии:

* порядок выдачи — ``PriorityOrder(NegativeReviewsFirstPolicy())``
  по умолчанию, ``FifoOrder()`` или ``PriorityOrder(SourcePriorityPolicy())``,
  меняется на лету;
* валидация — ``StrictLabelingTaskValidation`` / ``LenientLabelingTaskValidation``,
  меняется на лету;
* переполнение — ``RejectPublishOverflow`` (публикатор получает ошибку) или
  ``DropHeadOverflow`` (вытесненное уходит в ``reviews.labeling.dlq``);
  задаётся при объявлении очереди.

Предметные стратегии общие с моделью в памяти (``message_broker.queue_labeling``):
это один и тот же компонент, у которого две реализации хранения.
"""

from __future__ import annotations

from ..core import OverflowStrategy, ValidationStrategy
from ..queue_labeling import (
    QUEUE_NAME,
    LenientLabelingTaskValidation,
    NegativeReviewsFirstPolicy,
    SourcePriorityPolicy,
    StrictLabelingTaskValidation,
)
from .contracts import DeliveryOrderStrategy, FifoOrder, PriorityOrder, RabbitQueueBase

__all__ = [
    "QUEUE_NAME",
    "RabbitLabelingQueue",
    "StrictLabelingTaskValidation",
    "LenientLabelingTaskValidation",
    "NegativeReviewsFirstPolicy",
    "SourcePriorityPolicy",
    "FifoOrder",
    "PriorityOrder",
]


class RabbitLabelingQueue(RabbitQueueBase):
    """Очередь задач разметки на сервере RabbitMQ."""

    DEFAULT_MAX_LENGTH = 10_000

    def __init__(
        self,
        *,
        order: DeliveryOrderStrategy | None = None,
        validation: ValidationStrategy | None = None,
        overflow: OverflowStrategy | None = None,
        max_length: int | None = DEFAULT_MAX_LENGTH,
    ) -> None:
        super().__init__(
            QUEUE_NAME,
            order=PriorityOrder(NegativeReviewsFirstPolicy()) if order is None else order,
            validation=StrictLabelingTaskValidation() if validation is None else validation,
            overflow=overflow,
            max_length=max_length,
        )
