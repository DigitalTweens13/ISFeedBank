"""Компонент exchange_manager над RabbitMQ — маршрутизатор сообщений.

Объявляет на сервере обмены и привязки очередей, а для каждого
опубликованного сообщения решает, в какой обмен и с каким ключом его
отправить (связи 3 → 4 и 8 → 9).

Стратегия ``RabbitRoutingStrategy`` определяет обмен, его тип, ключи
привязки и ключ маршрутизации:

* ``DirectRouting`` (по умолчанию, допущение отчёта) — обмен
  ``feedback.direct``, ключ = имя очереди;
* ``TopicRouting`` — обмен ``feedback.topic``, ключ уточняется полями
  сообщения (например, ``reviews.labeling.api_batch`` или
  ``cases.events.critical``), привязки по шаблону ``<очередь>.#``.
  Это позволяет позже подключать очереди, которые слушают только часть
  сообщений (например, только критичные обращения).

Все зарегистрированные стратегии объявляются на сервере заранее,
поэтому переключение между ними во время работы не требует изменения
топологии.

Стратегия ``RabbitUnroutablePolicy`` решает, что делать, если очереди
для ключа нет: ``RaiseOnUnroutable`` (по умолчанию) или ``DiscardUnroutable``.
"""

from __future__ import annotations

import logging
import threading
from abc import ABC, abstractmethod
from typing import Any, Iterable, Mapping

from ..core import BrokerError, Message, UnroutableMessageError
from .contracts import AmqpChannelLike, PublishTarget, ServerQueue

logger = logging.getLogger(__name__)


# --------------------------------------------------------------------------
# Стратегии маршрутизации
# --------------------------------------------------------------------------
class RabbitRoutingStrategy(ABC):
    """Как сообщения попадают из обмена в очереди на сервере."""

    exchange: str
    exchange_type: str

    @abstractmethod
    def binding_key(self, queue_name: str) -> str:
        """Ключ, которым очередь привязывается к обмену."""

    @abstractmethod
    def routing_key(self, message: Message) -> str:
        """Ключ, с которым сообщение публикуется в обмен."""

    def declare(self, channel: AmqpChannelLike, queues: Iterable[ServerQueue]) -> None:
        channel.exchange_declare(exchange=self.exchange, exchange_type=self.exchange_type, durable=True)
        for queue in queues:
            channel.queue_bind(queue=queue.name, exchange=self.exchange, routing_key=self.binding_key(queue.name))

    def __repr__(self) -> str:
        return f"{type(self).__name__}(exchange={self.exchange!r})"


class DirectRouting(RabbitRoutingStrategy):
    """Точечный обмен: ключ маршрутизации совпадает с именем очереди."""

    exchange_type = "direct"

    def __init__(self, exchange: str = "feedback.direct") -> None:
        self.exchange = exchange

    def binding_key(self, queue_name: str) -> str:
        return queue_name

    def routing_key(self, message: Message) -> str:
        return message.routing_key


class TopicRouting(RabbitRoutingStrategy):
    """Тематический обмен: к ключу добавляются значения полей сообщения.

    ``qualifiers`` — какие поля тела брать для каждой очереди. Например,
    ``{"cases.events": ["severity"]}`` даёт ключ ``cases.events.critical``.
    """

    exchange_type = "topic"

    DEFAULT_QUALIFIERS: Mapping[str, tuple[str, ...]] = {
        "reviews.labeling": ("source",),
        "cases.events": ("severity",),
    }

    def __init__(self, exchange: str = "feedback.topic",
                 qualifiers: Mapping[str, Iterable[str]] | None = None) -> None:
        self.exchange = exchange
        source = self.DEFAULT_QUALIFIERS if qualifiers is None else qualifiers
        self._qualifiers = {k: tuple(v) for k, v in source.items()}

    def binding_key(self, queue_name: str) -> str:
        return f"{queue_name}.#"

    def routing_key(self, message: Message) -> str:
        parts = [message.routing_key]
        for field_name in self._qualifiers.get(message.routing_key, ()):
            value = message.body.get(field_name)
            parts.append(_safe_word(value) if value is not None else "none")
        return ".".join(parts)


def _safe_word(value: Any) -> str:
    """Значение поля как одно «слово» ключа: без точек и пробелов."""
    text = str(value).strip().lower().replace(".", "_").replace(" ", "_")
    return text or "none"


# --------------------------------------------------------------------------
# Стратегии для немаршрутизируемых сообщений
# --------------------------------------------------------------------------
class RabbitUnroutablePolicy(ABC):
    """Что делать, если для логического ключа сообщения нет очереди."""

    @abstractmethod
    def handle(self, message: Message) -> list[PublishTarget]:
        ...


class RaiseOnUnroutable(RabbitUnroutablePolicy):
    def handle(self, message: Message) -> list[PublishTarget]:
        raise UnroutableMessageError(f"Нет очереди для ключа «{message.routing_key}»")


class DiscardUnroutable(RabbitUnroutablePolicy):
    def handle(self, message: Message) -> list[PublishTarget]:
        logger.warning("Сообщение %s с ключом %s отброшено — нет очереди", message.message_id, message.routing_key)
        return []


# --------------------------------------------------------------------------
# Компонент
# --------------------------------------------------------------------------
class RabbitExchangeManager:
    """Маршрутизатор над RabbitMQ. Реализует протокол ``PublishRouter``."""

    def __init__(
        self,
        routing: RabbitRoutingStrategy | None = None,
        *,
        alternatives: Iterable[RabbitRoutingStrategy] = (),
        unroutable_policy: RabbitUnroutablePolicy | None = None,
    ) -> None:
        self._routing = routing if routing is not None else DirectRouting()
        self._strategies: list[RabbitRoutingStrategy] = [self._routing]
        for strategy in alternatives:
            self.register_strategy(strategy)
        self._unroutable = unroutable_policy if unroutable_policy is not None else RaiseOnUnroutable()
        self._queues: dict[str, ServerQueue] = {}
        self._lock = threading.RLock()

    # ------------------------------------------------------------------
    @property
    def routing_strategy(self) -> RabbitRoutingStrategy:
        return self._routing

    @property
    def strategies(self) -> tuple[RabbitRoutingStrategy, ...]:
        return tuple(self._strategies)

    def register_strategy(self, strategy: RabbitRoutingStrategy) -> None:
        """Добавляет стратегию, которую можно будет включить на лету.
        После регистрации нужно вызвать ``declare`` ещё раз."""
        with_same_name = [s for s in self._strategies if s.exchange == strategy.exchange]
        if with_same_name and with_same_name[0].exchange_type != strategy.exchange_type:
            raise BrokerError(f"Обмен «{strategy.exchange}» уже используется с типом {with_same_name[0].exchange_type}")
        if strategy not in self._strategies:
            self._strategies.append(strategy)

    def set_routing_strategy(self, strategy: RabbitRoutingStrategy) -> None:
        """Переключает маршрутизацию. Стратегия должна быть зарегистрирована
        и объявлена на сервере (``declare``)."""
        with self._lock:
            if strategy not in self._strategies:
                raise BrokerError(
                    f"{strategy!r} не зарегистрирована: передайте её в alternatives или register_strategy"
                )
            self._routing = strategy
        logger.info("Маршрутизация -> %r", strategy)

    def set_unroutable_policy(self, policy: RabbitUnroutablePolicy) -> None:
        with self._lock:
            self._unroutable = policy

    # ------------------------------------------------------------------
    def bind_queue(self, queue: ServerQueue) -> None:
        """Регистрирует очередь; на сервере она привяжется при ``declare``."""
        with self._lock:
            self._queues[queue.name] = queue

    def queues(self) -> tuple[ServerQueue, ...]:
        with self._lock:
            return tuple(self._queues.values())

    def declare(self, channel: AmqpChannelLike) -> None:
        """Объявляет на сервере очереди, все обмены и привязки (идемпотентно)."""
        queues = self.queues()
        for queue in queues:
            queue.declare(channel)
        for strategy in self._strategies:
            strategy.declare(channel, queues)
        logger.info("Топология объявлена: обмены %s, очереди %s",
                    [s.exchange for s in self._strategies], [q.name for q in queues])

    # ------------------------------------------------------------------
    def plan(self, message: Message) -> list[PublishTarget]:
        """Связь 3 → 4 / 8 → 9: куда и с каким приоритетом отправить сообщение."""
        with self._lock:
            queue = self._queues.get(message.routing_key)
            routing, unroutable = self._routing, self._unroutable
        if queue is None:
            return unroutable.handle(message)
        priority = queue.prepare(message)  # валидация и приоритет — решение очереди
        return [PublishTarget(queue=queue.name, exchange=routing.exchange,
                              routing_key=routing.routing_key(message), priority=priority)]
