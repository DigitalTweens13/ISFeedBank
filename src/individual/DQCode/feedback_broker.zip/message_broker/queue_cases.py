"""Компонент queue_cases — очередь событий обращений ``cases.events``.

Хранит события «обращение создано», опубликованные воркером разметки
(связь 7), до их получения воркером фоновых задач (связи 10–11).
Сообщения в очередь кладёт маршрутизатор (связь 9).

Стратегии, применяемые очередью:

* порядок выдачи — ``FifoStorage`` по умолчанию (хронология событий);
  можно переключить на ``PriorityStorage(CriticalCasesFirstPolicy())``
  или ``PriorityStorage(NearestSlaFirstPolicy())``;
* валидация — ``CaseEventValidation`` с набором допустимых типов
  событий (по умолчанию только ``case.created``);
* переполнение — ``RejectPublishOverflow`` (по умолчанию): события
  по обращениям нельзя терять молча.

Модуль зависит только от ``message_broker.core``.
"""

from __future__ import annotations


from datetime import datetime, timezone
from typing import Any, Callable, Iterable, Mapping

from .core import (
    BaseQueue,
    FifoStorage,
    Message,
    MessageValidationError,
    OverflowStrategy,
    PriorityPolicy,
    RejectPublishOverflow,
    RequiredFieldsValidation,
    StorageStrategy,
    ValidationStrategy,
)

QUEUE_NAME = "cases.events"

EVENT_CASE_CREATED = "case.created"

SEVERITY_WEIGHTS: Mapping[str, int] = {"low": 0, "medium": 1, "high": 2, "critical": 3}


# --------------------------------------------------------------------------
# Стратегия валидации события
# --------------------------------------------------------------------------
class CaseEventValidation(RequiredFieldsValidation):
    """Схема события по обращению.

    Обязательные поля: ``event_type`` (из ``allowed_event_types``),
    ``case_id`` (str), ``review_id`` (str).
    Необязательные: ``severity`` (low/medium/high/critical),
    ``category`` (str), ``sla_due_at`` (ISO 8601).
    """

    def __init__(self, allowed_event_types: Iterable[str] = (EVENT_CASE_CREATED,)) -> None:
        super().__init__({"event_type": str, "case_id": str, "review_id": str})
        self._allowed = frozenset(allowed_event_types)
        if not self._allowed:
            raise ValueError("Нужно указать хотя бы один тип события")

    @property
    def allowed_event_types(self) -> frozenset[str]:
        return self._allowed

    def validate_extra(self, body: Mapping[str, Any]) -> None:
        if body["event_type"] not in self._allowed:
            raise MessageValidationError(
                f"Тип события «{body['event_type']}» не принимается, допустимы: {sorted(self._allowed)}"
            )
        if not body["case_id"].strip():
            raise MessageValidationError("case_id не может быть пустым")
        severity = body.get("severity")
        if severity is not None and severity not in SEVERITY_WEIGHTS:
            raise MessageValidationError(f"Неизвестная критичность «{severity}»")
        if "category" in body and not isinstance(body["category"], str):
            raise MessageValidationError("Поле «category» должно быть строкой")
        if "sla_due_at" in body:
            _parse_deadline(body["sla_due_at"])


# --------------------------------------------------------------------------
# Стратегии приоритета событий
# --------------------------------------------------------------------------
class CriticalCasesFirstPolicy(PriorityPolicy):
    """Сначала события по критичным обращениям."""

    def priority_of(self, message: Message) -> int:
        return SEVERITY_WEIGHTS.get(message.body.get("severity", ""), 0)


class NearestSlaFirstPolicy(PriorityPolicy):
    """Сначала обращения с ближайшим сроком SLA.

    Приоритет — шкала 0–5 (её понимает и RabbitMQ):
    просрочено — 5, до 4 ч — 4, до 24 ч — 3, до 72 ч — 2,
    позже — 1, срок не указан — 0.
    """

    #: (порог в часах, приоритет), по возрастанию порога
    BUCKETS: tuple[tuple[float, int], ...] = ((0, 5), (4, 4), (24, 3), (72, 2))

    def __init__(self, now: Callable[[], datetime] | None = None) -> None:
        self._now = now or (lambda: datetime.now(timezone.utc))

    def priority_of(self, message: Message) -> int:
        raw = message.body.get("sla_due_at")
        if raw is None:
            return 0
        try:
            hours_left = (_parse_deadline(raw) - self._now()).total_seconds() / 3600
        except MessageValidationError:
            return 0
        for threshold, priority in self.BUCKETS:
            if hours_left <= threshold:
                return priority
        return 1


def _parse_deadline(value: Any) -> datetime:
    if not isinstance(value, str):
        raise MessageValidationError("sla_due_at должен быть строкой ISO 8601")
    try:
        deadline = datetime.fromisoformat(value)
    except ValueError as exc:
        raise MessageValidationError(f"sla_due_at «{value}» не в формате ISO 8601") from exc
    return deadline if deadline.tzinfo else deadline.replace(tzinfo=timezone.utc)


# --------------------------------------------------------------------------
# Компонент
# --------------------------------------------------------------------------
class CaseEventsQueue(BaseQueue):
    """Очередь событий обращений ``cases.events``."""

    DEFAULT_MAX_LENGTH = 50_000

    def __init__(
        self,
        *,
        storage: StorageStrategy | None = None,
        overflow: OverflowStrategy | None = None,
        validation: ValidationStrategy | None = None,
        max_length: int | None = DEFAULT_MAX_LENGTH,
    ) -> None:
        super().__init__(
            QUEUE_NAME,
            storage=FifoStorage() if storage is None else storage,
            overflow=RejectPublishOverflow() if overflow is None else overflow,
            validation=CaseEventValidation() if validation is None else validation,
            max_length=max_length,
        )
