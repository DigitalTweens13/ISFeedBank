"""Воркер фоновых задач — отдельный процесс, работающий через RabbitMQ.

Забирает события «обращение создано» из cases.events (связи 10–11)
и назначает ответственного и срок SLA.

    python background_worker.py          # работает, пока не нажать Ctrl+C
"""

from __future__ import annotations

import logging
import sys

from message_broker.core import BrokerError
from message_broker.rabbitmq import build_rabbit_broker
from message_broker.rabbitmq.assembly import BACKGROUND_WORKER
from process_reviews import OWNERS


def main() -> None:
    logging.basicConfig(level=logging.WARNING, format="  [log] %(message)s")
    logging.getLogger("pika").setLevel(logging.CRITICAL)  # внутренний журнал pika не нужен: о повторах сообщает наш слой
    broker = build_rabbit_broker()
    broker.setup()
    channel = broker.connect(BACKGROUND_WORKER).channel()

    def on_event(ch, delivery):
        e = delivery.body
        owner = OWNERS.get(e.get("category", "other"), OWNERS["other"])
        print(f"✓ {e['case_id']:<12} {e.get('severity', '-'):<8} → {owner}, срок до {e.get('sla_due_at', '-')}")

    channel.basic_consume("cases.events", on_event)
    print("Воркер фоновых задач ждёт события из cases.events (Ctrl+C — выход)")
    try:
        channel.start_consuming()
    except KeyboardInterrupt:
        print("\nОстановка.")
    finally:
        broker.shutdown()


if __name__ == "__main__":
    try:
        main()
    except BrokerError as exc:
        sys.exit(f"Ошибка: {exc}")
