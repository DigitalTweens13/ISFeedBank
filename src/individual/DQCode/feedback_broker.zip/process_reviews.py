"""Прогон своих отзывов через брокер.

Запуск:
    python process_reviews.py                      # пример sample_reviews.csv
    python process_reviews.py мои_отзывы.csv       # свой файл
    python process_reviews.py мои_отзывы.csv --fifo   # без приоритета негатива

Формат CSV (разделитель «;» или «,», кодировка UTF-8 или Windows-1251):
    review_id;text;rating;channel
Обязательны review_id и text; rating (1–5) и channel — по желанию.

Что происходит:
    1. Backend API публикует каждую строку как задачу разметки (связи 1–4).
    2. Воркер разметки забирает задачи (5–6), определяет тональность
       и категорию и для негативных отзывов публикует событие
       «обращение создано» (7–9).
    3. Воркер фоновых задач забирает события (10–11), назначает
       ответственного и срок SLA.
Результат печатается и сохраняется в results.csv.

Разметка здесь простая, по ключевым словам: настоящая модель — зона
воркера разметки, а не брокера.
"""

from __future__ import annotations

import argparse
import csv
import sys
from datetime import datetime, timedelta
from pathlib import Path

from message_broker import build_feedback_broker
from message_broker.assembly import API_BACKEND, BACKGROUND_WORKER, LABELING_WORKER
from message_broker.core import BrokerError, FifoStorage
from message_broker.queue_labeling import SOURCE_API_BATCH

CATEGORIES = {
    "fraud": ("мошен", "украл", "взлом", "без моего"),
    "fees": ("комисси", "списал", "ставк", "тариф"),
    "support": ("поддержк", "дозвон", "оператор", "ответ"),
    "app": ("приложени", "вылета", "обновлен", "вход"),
}
NEGATIVE_WORDS = ("не могу", "верните", "мошен", "вылета", "ужас", "опоздал", "выше обещанной")
OWNERS = {"fraud": "Служба безопасности", "fees": "Отдел тарифов", "support": "Контакт-центр",
          "app": "Команда мобильного приложения", "other": "Отдел качества"}
SLA_HOURS = {"critical": 4, "high": 24, "medium": 72}


# --------------------------------------------------------------------------
def read_reviews(path: Path) -> list[dict]:
    raw = path.read_bytes()
    for encoding in ("utf-8-sig", "cp1251"):
        try:
            text = raw.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    else:
        sys.exit(f"Не удалось определить кодировку файла {path}")
    delimiter = ";" if text.splitlines()[0].count(";") >= text.splitlines()[0].count(",") else ","
    return list(csv.DictReader(text.splitlines(), delimiter=delimiter))


def to_task(row: dict) -> dict:
    task = {"review_id": (row.get("review_id") or "").strip(),
            "text": (row.get("text") or "").strip(),
            "source": SOURCE_API_BATCH}
    rating = (row.get("rating") or "").strip()
    if rating:
        task["rating"] = int(rating) if rating.lstrip("-").isdigit() else rating
    if row.get("channel"):
        task["channel"] = row["channel"].strip()
    return task


def label(review: dict) -> tuple[str, str]:
    """Простая разметка: тональность и категория."""
    text = review["text"].lower()
    category = next((c for c, words in CATEGORIES.items() if any(w in text for w in words)), "other")
    rating = review.get("rating")
    if isinstance(rating, int):
        sentiment = "negative" if rating <= 2 else "neutral" if rating == 3 else "positive"
    else:
        sentiment = "negative" if any(w in text for w in NEGATIVE_WORDS) else "neutral"
    if sentiment == "neutral" and any(w in text for w in NEGATIVE_WORDS):
        sentiment = "negative"
    return sentiment, category


def severity_of(review: dict, category: str) -> str:
    if category == "fraud" or review.get("rating") == 1:
        return "critical"
    return "high" if review.get("rating") == 2 else "medium"


# --------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(description="Прогон отзывов из CSV через брокер сообщений")
    parser.add_argument("file", nargs="?", default="sample_reviews.csv")
    parser.add_argument("--fifo", action="store_true", help="выдавать задачи по порядку, без приоритета негатива")
    parser.add_argument("--out", default="results.csv")
    args = parser.parse_args()

    path = Path(args.file)
    if not path.exists():
        sys.exit(f"Файл не найден: {path.resolve()}")
    rows = read_reviews(path)

    broker = build_feedback_broker()
    if args.fifo:
        broker.labeling_queue.set_storage_strategy(FifoStorage())

    api = broker.connect(API_BACKEND).channel()
    labeling = broker.connect(LABELING_WORKER).channel()
    background = broker.connect(BACKGROUND_WORKER).channel()

    results: dict[str, dict] = {}

    # --- Цепочка 1: Backend API публикует задачи ----------------------------
    print(f"Файл: {path.name}, строк: {len(rows)}\n")
    print("1) Backend API публикует задачи разметки")
    for n, row in enumerate(rows, start=1):
        task = to_task(row)
        rid = task["review_id"] or f"строка {n}"
        try:
            api.basic_publish("reviews.labeling", task)
            results[rid] = {"review_id": rid, "text": task["text"], "rating": task.get("rating", ""),
                            "status": "в очереди"}
        except BrokerError as exc:
            results[rid] = {"review_id": rid, "text": task["text"], "rating": task.get("rating", ""),
                            "status": f"отклонён брокером: {exc}"}
            print(f"   ✗ {rid}: {exc}")
    print(f"   принято в reviews.labeling: {len(broker.labeling_queue)}\n")

    # --- Цепочка 1→2: воркер разметки ---------------------------------------
    print("2) Воркер разметки обрабатывает задачи (порядок выдачи — по стратегии очереди)")

    def on_task(channel, delivery):
        review = delivery.body
        sentiment, category = label(review)
        row = results[review["review_id"]]
        row.update(sentiment=sentiment, category=category, status="размечен")
        print(f"   {review['review_id']}  оценка={review.get('rating', '-')}  {sentiment:<8} {category}")
        if sentiment == "negative":
            severity = severity_of(review, category)
            due = datetime.now().astimezone() + timedelta(hours=SLA_HOURS[severity])
            channel.basic_publish("cases.events", {
                "event_type": "case.created",
                "case_id": f"case-{review['review_id']}",
                "review_id": review["review_id"],
                "category": category,
                "severity": severity,
                "sla_due_at": due.isoformat(timespec="minutes"),
            })

    labeling.basic_consume("reviews.labeling", on_task)
    labeling.drain_events()
    print(f"   событий в cases.events: {len(broker.cases_queue)}\n")

    # --- Цепочка 2: воркер фоновых задач ------------------------------------
    print("3) Воркер фоновых задач заводит обращения")
    while (delivery := background.basic_get("cases.events")) is not None:
        e = delivery.body
        owner = OWNERS[e["category"]]
        results[e["review_id"]].update(case_id=e["case_id"], severity=e["severity"], owner=owner,
                                       sla_due_at=e["sla_due_at"], status="заведено обращение")
        print(f"   {e['case_id']:<11} {e['severity']:<8} → {owner}, срок до {e['sla_due_at']}")
        background.basic_ack(delivery.delivery_tag)

    # --- Итоги --------------------------------------------------------------
    fields = ["review_id", "text", "rating", "sentiment", "category", "status",
              "case_id", "severity", "owner", "sla_due_at"]
    with open(args.out, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields, delimiter=";", extrasaction="ignore")
        writer.writeheader()
        writer.writerows(results.values())

    print("\nИтог по очередям:")
    for q in (broker.labeling_queue, broker.cases_queue):
        s = q.stats()
        print(f"   {s.name:<17} принято {s.published}, выдано {s.delivered}, подтверждено {s.acked}, "
              f"осталось {s.ready}, dead letter {s.dead_lettered}")
    print(f"\nРезультат сохранён в {Path(args.out).resolve()} (открывается в Excel)")
    broker.shutdown()


if __name__ == "__main__":
    main()
