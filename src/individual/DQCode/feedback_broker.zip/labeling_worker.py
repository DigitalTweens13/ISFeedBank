"""Воркер разметки — отдельный процесс, работающий через RabbitMQ.

Забирает задачи из reviews.labeling (связи 5–6), размечает отзыв и для
негативных публикует событие «обращение создано» в cases.events (7–9).

    python labeling_worker.py            # работает, пока не нажать Ctrl+C
    python labeling_worker.py --slow 2   # 2 секунды на задачу — удобно смотреть в панели

Можно запустить несколько копий: сервер поделит задачи между ними.
Разметка — простая, по ключевым словам (настоящая модель — не часть брокера).
"""

from __future__ import annotations

import argparse
import logging
import sys
import time
from datetime import datetime, timedelta

from message_broker.core import BrokerError
from message_broker.rabbitmq import build_rabbit_broker
from message_broker.rabbitmq.assembly import LABELING_WORKER
from process_reviews import SLA_HOURS, label, severity_of


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--slow", type=float, default=0.0, help="пауза на задачу, секунд")
    parser.add_argument("--fail", action="store_true", help="падать на каждой задаче (демонстрация повторов и dead letter)")
    args = parser.parse_args()
    logging.basicConfig(level=logging.WARNING, format="  [log] %(message)s")
    logging.getLogger("pika").setLevel(logging.CRITICAL)  # внутренний журнал pika не нужен: о повторах сообщает наш слой

    broker = build_rabbit_broker()
    broker.setup()
    channel = broker.connect(LABELING_WORKER).channel()

    def on_task(ch, delivery):
        review = delivery.body
        mark = " (повторно)" if delivery.redelivered else ""
        if args.fail:
            print(f"✗ {review.get('review_id')}: имитация сбоя, попытка {delivery.message.delivery_count + 1}{mark}")
            raise RuntimeError("модель разметки недоступна")
        if args.slow:
            time.sleep(args.slow)
        sentiment, category = label(review)
        print(f"✓ {review['review_id']:<8} оценка={review.get('rating', '-')}  {sentiment:<8} {category}{mark}")
        if sentiment == "negative":
            severity = severity_of(review, category)
            due = datetime.now().astimezone() + timedelta(hours=SLA_HOURS[severity])
            ch.basic_publish("cases.events", {
                "event_type": "case.created",
                "case_id": f"case-{review['review_id']}",
                "review_id": review["review_id"],
                "category": category,
                "severity": severity,
                "sla_due_at": due.isoformat(timespec="minutes"),
            })
            print(f"    → событие «обращение создано» ({severity})")

    channel.basic_consume("reviews.labeling", on_task)
    print("Воркер разметки ждёт задачи из reviews.labeling (Ctrl+C — выход)")
    try:
        channel.start_consuming()
    except KeyboardInterrupt:
        print("\nОстановка. Неподтверждённые задачи сервер вернёт в очередь.")
    finally:
        broker.shutdown()


if __name__ == "__main__":
    try:
        main()
    except BrokerError as exc:
        sys.exit(f"Ошибка: {exc}")
