"""Пошаговая демонстрация брокера на настоящем RabbitMQ (для защиты).

    docker compose up -d                 # сервер
    python show_rabbit.py                # Enter — следующий шаг
    python show_rabbit.py --no-pause     # всё сразу (без шага с перезапуском сервера)

Параллельно откройте панель http://localhost:15672 (feedback / feedback),
вкладку Queues: там видно, как меняются сообщения в очередях.

ВНИМАНИЕ: в начале очереди удаляются и создаются заново (чистый старт).
"""

from __future__ import annotations

import argparse
import logging
import time
from dataclasses import replace

from message_broker.core import AccessDeniedError, BrokerError
from message_broker.rabbitmq import build_rabbit_broker
from message_broker.rabbitmq.assembly import API_BACKEND, BACKGROUND_WORKER, LABELING_WORKER
from message_broker.rabbitmq.connection_handler import ExponentialBackoff, RabbitSettings
from message_broker.rabbitmq.contracts import FifoOrder, PriorityOrder
from message_broker.rabbitmq.queue_labeling import NegativeReviewsFirstPolicy

PAUSE = True
STEP = 0

TASKS = [
    {"review_id": "r-1", "text": "Всё отлично, спасибо", "rating": 5, "source": "api_batch"},
    {"review_id": "r-2", "text": "Списали комиссию без предупреждения", "rating": 1, "source": "api_batch"},
    {"review_id": "r-3", "text": "Приложение тормозит", "rating": 3, "source": "api_batch"},
]


def step(title: str, links: str = "") -> None:
    global STEP
    STEP += 1
    if PAUSE:
        input("\n[Enter — следующий шаг] ")
    suffix = f"   (связи {links})" if links else ""
    print(f"\n{'=' * 72}\nШАГ {STEP}. {title}{suffix}\n{'=' * 72}")


def state(broker) -> None:
    time.sleep(0.3)  # дать серверу обновить счётчики
    print("\n  На сервере RabbitMQ:")
    for info in broker.stats():
        print(f"    {info.name:<24} ждут выдачи: {info.ready:<4} подписчиков: {info.consumers}")


def drain_ratings(channel, queue: str) -> list:
    out = []
    while (d := channel.basic_get(queue, auto_ack=True)) is not None:
        out.append(d.body.get("rating"))
    return out


def label_and_publish(ch, review: dict) -> None:
    """Работа воркера разметки: негативный отзыв → событие «обращение создано» (связь 7)."""
    if review.get("rating", 3) <= 2:
        ch.basic_publish("cases.events", {"event_type": "case.created", "case_id": f"case-{review['review_id']}",
                                          "review_id": review["review_id"],
                                          "severity": "critical" if review["rating"] == 1 else "high"})
        print(f"  {review['review_id']} (оценка {review['rating']}): негатив → событие в cases.events")
    else:
        print(f"  {review['review_id']} (оценка {review['rating']}): обращение не нужно")


def main() -> None:
    global PAUSE
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-pause", action="store_true")
    args = parser.parse_args()
    PAUSE = not args.no_pause
    logging.basicConfig(level=logging.ERROR, format="  [log] %(message)s")
    logging.getLogger("pika").setLevel(logging.CRITICAL)  # внутренний журнал pika не нужен: о повторах сообщает наш слой

    # ------------------------------------------------------------------
    step("Подключение к серверу и объявление топологии")
    # heartbeat=0: пока вы рассказываете между шагами, сервер не закроет «молчащие» соединения
    settings = replace(RabbitSettings.from_env(), heartbeat=0)
    broker = build_rabbit_broker(settings=settings, reconnect=ExponentialBackoff(attempts=6))
    s = broker.connection_handler.settings
    print(f"  Сервер: {s.host}:{s.port}, панель: http://{s.host}:15672 (feedback / feedback)")
    broker.reset()
    broker.setup()
    print("  Маршрутизатор объявил обмены: feedback.direct (direct), feedback.topic (topic), feedback.dlx")
    for q in (broker.labeling_queue, broker.cases_queue):
        print(f"  Очередь {q.name}: {q.arguments()}")
    api = broker.connect(API_BACKEND).channel()
    bg = broker.connect(BACKGROUND_WORKER).channel()
    lab_conn = broker.connect(LABELING_WORKER)
    lab = lab_conn.channel()
    print("\n  Подключены три контейнера — в панели на вкладке Connections видны их имена:")
    print(f"     {API_BACKEND}, {LABELING_WORKER}, {BACKGROUND_WORKER}")
    state(broker)

    # ------------------------------------------------------------------
    step("Backend API и воркер фоновых задач публикуют задачи", "1, 2 → 3 → 4")
    for t in TASKS:
        api.basic_publish("reviews.labeling", t)
        print(f"  Backend API → {t['review_id']} (оценка {t['rating']})")
    bg.basic_publish("reviews.labeling", {"review_id": "r-4", "text": "Не дозвониться в поддержку",
                                          "rating": 2, "source": "collector"})
    print("  Воркер фоновых задач → r-4 (оценка 2)")
    try:
        api.basic_publish("reviews.labeling", {"review_id": "r-5", "text": ""})
    except BrokerError as exc:
        print(f"  Backend API → r-5 ОТКЛОНЕНО до отправки на сервер: {exc}")
    state(broker)

    # ------------------------------------------------------------------
    step("Права по диаграмме: Backend API пытается писать в cases.events")
    try:
        api.basic_publish("cases.events", {"event_type": "case.created", "case_id": "x", "review_id": "x"})
    except AccessDeniedError as exc:
        print(f"  ОТКАЗ: {exc}")

    # ------------------------------------------------------------------
    step("Воркер разметки забирает задачу, размечает и подтверждает", "5 → 6, 7 → 8 → 9")
    d = lab.basic_get("reviews.labeling")
    print(f"  Сервер выдал {d.body['review_id']} (оценка {d.body['rating']}) — первым самый негативный отзыв")
    print("  Пока нет ack, в панели у очереди Unacked = 1")
    if PAUSE:
        input("  [Enter — разметить и отправить ack] ")
    label_and_publish(lab, d.body)
    lab.basic_ack(d.delivery_tag)
    print("  ack отправлен — сервер удалил задачу")
    state(broker)

    # ------------------------------------------------------------------
    step("Надёжность: воркер взял задачу и упал без подтверждения", "5 → 6")
    d = lab.basic_get("reviews.labeling")
    print(f"  Выдана {d.body['review_id']}")
    state(broker)
    print("\n  !!! Соединение воркера разорвано")
    lab_conn.close()
    state(broker)
    lab_conn = broker.connect(LABELING_WORKER)
    lab = lab_conn.channel()
    again = lab.basic_get("reviews.labeling")
    print(f"  Новый воркер получил ту же задачу {again.body['review_id']}, повторная доставка: {again.redelivered}")
    label_and_publish(lab, again.body)
    lab.basic_ack(again.delivery_tag)
    state(broker)

    # ------------------------------------------------------------------
    step("Воркер разметки обрабатывает остальные задачи (подписка)", "5 → 6, 7 → 8 → 9")

    tag = lab.basic_consume("reviews.labeling", lambda ch, delivery: label_and_publish(ch, delivery.body))
    lab.start_consuming(inactivity_timeout=1)
    lab.basic_cancel(tag)
    state(broker)

    # ------------------------------------------------------------------
    step("Воркер фоновых задач забирает события", "10 → 11")
    while (d := bg.basic_get("cases.events")) is not None:
        print(f"  {d.body['case_id']} [{d.body['severity']}] от {d.message.publisher_id} → назначить ответственного, ack")
        bg.basic_ack(d.delivery_tag)
    state(broker)

    # ------------------------------------------------------------------
    step("Стратегия подтверждения: обработчик падает → 3 попытки → dead letter")
    api.basic_publish("reviews.labeling", {"review_id": "r-bad", "text": "битая задача", "source": "api_batch"})

    def failing(ch, delivery):
        print(f"  попытка {delivery.message.delivery_count + 1}: ошибка обработки")
        raise RuntimeError("модель недоступна")

    tag = lab.basic_consume("reviews.labeling", failing)
    lab.start_consuming(inactivity_timeout=1)
    lab.basic_cancel(tag)
    print("  Задача не потерялась и не крутится вечно — она в reviews.labeling.dlq")
    state(broker)

    # ------------------------------------------------------------------
    step("Стратегия порядка выдачи: смена на лету")
    for label, order in (("Негатив первым", PriorityOrder(NegativeReviewsFirstPolicy())), ("FIFO", FifoOrder())):
        broker.labeling_queue.set_order_strategy(order)
        for i, r in enumerate([5, 1, 4, 2]):
            api.basic_publish("reviews.labeling", {"review_id": f"s-{i}", "text": "…", "rating": r,
                                                   "source": "api_batch"})
        time.sleep(0.3)
        print(f"  {label:<16} отправлено [5, 1, 4, 2] → сервер выдал {drain_ratings(lab, 'reviews.labeling')}")
    broker.labeling_queue.set_order_strategy(PriorityOrder(NegativeReviewsFirstPolicy()))
    print("  Очередь на сервере та же — сменилась только стратегия в нашем компоненте.")

    # ------------------------------------------------------------------
    step("Стратегия маршрутизации: direct → topic на лету")
    broker.exchange_manager.set_routing_strategy(broker.topic_routing)
    api.basic_publish("reviews.labeling", {"review_id": "t-1", "text": "…", "source": "api_batch"})
    print("  Сообщение ушло в обмен feedback.topic с ключом reviews.labeling.api_batch")
    print("  и попало в очередь по привязке reviews.labeling.# (видно в панели: Exchanges → feedback.topic)")
    lab.basic_get("reviews.labeling", auto_ack=True)
    broker.exchange_manager.set_routing_strategy(broker.direct_routing)

    # ------------------------------------------------------------------
    if PAUSE:
        step("Сохранность: сообщения переживают перезапуск сервера")
        for i in range(3):
            api.basic_publish("reviews.labeling", {"review_id": f"p-{i}", "text": "сохранится", "source": "api_batch"})
        state(broker)
        print("\n  Перезапустите сервер в другом окне:  docker compose restart rabbitmq")
        input("  [Enter — когда перезапуск завершится] ")
        print("  Переподключение...")
        state(broker)
        print("  3 сообщения на месте: очереди durable, сообщения persistent.")
        lab = broker.connect(LABELING_WORKER).channel()
        while lab.basic_get("reviews.labeling", auto_ack=True) is not None:
            pass

    # ------------------------------------------------------------------
    step("Итог")
    state(broker)
    print("\n  Рабочие очереди пусты, сбойная задача сохранена в dead letter.")
    broker.shutdown()


if __name__ == "__main__":
    main()
