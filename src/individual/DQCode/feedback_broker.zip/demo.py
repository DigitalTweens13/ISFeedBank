"""Демонстрация двух цепочек из отчёта и смены стратегий во время работы.

Запуск: python demo.py
"""

from __future__ import annotations

import logging

from message_broker import build_feedback_broker
from message_broker.assembly import API_BACKEND, BACKGROUND_WORKER, LABELING_WORKER
from message_broker.connection_handler import AutoAck, ManualAck
from message_broker.core import AccessDeniedError, MessageValidationError
from message_broker.core import FifoStorage, PriorityStorage
from message_broker.exchange_manager import TopicRoutingStrategy
from message_broker.queue_cases import CriticalCasesFirstPolicy
from message_broker.queue_labeling import SOURCE_API_BATCH, SOURCE_COLLECTOR, LenientLabelingTaskValidation


def title(text: str) -> None:
    print(f"\n=== {text} ===")


def main() -> None:
    logging.basicConfig(level=logging.WARNING, format="  [log] %(message)s")
    broker = build_feedback_broker()

    api = broker.connect(API_BACKEND).channel()
    labeling = broker.connect(LABELING_WORKER).channel()
    background = broker.connect(BACKGROUND_WORKER).channel()

    # ------------------------------------------------------------------
    title("Цепочка 1: публикация задач разметки (связи 1–4)")
    batch = [
        {"review_id": "r-1", "text": "Всё отлично, спасибо", "rating": 5},
        {"review_id": "r-2", "text": "Списали комиссию без предупреждения", "rating": 1},
        {"review_id": "r-3", "text": "Нормально, но приложение тормозит", "rating": 3},
    ]
    for review in batch:
        queues = api.basic_publish("reviews.labeling", {**review, "source": SOURCE_API_BATCH, "batch_id": "b-42"})
        print(f"Backend API -> {review['review_id']} попал в {queues}")
    background.basic_publish(
        "reviews.labeling",
        {"review_id": "r-4", "text": "Не могу дозвониться в поддержку", "rating": 2, "source": SOURCE_COLLECTOR},
    )
    print("Воркер фоновых задач -> r-4")
    print(f"В reviews.labeling: {len(broker.labeling_queue)} задач (порядок — сначала негатив)")

    # ------------------------------------------------------------------
    title("Цепочка 1→2: воркер разметки забирает задачи и публикует события (связи 5–9)")

    def label_review(channel, delivery):
        review = delivery.body
        sentiment = "negative" if review.get("rating", 3) <= 2 else "other"
        print(f"  разметка {review['review_id']} (оценка {review.get('rating')}): {sentiment}")
        if sentiment == "negative":
            severity = "critical" if review["rating"] == 1 else "high"
            channel.basic_publish(
                "cases.events",
                {"event_type": "case.created", "case_id": f"c-{review['review_id']}",
                 "review_id": review["review_id"], "severity": severity},
            )

    labeling.basic_qos(prefetch_count=1)
    labeling.basic_consume("reviews.labeling", label_review)
    print(f"Обработано задач: {labeling.drain_events()}")

    # ------------------------------------------------------------------
    title("Цепочка 2: воркер фоновых задач забирает события (связи 10–11)")
    while (delivery := background.basic_get("cases.events")) is not None:
        print(f"  событие {delivery.body['event_type']} по {delivery.body['case_id']} "
              f"({delivery.body['severity']}) — назначить владельца, запустить SLA")
        background.basic_ack(delivery.delivery_tag)

    # ------------------------------------------------------------------
    title("Права по диаграмме")
    try:
        api.basic_publish("cases.events", {"event_type": "case.created", "case_id": "x", "review_id": "x"})
    except AccessDeniedError as exc:
        print(f"Отказ: {exc}")

    # ------------------------------------------------------------------
    title("Стратегия: смена порядка выдачи очереди на лету")
    broker.labeling_queue.set_storage_strategy(FifoStorage())
    for i, rating in enumerate([5, 1, 4], start=10):
        api.basic_publish("reviews.labeling", {"review_id": f"r-{i}", "text": "…", "rating": rating, "source": SOURCE_API_BATCH})
    order = []
    while (d := labeling.basic_get("reviews.labeling", auto_ack=True)) is not None:
        order.append(d.body["rating"])
    print(f"FIFO: оценки в порядке выдачи {order}")

    title("Стратегия: валидация")
    try:
        api.basic_publish("reviews.labeling", {"review_id": "r-20", "text": "Без источника"})
    except MessageValidationError as exc:
        print(f"Строгая схема: {exc}")
    broker.labeling_queue.set_validation_strategy(LenientLabelingTaskValidation())
    api.basic_publish("reviews.labeling", {"review_id": "r-20", "text": "Без источника"})
    print("Мягкая схема: принято")
    labeling.basic_get("reviews.labeling", auto_ack=True)

    title("Стратегия: критичные обращения первыми")
    broker.cases_queue.set_storage_strategy(PriorityStorage(CriticalCasesFirstPolicy()))
    for case_id, severity in [("c-a", "low"), ("c-b", "critical"), ("c-c", "medium")]:
        labeling.basic_publish("cases.events", {"event_type": "case.created", "case_id": case_id,
                                                "review_id": "r", "severity": severity})
    order = []
    while (d := background.basic_get("cases.events", auto_ack=True)) is not None:
        order.append(d.body["severity"])
    print(f"Порядок выдачи: {order}")

    title("Стратегия: topic-маршрутизация")
    broker.exchange_manager.set_routing_strategy(TopicRoutingStrategy())
    broker.exchange_manager.unbind_queue("cases.events")
    broker.exchange_manager.bind_queue(broker.cases_queue, binding_key="cases.#")
    queues = labeling.basic_publish("cases.events", {"event_type": "case.created", "case_id": "c-t", "review_id": "r"})
    print(f"Ключ cases.events по шаблону cases.# -> {queues}")
    background.basic_get("cases.events", auto_ack=True)

    title("Стратегия подтверждения: сбой обработчика")

    def flaky(channel, delivery):
        raise RuntimeError("модель разметки недоступна")

    broker.labeling_queue.set_validation_strategy(LenientLabelingTaskValidation())
    api.basic_publish("reviews.labeling", {"review_id": "r-30", "text": "Тест сбоя"})
    worker = broker.connect(LABELING_WORKER).channel()
    flaky_tag = worker.basic_consume("reviews.labeling", flaky)  # AckAfterProcessing: 3 попытки, затем dead letter
    worker.drain_events()
    dead = broker.labeling_queue.dead_letters()
    print(f"Ack после обработки: в dead letter {len(dead)} сообщ., причина «{dead[-1].reason}»")

    broker.connection_handler.set_ack_strategy(AutoAck())
    api.basic_publish("reviews.labeling", {"review_id": "r-31", "text": "Тест auto-ack"})
    worker.drain_events()
    print(f"Auto-ack: сообщение подтверждено до обработки и потеряно; в очереди {len(broker.labeling_queue)}")

    broker.connection_handler.set_ack_strategy(ManualAck())
    worker.basic_cancel(flaky_tag)
    api.basic_publish("reviews.labeling", {"review_id": "r-32", "text": "Тест падения воркера"})
    worker.basic_consume("reviews.labeling", lambda ch, d: None)  # не подтверждает
    worker.drain_events()
    print(f"Ручной ack: неподтверждённых {broker.labeling_queue.unacked_count}")
    worker.close()
    print(f"Канал закрыт (воркер упал): задача вернулась, в очереди {len(broker.labeling_queue)}")

    title("Статистика очередей")
    for queue in (broker.labeling_queue, broker.cases_queue):
        print(queue.stats())

    broker.shutdown()


if __name__ == "__main__":
    main()
