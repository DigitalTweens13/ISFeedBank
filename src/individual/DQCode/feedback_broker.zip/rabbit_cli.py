"""Управление брокером на настоящем RabbitMQ.

    python rabbit_cli.py setup                  объявить обмены и очереди
    python rabbit_cli.py stats                  сколько сообщений в очередях
    python rabbit_cli.py publish                опубликовать sample_reviews.csv от имени Backend API
    python rabbit_cli.py publish мои.csv        свой CSV (review_id;text;rating;channel)
    python rabbit_cli.py publish --fifo         без приоритета негатива
    python rabbit_cli.py dlq                    показать сообщения в dead letter очередях
    python rabbit_cli.py reset                  удалить очереди и обмены (с сообщениями!)

Адрес и пароль: переменные RABBITMQ_HOST, RABBITMQ_USER, RABBITMQ_PASSWORD
(по умолчанию localhost, feedback/feedback — как в docker-compose.yml).
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from message_broker.connection_handler import PermitAllPolicy
from message_broker.core import BrokerError
from message_broker.rabbitmq import build_rabbit_broker
from message_broker.rabbitmq.assembly import API_BACKEND
from message_broker.rabbitmq.connection_handler import NoRetry
from message_broker.rabbitmq.contracts import FifoOrder


def print_stats(broker) -> None:
    print(f"  {'очередь':<24}{'ждут выдачи':>12}{'подписчиков':>13}")
    for info in broker.stats():
        print(f"  {info.name:<24}{info.ready:>12}{info.consumers:>13}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Управление брокером на RabbitMQ")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("setup")
    sub.add_parser("stats")
    sub.add_parser("reset")
    sub.add_parser("dlq")
    pub = sub.add_parser("publish")
    pub.add_argument("file", nargs="?", default="sample_reviews.csv")
    pub.add_argument("--fifo", action="store_true")
    args = parser.parse_args()
    logging.basicConfig(level=logging.ERROR, format="  [log] %(message)s")
    logging.getLogger("pika").setLevel(logging.CRITICAL)  # внутренний журнал pika не нужен: о повторах сообщает наш слой

    broker = build_rabbit_broker(reconnect=NoRetry())
    try:
        if args.command == "setup":
            broker.setup()
            print("Топология объявлена:")
            print("  обмены: feedback.direct (direct), feedback.topic (topic), feedback.dlx (dead letter)")
            print("  очереди: reviews.labeling, cases.events и их .dlq")
            print_stats(broker)

        elif args.command == "stats":
            print_stats(broker)

        elif args.command == "reset":
            if input("Удалить очереди вместе с сообщениями? [y/N] ").strip().lower() != "y":
                return
            broker.reset()
            print("Удалено. Объявить заново: python rabbit_cli.py setup")

        elif args.command == "dlq":
            broker.connection_handler.set_access_policy(PermitAllPolicy())
            conn = broker.connect("admin")
            ch = conn.channel()
            for queue in (broker.labeling_queue, broker.cases_queue):
                print(f"{queue.dead_letter_queue}:")
                count = 0
                while (d := ch.basic_get(queue.dead_letter_queue)) is not None:  # без ack
                    count += 1
                    print(f"  {d.body}")
                if not count:
                    print("  (пусто)")
            conn.close()  # ничего не подтверждено — сервер вернёт всё на место

        elif args.command == "publish":
            from process_reviews import read_reviews, to_task

            path = Path(args.file)
            if not path.exists():
                sys.exit(f"Файл не найден: {path.resolve()}")
            broker.setup()
            if args.fifo:
                broker.labeling_queue.set_order_strategy(FifoOrder())
            api = broker.connect(API_BACKEND).channel()
            sent = 0
            for row in read_reviews(path):
                task = to_task(row)
                try:
                    api.basic_publish("reviews.labeling", task)
                    sent += 1
                    print(f"  → {task['review_id']} (оценка {task.get('rating', '-')})")
                except BrokerError as exc:
                    print(f"  ✗ {task.get('review_id') or '?'}: {exc}")
            print(f"Опубликовано в reviews.labeling: {sent}")
            print_stats(broker)
    except BrokerError as exc:
        sys.exit(f"Ошибка: {exc}")
    finally:
        broker.shutdown()


if __name__ == "__main__":
    main()
