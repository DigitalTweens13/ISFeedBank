"""Тесты компонентов брокера и их стратегий. Запуск: python -m pytest -q"""

from __future__ import annotations

import pytest

from message_broker import build_feedback_broker
from message_broker.assembly import API_BACKEND, BACKGROUND_WORKER, LABELING_WORKER
from message_broker.connection_handler import (
    AckAfterProcessing,
    AutoAck,
    ConnectionHandler,
    Credentials,
    ManualAck,
    PermitAllPolicy,
    SharedSecretAuthentication,
)
from message_broker.core import (
    AccessDeniedError,
    AuthenticationError,
    ConnectionClosedError,
    DropHeadOverflow,
    ExchangeConflictError,
    FifoStorage,
    Message,
    MessageValidationError,
    PriorityStorage,
    QueueOverflowError,
    UnknownDeliveryTagError,
    UnroutableMessageError,
)
from message_broker.exchange_manager import (
    AlternateQueueUnroutable,
    DirectRoutingStrategy,
    DiscardUnroutable,
    ExchangeManager,
    FanoutRoutingStrategy,
    TopicRoutingStrategy,
    topic_matches,
)
from message_broker.queue_cases import CaseEventValidation, CaseEventsQueue, CriticalCasesFirstPolicy, NearestSlaFirstPolicy
from message_broker.queue_labeling import (
    LenientLabelingTaskValidation,
    ReviewsLabelingQueue,
    SourcePriorityPolicy,
)


def task(review_id: str, rating: int | None = None, source: str = "api_batch") -> dict:
    body = {"review_id": review_id, "text": "текст отзыва", "source": source}
    if rating is not None:
        body["rating"] = rating
    return body


def event(case_id: str, **extra) -> dict:
    return {"event_type": "case.created", "case_id": case_id, "review_id": "r-1", **extra}


def msg(body: dict, key: str = "reviews.labeling", **kw) -> Message:
    return Message(body=body, routing_key=key, **kw)


# ----------------------------------------------------------------------
# Очередь reviews.labeling
# ----------------------------------------------------------------------
class TestLabelingQueue:
    def test_negative_reviews_first_by_default(self):
        q = ReviewsLabelingQueue()
        for i, rating in enumerate([5, 1, 3, 2]):
            q.put(msg(task(f"r{i}", rating)))
        assert [q.get().message.body["rating"] for _ in range(4)] == [1, 2, 3, 5]

    def test_switch_storage_keeps_messages(self):
        q = ReviewsLabelingQueue()
        q.put(msg(task("a", 5)))
        q.put(msg(task("b", 1)))
        q.set_storage_strategy(FifoStorage())
        assert len(q) == 2
        q.put(msg(task("c", 1)))
        assert [q.get().message.body["review_id"] for _ in range(3)] == ["b", "a", "c"]

    def test_source_priority_policy(self):
        q = ReviewsLabelingQueue(storage=PriorityStorage(SourcePriorityPolicy()))
        q.put(msg(task("bg", source="collector")))
        q.put(msg(task("api", source="api_batch")))
        assert q.get().message.body["review_id"] == "api"

    @pytest.mark.parametrize("body", [
        {"review_id": "r", "text": "x"},                                   # нет source
        {"review_id": "r", "text": "  ", "source": "api_batch"},          # пустой текст
        {"review_id": "r", "text": "x", "source": "unknown"},             # чужой источник
        {"review_id": "r", "text": "x", "source": "api_batch", "rating": 7},
        {"review_id": 1, "text": "x", "source": "api_batch"},             # неверный тип
    ])
    def test_strict_validation_rejects(self, body):
        with pytest.raises(MessageValidationError):
            ReviewsLabelingQueue().put(msg(body))

    def test_lenient_validation(self):
        q = ReviewsLabelingQueue(validation=LenientLabelingTaskValidation())
        q.put(msg({"review_id": 1, "text": "x"}))
        assert len(q) == 1

    def test_reject_publish_overflow(self):
        q = ReviewsLabelingQueue(max_length=1)
        q.put(msg(task("a")))
        with pytest.raises(QueueOverflowError):
            q.put(msg(task("b")))

    def test_drop_head_overflow_dead_letters_lowest_priority(self):
        q = ReviewsLabelingQueue(max_length=2, overflow=DropHeadOverflow())
        q.put(msg(task("pos", 5)))
        q.put(msg(task("neg", 1)))
        q.put(msg(task("mid", 3)))
        assert len(q) == 2
        assert q.dead_letters()[0].message.body["review_id"] == "pos"
        assert q.dead_letters()[0].reason == "overflow"

    def test_ack_nack_requeue_and_dead_letter(self):
        q = ReviewsLabelingQueue()
        q.put(msg(task("a")))
        d = q.get()
        q.nack(d.delivery_tag, requeue=True)
        d2 = q.get()
        assert d2.redelivered and d2.message.delivery_count == 1
        q.nack(d2.delivery_tag, requeue=False)
        assert len(q) == 0 and q.stats().dead_lettered == 1
        with pytest.raises(UnknownDeliveryTagError):
            q.ack(d2.delivery_tag)


# ----------------------------------------------------------------------
# Очередь cases.events
# ----------------------------------------------------------------------
class TestCasesQueue:
    def test_fifo_by_default(self):
        q = CaseEventsQueue()
        for cid in ("c1", "c2", "c3"):
            q.put(msg(event(cid, severity="critical" if cid == "c3" else "low"), "cases.events"))
        assert [q.get().message.body["case_id"] for _ in range(3)] == ["c1", "c2", "c3"]

    def test_critical_first(self):
        q = CaseEventsQueue(storage=PriorityStorage(CriticalCasesFirstPolicy()))
        q.put(msg(event("low", severity="low"), "cases.events"))
        q.put(msg(event("crit", severity="critical"), "cases.events"))
        assert q.get().message.body["case_id"] == "crit"

    def test_nearest_sla_first(self):
        from datetime import datetime, timezone
        now = datetime(2026, 10, 23, 9, 0, tzinfo=timezone.utc)
        policy = NearestSlaFirstPolicy(now=lambda: now)
        q = CaseEventsQueue(storage=PriorityStorage(policy))
        q.put(msg(event("none"), "cases.events"))
        q.put(msg(event("late", sla_due_at="2026-11-10T12:00:00+03:00"), "cases.events"))
        q.put(msg(event("soon", sla_due_at="2026-10-23T14:00:00+03:00"), "cases.events"))
        q.put(msg(event("overdue", sla_due_at="2026-10-22T12:00:00+00:00"), "cases.events"))
        assert [q.get().message.body["case_id"] for _ in range(4)] == ["overdue", "soon", "late", "none"]

    @pytest.mark.parametrize("body", [
        {"event_type": "case.closed", "case_id": "c", "review_id": "r"},
        {"event_type": "case.created", "case_id": "", "review_id": "r"},
        {"event_type": "case.created", "case_id": "c", "review_id": "r", "severity": "huge"},
        {"event_type": "case.created", "case_id": "c", "review_id": "r", "sla_due_at": "завтра"},
    ])
    def test_validation_rejects(self, body):
        with pytest.raises(MessageValidationError):
            CaseEventsQueue().put(msg(body, "cases.events"))

    def test_extend_allowed_event_types(self):
        q = CaseEventsQueue()
        q.set_validation_strategy(CaseEventValidation({"case.created", "case.closed"}))
        q.put(msg({"event_type": "case.closed", "case_id": "c", "review_id": "r"}, "cases.events"))
        assert len(q) == 1


# ----------------------------------------------------------------------
# Маршрутизатор
# ----------------------------------------------------------------------
class TestExchangeManager:
    def setup_method(self):
        self.labeling, self.cases = ReviewsLabelingQueue(), CaseEventsQueue()
        self.router = ExchangeManager()
        self.router.bind_queue(self.labeling)
        self.router.bind_queue(self.cases)

    def test_direct_routing_by_queue_name(self):
        assert self.router.route(msg(task("a"))) == ["reviews.labeling"]
        assert self.router.route(msg(event("c"), "cases.events")) == ["cases.events"]
        assert len(self.labeling) == 1 and len(self.cases) == 1

    def test_unroutable_raises_by_default(self):
        with pytest.raises(UnroutableMessageError):
            self.router.route(msg(task("a"), "reviews.unknown"))

    def test_unroutable_discard_and_alternate(self):
        self.router.set_unroutable_policy(DiscardUnroutable())
        assert self.router.route(msg(task("a"), "x")) == []
        spare = ReviewsLabelingQueue(validation=LenientLabelingTaskValidation())
        self.router.set_unroutable_policy(AlternateQueueUnroutable(spare))
        assert self.router.route(msg(task("a"), "x")) == ["reviews.labeling"]
        assert len(spare) == 1

    def test_switch_to_topic(self):
        self.router.set_routing_strategy(TopicRoutingStrategy())
        self.router.unbind_queue("cases.events")
        self.router.bind_queue(self.cases, binding_key="cases.#")
        assert self.router.route(msg(event("c"), "cases.events")) == ["cases.events"]

    def test_fanout_exchange(self):
        self.router.declare_exchange("audit", FanoutRoutingStrategy())
        lenient_l = ReviewsLabelingQueue(validation=LenientLabelingTaskValidation())
        self.router.bind_queue(lenient_l, exchange="audit", binding_key="")
        assert self.router.route(msg(task("a"), "anything", exchange="audit")) == ["reviews.labeling"]

    def test_exchange_type_conflict(self):
        with pytest.raises(ExchangeConflictError):
            self.router.declare_exchange("feedback.direct", TopicRoutingStrategy())
        assert self.router.declare_exchange("feedback.direct", DirectRoutingStrategy())

    @pytest.mark.parametrize("pattern,key,expected", [
        ("cases.*", "cases.events", True),
        ("cases.*", "cases.events.x", False),
        ("cases.#", "cases", True),
        ("#", "a.b.c", True),
        ("*.labeling", "reviews.labeling", True),
        ("a.#.c", "a.b.b.c", True),
        ("a.#.c", "a.b.d", False),
    ])
    def test_topic_matches(self, pattern, key, expected):
        assert topic_matches(pattern, key) is expected


# ----------------------------------------------------------------------
# Обработчик соединений и сквозные цепочки
# ----------------------------------------------------------------------
class TestConnectionHandler:
    def setup_method(self):
        self.broker = build_feedback_broker()

    def test_chain_1_and_2_end_to_end(self):
        api = self.broker.connect(API_BACKEND).channel()
        bg = self.broker.connect(BACKGROUND_WORKER).channel()
        lab = self.broker.connect(LABELING_WORKER).channel()

        api.basic_publish("reviews.labeling", task("r1", 1))             # связь 1
        bg.basic_publish("reviews.labeling", task("r2", 5, "collector"))  # связь 2

        def on_task(ch, d):
            if d.body["rating"] <= 2:
                ch.basic_publish("cases.events", event("c-" + d.body["review_id"]))  # связь 7

        lab.basic_consume("reviews.labeling", on_task)  # связь 5
        assert lab.drain_events() == 2
        assert self.broker.labeling_queue.stats().acked == 2

        d = bg.basic_get("cases.events")                 # связь 10
        assert d.body["case_id"] == "c-r1"
        bg.basic_ack(d.delivery_tag)
        assert len(self.broker.cases_queue) == 0

    @pytest.mark.parametrize("client,op,target", [
        (API_BACKEND, "publish", "cases.events"),
        (API_BACKEND, "consume", "reviews.labeling"),
        (LABELING_WORKER, "publish", "reviews.labeling"),
        (LABELING_WORKER, "consume", "cases.events"),
        (BACKGROUND_WORKER, "consume", "reviews.labeling"),
        ("stranger", "publish", "reviews.labeling"),
    ])
    def test_permissions_follow_diagram(self, client, op, target):
        ch = self.broker.connect(client).channel()
        with pytest.raises(AccessDeniedError):
            if op == "publish":
                ch.basic_publish(target, task("x") if target == "reviews.labeling" else event("x"))
            else:
                ch.basic_get(target)

    def test_permit_all_policy_swap(self):
        self.broker.connection_handler.set_access_policy(PermitAllPolicy())
        api = self.broker.connect(API_BACKEND).channel()
        assert api.basic_publish("cases.events", event("c")) == ["cases.events"]

    def test_shared_secret_authentication(self):
        broker = build_feedback_broker(secrets={API_BACKEND: "s3cret"})
        assert broker.connect(API_BACKEND, "s3cret").is_open
        with pytest.raises(AuthenticationError):
            broker.connect(API_BACKEND, "wrong")
        with pytest.raises(AuthenticationError):
            broker.connect(LABELING_WORKER, "s3cret")

    def test_ack_after_processing_retries_then_dead_letters(self):
        api = self.broker.connect(API_BACKEND).channel()
        lab = self.broker.connect(LABELING_WORKER).channel()
        api.basic_publish("reviews.labeling", task("r"))
        calls = []

        def failing(ch, d):
            calls.append(d.message.delivery_count)
            raise RuntimeError("boom")

        lab.basic_consume("reviews.labeling", failing)
        lab.drain_events()
        assert calls == [0, 1, 2]
        assert self.broker.labeling_queue.stats().dead_lettered == 1

    def test_auto_ack_loses_message_on_failure(self):
        self.broker.connection_handler.set_ack_strategy(AutoAck())
        api = self.broker.connect(API_BACKEND).channel()
        lab = self.broker.connect(LABELING_WORKER).channel()
        api.basic_publish("reviews.labeling", task("r"))
        lab.basic_consume("reviews.labeling", lambda ch, d: (_ for _ in ()).throw(RuntimeError()))
        assert lab.drain_events() == 1
        stats = self.broker.labeling_queue.stats()
        assert stats.acked == 1 and stats.ready == 0 and stats.dead_lettered == 0

    def test_manual_ack_with_prefetch_and_requeue_on_close(self):
        api = self.broker.connect(API_BACKEND).channel()
        for i in range(3):
            api.basic_publish("reviews.labeling", task(f"r{i}"))
        conn = self.broker.connect(LABELING_WORKER)
        lab = conn.channel()
        lab.basic_qos(prefetch_count=2)
        lab.basic_consume("reviews.labeling", lambda ch, d: None, ack_strategy=ManualAck())
        assert lab.drain_events() == 2          # упёрлись в prefetch
        assert lab.unacked_count == 2
        conn.close()                            # воркер «упал»
        assert len(self.broker.labeling_queue) == 3
        with pytest.raises(ConnectionClosedError):
            lab.basic_get("reviews.labeling")

    def test_double_ack_rejected(self):
        api = self.broker.connect(API_BACKEND).channel()
        lab = self.broker.connect(LABELING_WORKER).channel()
        api.basic_publish("reviews.labeling", task("r"))
        d = lab.basic_get("reviews.labeling")
        lab.basic_ack(d.delivery_tag)
        with pytest.raises(UnknownDeliveryTagError):
            lab.basic_ack(d.delivery_tag)

    def test_callback_ack_is_not_duplicated(self):
        api = self.broker.connect(API_BACKEND).channel()
        lab = self.broker.connect(LABELING_WORKER).channel()
        api.basic_publish("reviews.labeling", task("r"))
        lab.basic_consume("reviews.labeling", lambda ch, d: ch.basic_ack(d.delivery_tag),
                          ack_strategy=AckAfterProcessing())
        assert lab.drain_events() == 1
        assert self.broker.labeling_queue.stats().acked == 1

    def test_connection_limit(self):
        from message_broker.core import ConnectionLimitError
        handler = ConnectionHandler(ExchangeManager(), max_connections=1)
        handler.open_connection(Credentials("a"))
        with pytest.raises(ConnectionLimitError):
            handler.open_connection(Credentials("b"))


def test_components_do_not_import_each_other():
    """Каждый компонент зависит только от ядра."""
    import ast
    import pathlib

    components = {"connection_handler", "exchange_manager", "queue_labeling", "queue_cases"}
    root = pathlib.Path(__file__).resolve().parents[1] / "message_broker"
    for name in components:
        tree = ast.parse((root / f"{name}.py").read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module:
                assert node.module.split(".")[-1] not in components - {name}, f"{name} импортирует {node.module}"
