"""Имитация ``pika`` и сервера RabbitMQ для тестов без настоящего сервера.

Повторяет поведение RabbitMQ, на которое опирается слой
``message_broker.rabbitmq``: обмены direct/topic и обмен по умолчанию,
durable-очереди с аргументами (приоритет, лимит длины, x-overflow,
dead letter), publisher confirms и mandatory, ack/nack, prefetch,
возврат неподтверждённых сообщений при закрытии канала или обрыве,
ошибки 404/406, отказ в аутентификации, недоступность сервера.

Написана отдельно от кода брокера, чтобы тесты проверяли его честно.
Это не замена проверке на живом сервере.
"""

from __future__ import annotations

import itertools
from types import SimpleNamespace
from typing import Any, Callable


# --------------------------------------------------------------------------
# Исключения (имена как в pika.exceptions)
# --------------------------------------------------------------------------
class AMQPError(Exception):
    pass


class AMQPConnectionError(AMQPError):
    pass


class StreamLostError(AMQPConnectionError):
    pass


class ProbableAuthenticationError(AMQPConnectionError):
    pass


class AMQPChannelError(AMQPError):
    pass


class ChannelClosedByBroker(AMQPChannelError):
    def __init__(self, reply_code: int, reply_text: str) -> None:
        super().__init__(reply_code, reply_text)
        self.reply_code = reply_code
        self.reply_text = reply_text


class ChannelWrongStateError(AMQPChannelError):
    pass


class UnroutableError(AMQPChannelError):
    pass


class NackError(AMQPChannelError):
    pass


exceptions = SimpleNamespace(
    AMQPError=AMQPError, AMQPConnectionError=AMQPConnectionError, StreamLostError=StreamLostError,
    ProbableAuthenticationError=ProbableAuthenticationError, AMQPChannelError=AMQPChannelError,
    ChannelClosedByBroker=ChannelClosedByBroker, ChannelWrongStateError=ChannelWrongStateError,
    UnroutableError=UnroutableError, NackError=NackError,
)


# --------------------------------------------------------------------------
# Параметры и свойства
# --------------------------------------------------------------------------
class PlainCredentials:
    def __init__(self, username: str, password: str) -> None:
        self.username, self.password = username, password


class ConnectionParameters:
    def __init__(self, **kwargs: Any) -> None:
        self.__dict__.update(kwargs)


class BasicProperties:
    FIELDS = ("content_type", "content_encoding", "headers", "delivery_mode", "priority", "correlation_id",
              "reply_to", "expiration", "message_id", "timestamp", "type", "user_id", "app_id", "cluster_id")

    def __init__(self, **kwargs: Any) -> None:
        unknown = set(kwargs) - set(self.FIELDS)
        if unknown:
            raise TypeError(f"BasicProperties: неизвестные поля {unknown}")
        for name in self.FIELDS:
            setattr(self, name, kwargs.get(name))


# --------------------------------------------------------------------------
# Сервер
# --------------------------------------------------------------------------
def _topic_match(pattern: str, key: str) -> bool:
    p, k = pattern.split("."), key.split(".")

    def m(i: int, j: int) -> bool:
        if i == len(p):
            return j == len(k)
        if p[i] == "#":
            return m(i + 1, j) or (j < len(k) and m(i, j + 1))
        return j < len(k) and p[i] in ("*", k[j]) and m(i + 1, j + 1)

    return m(0, 0)


class _StoredMessage:
    def __init__(self, exchange: str, routing_key: str, body: bytes, properties: BasicProperties) -> None:
        self.exchange, self.routing_key, self.body, self.properties = exchange, routing_key, body, properties
        self.redelivered = False


class _Queue:
    def __init__(self, server: "FakeRabbitServer", name: str, durable: bool, arguments: dict) -> None:
        self.server, self.name, self.durable, self.arguments = server, name, durable, dict(arguments or {})
        self._items: list[tuple[int, int, _StoredMessage]] = []
        self._seq = itertools.count()
        self._front = itertools.count(-1, -1)

    def _prio(self, msg: _StoredMessage) -> int:
        max_p = self.arguments.get("x-max-priority")
        if not max_p:
            return 0
        return min(max_p, msg.properties.priority or 0)

    def __len__(self) -> int:
        return len(self._items)

    def publish(self, msg: _StoredMessage) -> bool:
        limit = self.arguments.get("x-max-length")
        if limit is not None and len(self._items) >= limit:
            if self.arguments.get("x-overflow", "drop-head") == "reject-publish":
                return False
            self._items.sort(key=lambda e: (-e[0], e[1]))
            _, _, dropped = self._items.pop(0)
            self.server.dead_letter(self, dropped, "maxlen")
        self._items.append((self._prio(msg), next(self._seq), msg))
        return True

    def requeue(self, msg: _StoredMessage) -> None:
        msg.redelivered = True
        self._items.append((self._prio(msg), next(self._front), msg))

    def pop(self) -> _StoredMessage | None:
        if not self._items:
            return None
        self._items.sort(key=lambda e: (-e[0], e[1]))
        return self._items.pop(0)[2]


class FakeRabbitServer:
    """Состояние «сервера», общее для всех соединений."""

    def __init__(self, users: dict[str, str] | None = None) -> None:
        self.users = users if users is not None else {"feedback": "feedback"}
        self.exchanges: dict[str, str] = {}
        self.bindings: list[tuple[str, str, str]] = []  # (exchange, queue, key)
        self.queues: dict[str, _Queue] = {}
        self.down = False
        self.connections: list["BlockingConnection"] = []
        self.connection_names: list[str] = []

    # --- маршрутизация ---------------------------------------------------
    def route(self, exchange: str, routing_key: str) -> list[_Queue]:
        if exchange == "":
            q = self.queues.get(routing_key)
            return [q] if q is not None else []
        etype = self.exchanges[exchange]
        names: list[str] = []
        for ex, queue, key in self.bindings:
            if ex != exchange:
                continue
            ok = (etype == "direct" and key == routing_key) or (etype == "topic" and _topic_match(key, routing_key)) \
                or etype == "fanout"
            if ok and queue not in names:
                names.append(queue)
        return [self.queues[n] for n in names if n in self.queues]

    def dead_letter(self, queue: _Queue, msg: _StoredMessage, reason: str) -> None:
        dlx = queue.arguments.get("x-dead-letter-exchange")
        if dlx is None or dlx not in self.exchanges:
            return
        key = queue.arguments.get("x-dead-letter-routing-key", msg.routing_key)
        for target in self.route(dlx, key):
            copy = _StoredMessage(dlx, key, msg.body, msg.properties)
            target.publish(copy)

    # --- управление для тестов -------------------------------------------
    def drop_connections(self) -> None:
        """Обрыв сети: все соединения рвутся, неподтверждённое возвращается в очереди."""
        for conn in list(self.connections):
            conn._lost()

    def messages(self, queue: str) -> int:
        return len(self.queues[queue])

    def peek_bodies(self, queue: str) -> list[bytes]:
        q = self.queues[queue]
        return [m.body for _, _, m in sorted(q._items, key=lambda e: (-e[0], e[1]))]


# --------------------------------------------------------------------------
# Соединение и канал
# --------------------------------------------------------------------------
class BlockingConnection:
    server: FakeRabbitServer  # подставляется make_pika

    def __init__(self, parameters: ConnectionParameters) -> None:
        if self.server.down:
            raise AMQPConnectionError("Connection refused")
        creds = parameters.credentials
        if self.server.users.get(creds.username) != creds.password:
            raise ProbableAuthenticationError("ACCESS_REFUSED")
        self.parameters = parameters
        self.is_open = True
        self._channels: list[BlockingChannel] = []
        self.server.connections.append(self)
        self.server.connection_names.append((getattr(parameters, "client_properties", None) or {}).get("connection_name", ""))

    @property
    def is_closed(self) -> bool:
        return not self.is_open

    def channel(self) -> "BlockingChannel":
        self._check()
        ch = BlockingChannel(self)
        self._channels.append(ch)
        return ch

    def process_data_events(self, time_limit: float = 0) -> None:
        self._check()
        for ch in list(self._channels):
            ch._deliver()

    def close(self) -> None:
        if not self.is_open:
            raise ConnectionWrongState()
        for ch in list(self._channels):
            if ch.is_open:
                ch.close()
        self.is_open = False
        self._remove()

    def _lost(self) -> None:
        for ch in list(self._channels):
            ch._requeue_unacked()
            ch.is_open = False
        self.is_open = False
        self._remove()
        self._broken = True

    def _remove(self) -> None:
        if self in self.server.connections:
            self.server.connections.remove(self)

    def _check(self) -> None:
        if getattr(self, "_broken", False):
            raise StreamLostError("Stream connection lost")
        if not self.is_open:
            raise AMQPConnectionError("connection closed")


class ConnectionWrongState(AMQPError):
    pass


class BlockingChannel:
    _tags = itertools.count(1)

    def __init__(self, connection: BlockingConnection) -> None:
        self.connection = connection
        self.server = connection.server
        self.is_open = True
        self.confirm = False
        self.prefetch = 0
        self._tag = itertools.count(1)
        self._unacked: dict[int, tuple[_Queue, _StoredMessage]] = {}
        self._consumers: dict[str, tuple[str, Callable, bool]] = {}

    # --- служебное ------------------------------------------------------
    def _check(self) -> None:
        self.connection._check()
        if not self.is_open:
            raise ChannelWrongStateError("Channel is closed.")

    def _fail(self, code: int, text: str) -> None:
        self._requeue_unacked()
        self.is_open = False
        raise ChannelClosedByBroker(code, text)

    def _requeue_unacked(self) -> None:
        for queue, msg in self._unacked.values():
            queue.requeue(msg)
        self._unacked.clear()

    def _method(self, tag: int, msg: _StoredMessage) -> SimpleNamespace:
        return SimpleNamespace(delivery_tag=tag, redelivered=msg.redelivered,
                               routing_key=msg.routing_key, exchange=msg.exchange)

    def _deliver(self) -> None:
        if not self.is_open:
            return
        progressed = True
        while progressed:
            progressed = False
            for ctag, (queue_name, callback, auto_ack) in list(self._consumers.items()):
                if self.prefetch and len(self._unacked) >= self.prefetch:
                    return
                queue = self.server.queues.get(queue_name)
                msg = queue.pop() if queue else None
                if msg is None:
                    continue
                tag = next(self._tag)
                if not auto_ack:
                    self._unacked[tag] = (queue, msg)
                callback(self, self._method(tag, msg), msg.properties, msg.body)
                progressed = True

    # --- API pika ---------------------------------------------------------
    def confirm_delivery(self) -> None:
        self._check()
        self.confirm = True

    def basic_qos(self, prefetch_size: int = 0, prefetch_count: int = 0, global_qos: bool = False) -> None:
        self._check()
        self.prefetch = prefetch_count

    def exchange_declare(self, exchange: str, exchange_type: str = "direct", passive: bool = False,
                         durable: bool = False, auto_delete: bool = False, internal: bool = False,
                         arguments: dict | None = None) -> None:
        self._check()
        existing = self.server.exchanges.get(exchange)
        if passive:
            if existing is None:
                self._fail(404, f"NOT_FOUND - no exchange '{exchange}'")
            return
        if existing is not None and existing != str(exchange_type):
            self._fail(406, f"PRECONDITION_FAILED - inequivalent arg 'type' for exchange '{exchange}'")
        self.server.exchanges[exchange] = str(exchange_type)

    def exchange_delete(self, exchange: str, if_unused: bool = False) -> None:
        self._check()
        self.server.exchanges.pop(exchange, None)
        self.server.bindings = [b for b in self.server.bindings if b[0] != exchange]

    def queue_declare(self, queue: str, passive: bool = False, durable: bool = False, exclusive: bool = False,
                      auto_delete: bool = False, arguments: dict | None = None) -> SimpleNamespace:
        self._check()
        existing = self.server.queues.get(queue)
        if passive:
            if existing is None:
                self._fail(404, f"NOT_FOUND - no queue '{queue}'")
        elif existing is None:
            existing = self.server.queues[queue] = _Queue(self.server, queue, durable, arguments or {})
        elif existing.arguments != dict(arguments or {}) or existing.durable != durable:
            self._fail(406, f"PRECONDITION_FAILED - inequivalent arg for queue '{queue}'")
        consumers = sum(1 for c in self.server.connections for ch in c._channels if ch.is_open
                        for (qn, _, _) in ch._consumers.values() if qn == queue)
        return SimpleNamespace(method=SimpleNamespace(queue=queue, message_count=len(existing),
                                                      consumer_count=consumers))

    def queue_bind(self, queue: str, exchange: str, routing_key: str | None = None,
                   arguments: dict | None = None) -> None:
        self._check()
        if exchange not in self.server.exchanges:
            self._fail(404, f"NOT_FOUND - no exchange '{exchange}'")
        if queue not in self.server.queues:
            self._fail(404, f"NOT_FOUND - no queue '{queue}'")
        binding = (exchange, queue, routing_key if routing_key is not None else queue)
        if binding not in self.server.bindings:
            self.server.bindings.append(binding)

    def queue_delete(self, queue: str, if_unused: bool = False, if_empty: bool = False) -> None:
        self._check()
        self.server.queues.pop(queue, None)
        self.server.bindings = [b for b in self.server.bindings if b[1] != queue]

    def basic_publish(self, exchange: str, routing_key: str, body: bytes,
                      properties: BasicProperties | None = None, mandatory: bool = False) -> None:
        self._check()
        if not isinstance(body, (bytes, bytearray)):
            raise TypeError("body должен быть bytes")
        if exchange != "" and exchange not in self.server.exchanges:
            self._fail(404, f"NOT_FOUND - no exchange '{exchange}'")
        targets = self.server.route(exchange, routing_key)
        if not targets:
            if mandatory and self.confirm:
                raise UnroutableError([body])
            return
        props = properties or BasicProperties()
        rejected = False
        for queue in targets:
            if not queue.publish(_StoredMessage(exchange, routing_key, bytes(body), props)):
                rejected = True
        if rejected and self.confirm:
            raise NackError([body])

    def basic_get(self, queue: str, auto_ack: bool = False) -> tuple[Any, Any, Any]:
        self._check()
        q = self.server.queues.get(queue)
        if q is None:
            self._fail(404, f"NOT_FOUND - no queue '{queue}'")
        msg = q.pop()
        if msg is None:
            return None, None, None
        tag = next(self._tag)
        if not auto_ack:
            self._unacked[tag] = (q, msg)
        return self._method(tag, msg), msg.properties, msg.body

    def basic_ack(self, delivery_tag: int = 0, multiple: bool = False) -> None:
        self._check()
        if delivery_tag not in self._unacked:
            self._fail(406, f"PRECONDITION_FAILED - unknown delivery tag {delivery_tag}")
        del self._unacked[delivery_tag]

    def basic_nack(self, delivery_tag: int = 0, multiple: bool = False, requeue: bool = True) -> None:
        self._check()
        if delivery_tag not in self._unacked:
            self._fail(406, f"PRECONDITION_FAILED - unknown delivery tag {delivery_tag}")
        queue, msg = self._unacked.pop(delivery_tag)
        if requeue:
            queue.requeue(msg)
        else:
            self.server.dead_letter(queue, msg, "rejected")

    def basic_consume(self, queue: str, on_message_callback: Callable, auto_ack: bool = False,
                      exclusive: bool = False, consumer_tag: str | None = None,
                      arguments: dict | None = None) -> str:
        self._check()
        if queue not in self.server.queues:
            self._fail(404, f"NOT_FOUND - no queue '{queue}'")
        tag = consumer_tag or f"ctag{next(self._tags)}"
        self._consumers[tag] = (queue, on_message_callback, auto_ack)
        return tag

    def basic_cancel(self, consumer_tag: str) -> None:
        self._check()
        self._consumers.pop(consumer_tag, None)

    def close(self) -> None:
        if not self.is_open:
            raise ChannelWrongStateError("Channel is closed.")
        self._requeue_unacked()
        self._consumers.clear()
        self.is_open = False


# --------------------------------------------------------------------------
def make_pika(server: FakeRabbitServer) -> SimpleNamespace:
    """Модуль, подставляемый вместо ``pika`` (``pika_module=...``)."""
    conn_cls = type("BlockingConnection", (BlockingConnection,), {"server": server})
    return SimpleNamespace(
        BlockingConnection=conn_cls, ConnectionParameters=ConnectionParameters,
        PlainCredentials=PlainCredentials, BasicProperties=BasicProperties, exceptions=exceptions,
    )
