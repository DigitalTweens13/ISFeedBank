"""Тесты слоя над RabbitMQ на имитации сервера (tests/fake_pika.py).

Проверяют логику слоя без запущенного RabbitMQ. Проверка на живом
сервере — сценарий в README (раздел «Проверка на настоящем RabbitMQ»).
"""

from __future__ import annotations

import json

import pytest

from message_broker.connection_handler import ManualAck
from message_broker.core import (
    AccessDeniedError,
    AuthenticationError,
    BrokerError,
    ConnectionClosedError,
    DropHeadOverflow,
    MessageValidationError,
    QueueOverflowError,
    UnroutableMessageError,
)
from message_broker.rabbitmq import build_rabbit_broker
from message_broker.rabbitmq.assembly import API_BACKEND, BACKGROUND_WORKER, LABELING_WORKER
from message_broker.rabbitmq.connection_handler import (
    FixedDelayRetry,
    NoRetry,
    RabbitConnectionHandler,
    StaticCredentials,
)
from message_broker.rabbitmq.contracts import FifoOrder, PriorityOrder
from message_broker.rabbitmq.exchange_manager import DirectRouting, RabbitExchangeManager, TopicRouting
from message_broker.rabbitmq.queue_cases import CriticalCasesFirstPolicy
from message_broker.rabbitmq.queue_labeling import RabbitLabelingQueue

from .fake_pika import FakeRabbitServer, make_pika


def task(review_id: str, rating: int | None = None, source: str = "api_batch") -> dict:
    body = {"review_id": review_id, "text": "текст", "source": source}
    if rating is not None:
        body["rating"] = rating
    return body


def event(case_id: str, **extra) -> dict:
    return {"event_type": "case.created", "case_id": case_id, "review_id": "r", **extra}


@pytest.fixture
def server():
    return FakeRabbitServer()


@pytest.fixture
def broker(server):
    b = build_rabbit_broker(pika_module=make_pika(server), reconnect=NoRetry())
    b.setup()
    return b


# ----------------------------------------------------------------------
# Топология
# ----------------------------------------------------------------------
class TestTopology:
    def test_setup_declares_everything(self, broker, server):
        assert server.exchanges == {"feedback.dlx": "direct", "feedback.direct": "direct", "feedback.topic": "topic"}
        assert set(server.queues) == {"reviews.labeling", "reviews.labeling.dlq", "cases.events", "cases.events.dlq"}
        args = server.queues["reviews.labeling"].arguments
        assert args["x-max-priority"] == 10
        assert args["x-overflow"] == "reject-publish"
        assert args["x-dead-letter-exchange"] == "feedback.dlx"
        assert server.queues["reviews.labeling"].durable
        assert ("feedback.direct", "reviews.labeling", "reviews.labeling") in server.bindings
        assert ("feedback.topic", "cases.events", "cases.events.#") in server.bindings

    def test_setup_is_idempotent(self, broker, server):
        broker.setup()
        assert len(server.bindings) == 6

    def test_conflicting_existing_queue(self, server):
        pika = make_pika(server)
        ch = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=pika.PlainCredentials("feedback", "feedback"))).channel()
        ch.queue_declare(queue="reviews.labeling", durable=True)  # без аргументов
        b = build_rabbit_broker(pika_module=pika, reconnect=NoRetry())
        with pytest.raises(BrokerError, match="reset"):
            b.setup()

    def test_reset_removes_queues(self, broker, server):
        broker.reset()
        assert server.queues == {} and "feedback.direct" not in server.exchanges

    def test_stats(self, broker):
        broker.connect(API_BACKEND).channel().basic_publish("reviews.labeling", task("r1"))
        stats = {s.name: s.ready for s in broker.stats()}
        assert stats == {"reviews.labeling": 1, "reviews.labeling.dlq": 0, "cases.events": 0, "cases.events.dlq": 0}


# ----------------------------------------------------------------------
# Публикация
# ----------------------------------------------------------------------
class TestPublish:
    def test_message_is_persistent_json(self, broker, server):
        broker.connect(API_BACKEND).channel().basic_publish("reviews.labeling", task("r1", 1))
        stored = server.queues["reviews.labeling"]._items[0][2]
        assert stored.properties.delivery_mode == 2
        assert stored.properties.content_type == "application/json"
        assert stored.properties.priority == 4  # оценка 1 → приоритет 4
        assert json.loads(stored.body)["review_id"] == "r1"
        assert stored.properties.headers["x-publisher"] == API_BACKEND

    def test_validation_happens_before_server(self, broker, server):
        api = broker.connect(API_BACKEND).channel()
        with pytest.raises(MessageValidationError):
            api.basic_publish("reviews.labeling", {"review_id": "r", "text": "x"})
        assert server.messages("reviews.labeling") == 0

    def test_permissions(self, broker):
        with pytest.raises(AccessDeniedError):
            broker.connect(API_BACKEND).channel().basic_publish("cases.events", event("c"))
        with pytest.raises(AccessDeniedError):
            broker.connect(LABELING_WORKER).channel().basic_get("cases.events")

    def test_unknown_key(self, broker):
        broker.connection_handler.set_access_policy(__import__(
            "message_broker.connection_handler", fromlist=["PermitAllPolicy"]).PermitAllPolicy())
        with pytest.raises(UnroutableMessageError):
            broker.connect(API_BACKEND).channel().basic_publish("nowhere", task("r"))

    def test_without_setup_server_rejects(self, server):
        b = build_rabbit_broker(pika_module=make_pika(server), reconnect=NoRetry())
        with pytest.raises(BrokerError):
            b.connect(API_BACKEND).channel().basic_publish("reviews.labeling", task("r"))

    def test_connection_name_visible_on_server(self, broker, server):
        broker.connect(LABELING_WORKER)
        assert LABELING_WORKER in server.connection_names


# ----------------------------------------------------------------------
# Стратегии очередей
# ----------------------------------------------------------------------
class TestQueueStrategies:
    def _drain(self, ch, queue):
        out = []
        while (d := ch.basic_get(queue, auto_ack=True)) is not None:
            out.append(d.body)
        return out

    def test_negative_first_then_fifo_on_the_fly(self, broker):
        api = broker.connect(API_BACKEND).channel()
        lab = broker.connect(LABELING_WORKER).channel()
        for i, r in enumerate([5, 1, 3, 2]):
            api.basic_publish("reviews.labeling", task(f"r{i}", r))
        assert [b["rating"] for b in self._drain(lab, "reviews.labeling")] == [1, 2, 3, 5]
        broker.labeling_queue.set_order_strategy(FifoOrder())
        for i, r in enumerate([5, 1, 3, 2]):
            api.basic_publish("reviews.labeling", task(f"s{i}", r))
        assert [b["rating"] for b in self._drain(lab, "reviews.labeling")] == [5, 1, 3, 2]

    def test_critical_cases_first(self, broker):
        broker.cases_queue.set_order_strategy(PriorityOrder(CriticalCasesFirstPolicy()))
        lab = broker.connect(LABELING_WORKER).channel()
        bg = broker.connect(BACKGROUND_WORKER).channel()
        for cid, sev in [("a", "low"), ("b", "critical"), ("c", "medium")]:
            lab.basic_publish("cases.events", event(cid, severity=sev))
        assert [b["severity"] for b in self._drain(bg, "cases.events")] == ["critical", "medium", "low"]

    def _custom(self, server, queue):
        router = RabbitExchangeManager(DirectRouting())
        router.bind_queue(queue)
        handler = RabbitConnectionHandler(router, pika_module=make_pika(server), reconnect=NoRetry())
        handler.register_queue(queue)
        handler.declare_topology()
        return handler

    def test_reject_publish_overflow(self, server):
        handler = self._custom(server, RabbitLabelingQueue(max_length=1))
        ch = handler.open_connection(API_BACKEND).channel()
        ch.basic_publish("reviews.labeling", task("a"))
        with pytest.raises(QueueOverflowError):
            ch.basic_publish("reviews.labeling", task("b"))

    def test_drop_head_overflow_goes_to_dlq(self, server):
        handler = self._custom(server, RabbitLabelingQueue(max_length=1, overflow=DropHeadOverflow()))
        ch = handler.open_connection(API_BACKEND).channel()
        ch.basic_publish("reviews.labeling", task("a"))
        ch.basic_publish("reviews.labeling", task("b"))
        assert server.messages("reviews.labeling") == 1
        assert json.loads(server.peek_bodies("reviews.labeling.dlq")[0])["review_id"] == "a"


# ----------------------------------------------------------------------
# Маршрутизация
# ----------------------------------------------------------------------
class TestRouting:
    def test_switch_to_topic(self, broker, server):
        broker.exchange_manager.set_routing_strategy(broker.topic_routing)
        api = broker.connect(API_BACKEND).channel()
        assert api.basic_publish("reviews.labeling", task("r", source="collector")) == ["reviews.labeling"]
        stored = server.queues["reviews.labeling"]._items[0][2]
        assert stored.exchange == "feedback.topic"
        assert stored.routing_key == "reviews.labeling.collector"

    def test_unregistered_strategy_rejected(self, broker):
        with pytest.raises(BrokerError):
            broker.exchange_manager.set_routing_strategy(TopicRouting(exchange="other.topic"))


# ----------------------------------------------------------------------
# Потребители, подтверждения, надёжность
# ----------------------------------------------------------------------
class TestConsuming:
    def test_both_chains_end_to_end(self, broker, server):
        api = broker.connect(API_BACKEND).channel()
        bg = broker.connect(BACKGROUND_WORKER).channel()
        lab = broker.connect(LABELING_WORKER).channel()
        api.basic_publish("reviews.labeling", task("r1", 1))
        bg.basic_publish("reviews.labeling", task("r2", 5, "collector"))

        def on_task(ch, d):
            if d.body["rating"] <= 2:
                ch.basic_publish("cases.events", event("c-" + d.body["review_id"]))

        lab.basic_consume("reviews.labeling", on_task)
        assert lab.start_consuming(inactivity_timeout=0) == 2
        assert server.messages("reviews.labeling") == 0
        d = bg.basic_get("cases.events")
        assert d.body["case_id"] == "c-r1" and d.message.publisher_id == LABELING_WORKER
        bg.basic_ack(d.delivery_tag)
        assert server.messages("cases.events") == 0

    def test_max_messages(self, broker):
        api = broker.connect(API_BACKEND).channel()
        for i in range(3):
            api.basic_publish("reviews.labeling", task(f"r{i}"))
        lab = broker.connect(LABELING_WORKER).channel()
        lab.basic_consume("reviews.labeling", lambda ch, d: None)
        assert lab.start_consuming(max_messages=2) == 2

    def test_worker_crash_returns_message(self, broker, server):
        broker.connect(API_BACKEND).channel().basic_publish("reviews.labeling", task("r1"))
        conn = broker.connect(LABELING_WORKER)
        d = conn.channel().basic_get("reviews.labeling")
        assert server.messages("reviews.labeling") == 0
        conn.close()  # воркер «упал» без ack
        assert server.messages("reviews.labeling") == 1
        again = broker.connect(LABELING_WORKER).channel().basic_get("reviews.labeling")
        assert again.body == d.body and again.redelivered

    def test_retries_then_dead_letter(self, broker, server):
        broker.connect(API_BACKEND).channel().basic_publish("reviews.labeling", task("r1"))
        lab = broker.connect(LABELING_WORKER).channel()
        attempts = []

        def failing(ch, d):
            attempts.append(d.message.delivery_count)
            raise RuntimeError("модель недоступна")

        lab.basic_consume("reviews.labeling", failing)
        lab.start_consuming(inactivity_timeout=0)
        assert attempts == [0, 1, 2]
        assert server.messages("reviews.labeling") == 0
        assert server.messages("reviews.labeling.dlq") == 1

    def test_manual_ack_prefetch(self, broker, server):
        api = broker.connect(API_BACKEND).channel()
        for i in range(3):
            api.basic_publish("reviews.labeling", task(f"r{i}"))
        lab = broker.connect(LABELING_WORKER).channel()
        lab.basic_qos(2)
        lab.basic_consume("reviews.labeling", lambda ch, d: None, ack_strategy=ManualAck())
        lab.start_consuming(inactivity_timeout=0)
        assert lab.unacked_count == 2 and server.messages("reviews.labeling") == 1

    def test_reconnect_during_publish(self, broker, server):
        api = broker.connect(API_BACKEND).channel()
        broker.connection_handler.set_reconnect_strategy(FixedDelayRetry(attempts=2, delay=0))
        server.drop_connections()
        assert api.basic_publish("reviews.labeling", task("r1")) == ["reviews.labeling"]
        assert server.messages("reviews.labeling") == 1

    def test_reconnect_during_consuming(self, broker, server):
        api = broker.connect(API_BACKEND).channel()
        for i in range(3):
            api.basic_publish("reviews.labeling", task(f"r{i}"))
        lab = broker.connect(LABELING_WORKER).channel()
        seen = []

        def handler(ch, d):
            seen.append(d.body["review_id"])
            if len(seen) == 1:
                server.drop_connections()  # обрыв сети посреди обработки

        lab.basic_consume("reviews.labeling", handler)
        lab.start_consuming(inactivity_timeout=0)
        assert server.messages("reviews.labeling") == 0
        assert sorted(set(seen)) == ["r0", "r1", "r2"]
        assert seen.count(seen[0]) == 2  # первое сообщение доставлено повторно


# ----------------------------------------------------------------------
# Подключение
# ----------------------------------------------------------------------
class TestConnection:
    def test_wrong_password(self, server):
        b = build_rabbit_broker(pika_module=make_pika(server), credentials=StaticCredentials("feedback", "bad"))
        with pytest.raises(AuthenticationError):
            b.connect(API_BACKEND)

    def test_server_down_retries_then_fails(self, server):
        server.down = True
        sleeps = []
        b = build_rabbit_broker(pika_module=make_pika(server), reconnect=FixedDelayRetry(attempts=3, delay=0.5))
        b.connection_handler._sleep = sleeps.append
        with pytest.raises(ConnectionClosedError, match="docker compose"):
            b.connect(API_BACKEND)
        assert sleeps == [0.5, 0.5]


def test_rabbit_components_do_not_import_each_other():
    import ast
    import pathlib

    components = {"connection_handler", "exchange_manager", "queue_labeling", "queue_cases"}
    root = pathlib.Path(__file__).resolve().parents[1] / "message_broker" / "rabbitmq"
    for name in components:
        tree = ast.parse((root / f"{name}.py").read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module:
                imported = node.module.split(".")[-1]
                assert imported not in components - {name}, f"rabbitmq.{name} импортирует {node.module}"
