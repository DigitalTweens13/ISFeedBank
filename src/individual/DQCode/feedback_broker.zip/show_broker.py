"""Пошаговая демонстрация брокера для защиты.

    python show_broker.py                 # с паузами (Enter — следующий шаг)
    python show_broker.py --no-pause      # всё сразу
    python show_broker.py --file мои.csv  # задачи берутся из своего CSV

Каждый шаг подписан номерами связей диаграммы L3, после шага
печатается состояние обеих очередей.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from message_broker import build_feedback_broker
from message_broker.assembly import API_BACKEND, BACKGROUND_WORKER, LABELING_WORKER
from message_broker.core import AccessDeniedError, BrokerError, FifoStorage, PriorityStorage
from message_broker.exchange_manager import TopicRoutingStrategy
from message_broker.queue_labeling import NegativeReviewsFirstPolicy, SOURCE_API_BATCH, SOURCE_COLLECTOR

PAUSE = True
STEP = 0

DEFAULT_TASKS = [
    {"review_id": "r-1", "text": "Всё отлично, спасибо", "rating": 5},
    {"review_id": "r-2", "text": "Списали комиссию без предупреждения", "rating": 1},
    {"review_id": "r-3", "text": "Приложение тормозит", "rating": 3},
]


def step(title: str, links: str = "") -> None:
    global STEP
    STEP += 1
    if PAUSE:
        input("\n[Enter — следующий шаг] ")
    suffix = f"   (связи {links})" if links else ""
    print(f"\n{'=' * 72}\nШАГ {STEP}. {title}{suffix}\n{'=' * 72}")


def state(broker) -> None:
    print("\n  Состояние очередей:")
    for q in (broker.labeling_queue, broker.cases_queue):
        s = q.stats()
        print(f"    {s.name:<17} ждут выдачи: {s.ready:<3} у воркеров без ack: {s.unacked:<3} "
              f"подтверждено: {s.acked:<3} dead letter: {s.dead_lettered}")


def show(delivery) -> str:
    b = delivery.body
    return f"{b.get('review_id') or b.get('case_id')} (оценка {b.get('rating', '-')})" \
        if "review_id" in b and "case_id" not in b else f"{b['case_id']} [{b.get('severity', '-')}]"


def load_tasks(path: str | None) -> list[dict]:
    if not path:
        return DEFAULT_TASKS
    from process_reviews import read_reviews, to_task  # переиспользуем чтение CSV
    return [to_task(row) for row in read_reviews(Path(path))]


def main() -> None:
    global PAUSE
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-pause", action="store_true")
    parser.add_argument("--file")
    args = parser.parse_args()
    PAUSE = not args.no_pause
    tasks = load_tasks(args.file)

    # ------------------------------------------------------------------
    step("Сборка брокера из четырёх независимых компонентов")
    broker = build_feedback_broker()
    ex = broker.exchange_manager.get_exchange()
    print(f"  Обработчик соединений: {type(broker.connection_handler).__name__}")
    print(f"  Маршрутизатор:         {type(broker.exchange_manager).__name__}, обмен «{ex.name}» "
          f"({ex.routing_strategy.exchange_type})")
    for b in ex.bindings:
        print(f"     привязка: ключ «{b.binding_key}» → очередь {b.queue.name}")
    print(f"  Очередь 1: {broker.labeling_queue.name}, порядок: "
          f"{type(broker.labeling_queue.storage_strategy).__name__}"
          f"({type(broker.labeling_queue.storage_strategy.policy).__name__})")
    print(f"  Очередь 2: {broker.cases_queue.name}, порядок: {type(broker.cases_queue.storage_strategy).__name__}")

    api_conn = broker.connect(API_BACKEND)
    lab_conn = broker.connect(LABELING_WORKER)
    bg_conn = broker.connect(BACKGROUND_WORKER)
    api, lab, bg = api_conn.channel(), lab_conn.channel(), bg_conn.channel()
    print("\n  Подключились три контейнера:")
    for c in broker.connection_handler.active_connections():
        print(f"     {c.connection_id}: {c.identity.client_id}")
    state(broker)

    # ------------------------------------------------------------------
    step("Backend API и воркер фоновых задач публикуют задачи разметки", "1, 2 → 3 → 4")
    for t in tasks:
        t = {"source": SOURCE_API_BATCH, **t}
        try:
            queues = api.basic_publish("reviews.labeling", t)
            print(f"  Backend API → {t['review_id']} (оценка {t.get('rating', '-')}) → попало в {queues}")
        except BrokerError as exc:
            print(f"  Backend API → {t.get('review_id') or '?'} ОТКЛОНЕНО: {exc}")
    bg.basic_publish("reviews.labeling", {"review_id": "r-4", "text": "Не дозвониться в поддержку",
                                          "rating": 2, "source": SOURCE_COLLECTOR})
    print("  Воркер фоновых задач → r-4 (оценка 2) → попало в ['reviews.labeling']")
    state(broker)

    # ------------------------------------------------------------------
    step("Проверка прав: Backend API пытается писать в cases.events")
    try:
        api.basic_publish("cases.events", {"event_type": "case.created", "case_id": "x", "review_id": "x"})
    except AccessDeniedError as exc:
        print(f"  ОТКАЗ: {exc}")
        print("  На диаграмме связи Backend API → cases.events нет, поэтому брокер её запрещает.")
    state(broker)

    # ------------------------------------------------------------------
    step("Воркер разметки забирает задачу и подтверждает её", "5 → 6")
    d = lab.basic_get("reviews.labeling")
    print(f"  Выдана задача {show(d)} — первой выдан самый негативный отзыв")
    state(broker)
    print("\n  ... воркер разметил отзыв и отправляет ack")
    lab.basic_ack(d.delivery_tag)
    state(broker)

    # ------------------------------------------------------------------
    step("Отказоустойчивость: воркер взял задачу и упал, не подтвердив её", "5 → 6")
    d = lab.basic_get("reviews.labeling")
    print(f"  Выдана задача {show(d)}")
    state(broker)
    print("\n  !!! Соединение воркера разорвано (процесс упал)")
    lab_conn.close()
    state(broker)
    print("  Задача не потерялась — вернулась в очередь.")
    lab_conn = broker.connect(LABELING_WORKER)
    lab = lab_conn.channel()
    d = lab.basic_get("reviews.labeling")
    print(f"  Новый воркер получил ту же задачу {show(d)}, признак повторной доставки: {d.redelivered}")
    lab.basic_nack(d.delivery_tag, requeue=True)

    # ------------------------------------------------------------------
    step("Воркер разметки обрабатывает остальное и публикует события", "5 → 6, 7 → 8 → 9")

    def on_task(channel, delivery):
        review = delivery.body
        rating = review.get("rating", 3)
        if isinstance(rating, int) and rating <= 2:
            severity = "critical" if rating == 1 else "high"
            channel.basic_publish("cases.events", {"event_type": "case.created", "case_id": f"case-{review['review_id']}",
                                                   "review_id": review["review_id"], "severity": severity})
            print(f"  {show(delivery)}: негатив → опубликовано событие «обращение создано»")
        else:
            print(f"  {show(delivery)}: обращение не требуется")

    lab.basic_consume("reviews.labeling", on_task)
    lab.drain_events()
    state(broker)

    # ------------------------------------------------------------------
    step("Воркер фоновых задач забирает события по обращениям", "10 → 11")
    while (d := bg.basic_get("cases.events")) is not None:
        print(f"  Событие {show(d)} → назначить владельца, запустить контроль SLA, ack")
        bg.basic_ack(d.delivery_tag)
    state(broker)

    # ------------------------------------------------------------------
    step("Паттерн «Стратегия»: смена порядка выдачи на лету")
    ratings = [5, 1, 4, 2]

    def run(label: str) -> None:
        for i, r in enumerate(ratings):
            api.basic_publish("reviews.labeling", {"review_id": f"s-{i}", "text": "…", "rating": r,
                                                   "source": SOURCE_API_BATCH})
        out = []
        while (x := lab.basic_get("reviews.labeling", auto_ack=True)) is not None:
            out.append(x.body["rating"])
        print(f"  {label:<45} отправлено {ratings} → выдано {out}")

    run("PriorityStorage(NegativeReviewsFirstPolicy):")
    broker.labeling_queue.set_storage_strategy(FifoStorage())
    run("FifoStorage:")
    broker.labeling_queue.set_storage_strategy(PriorityStorage(NegativeReviewsFirstPolicy()))
    print("  Код очереди не менялся — подменён только объект-стратегия.")

    # ------------------------------------------------------------------
    step("Паттерн «Стратегия»: смена маршрутизации direct → topic")
    broker.exchange_manager.set_routing_strategy(TopicRoutingStrategy())
    broker.exchange_manager.unbind_queue("cases.events")
    broker.exchange_manager.bind_queue(broker.cases_queue, binding_key="cases.#")
    queues = lab.basic_publish("cases.events", {"event_type": "case.created", "case_id": "case-t",
                                                "review_id": "r-t", "severity": "low"})
    print(f"  Привязка по шаблону «cases.#», ключ «cases.events» → {queues}")
    bg.basic_get("cases.events", auto_ack=True)

    # ------------------------------------------------------------------
    step("Итог")
    state(broker)
    print("\n  Все сообщения доставлены и подтверждены, очереди пусты.")
    broker.shutdown()


if __name__ == "__main__":
    main()
