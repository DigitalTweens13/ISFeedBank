# Брокер сообщений (RabbitMQ) — ИС управления обратной связью клиентов банка

Компоненты контейнера «Брокер сообщений» по диаграмме C4 L3 на Python,
в стиле ООП и с паттерном «Стратегия».

Две реализации одних и тех же четырёх компонентов с одинаковым интерфейсом:

| | `message_broker.rabbitmq` — **основная** | `message_broker` — модель в памяти |
|---|---|---|
| Где хранятся сообщения | сервер RabbitMQ (на диске) | память одного процесса |
| Части системы в разных процессах | работают вместе | нет |
| Переживает перезапуск | да (durable + persistent) | нет |
| Нужно | `pip install pika` + `docker compose up -d` | ничего |
| Для чего | продукт, защита на живом сервере | тесты, быстрая демонстрация |

## Структура

```
message_broker/
  core/                     общее ядро: Message, Delivery, протоколы, исключения,
                            абстрактные стратегии, базовая очередь в памяти
  connection_handler.py     ┐
  exchange_manager.py       │ модель в памяти (четыре компонента)
  queue_labeling.py         │
  queue_cases.py            ┘
  assembly.py               сборка модели и права клиентов по диаграмме
  rabbitmq/                 слой над настоящим RabbitMQ:
    contracts.py              общие контракты слоя, базовая очередь на сервере, JSON-кодирование
    connection_handler.py     Обработчик AMQP-соединений  (связи 1, 2, 5, 7, 10 → 3, 6, 8, 11)
    exchange_manager.py       Маршрутизатор сообщений      (связи 3, 8 → 4, 9)
    queue_labeling.py         Очередь reviews.labeling     (связи 4, 6)
    queue_cases.py            Очередь cases.events         (связи 9, 11)
    assembly.py               build_rabbit_broker()

docker-compose.yml          сервер RabbitMQ с веб-панелью
labeling_worker.py          воркер разметки — отдельный процесс
background_worker.py        воркер фоновых задач — отдельный процесс
rabbit_cli.py               setup / stats / publish / dlq / reset
show_rabbit.py              пошаговая демонстрация на живом сервере (для защиты)
show_broker.py, demo.py     демонстрация модели в памяти
process_reviews.py          прогон CSV через модель в памяти
tests/                      76 тестов; tests/fake_pika.py — имитация сервера для тестов
```

Компоненты не импортируют друг друга (это проверяют тесты): каждый зависит только
от общих контрактов. Связывают их `assembly.py` и `rabbitmq/assembly.py`.

## Как устроен слой над RabbitMQ

Сообщения хранит и доставляет сервер. Компоненты управляют им:

* **Маршрутизатор** объявляет обмены `feedback.direct` и `feedback.topic`
  и привязки; для каждого сообщения выбирает обмен и ключ.
* **Очереди** объявляют на сервере `reviews.labeling` и `cases.events`:
  durable, приоритетные (`x-max-priority`), с лимитом и поведением при
  переполнении (`x-overflow`) и dead letter очередью `<имя>.dlq`.
  Перед отправкой проверяют сообщение и вычисляют его приоритет.
* **Обработчик соединений** подключает контейнеры через `pika`,
  проверяет права, публикует с подтверждением сервера (publisher confirms,
  `mandatory`), подтверждает доставку по стратегии, переподключается при обрыве.

Надёжность:
* сообщения persistent в durable-очередях — переживают перезапуск сервера;
* ack только после обработки — если воркер упал, сервер вернёт задачу в очередь;
* ошибка обработки → до 3 попыток (заголовок `x-attempts`), затем `<очередь>.dlq`;
* обрыв соединения → переподключение по стратегии и восстановление подписок.

## Паттерн «Стратегия» в слое над RabbitMQ

| Компонент | Стратегия | Реализации | Смена на лету |
|---|---|---|---|
| Обработчик соединений | `CredentialsProvider` | `StaticCredentials`, `PerClientCredentials`, `EnvironmentCredentials` | да |
| | `ReconnectStrategy` | `NoRetry`, `FixedDelayRetry`, `ExponentialBackoff` | да |
| | `AccessPolicy` | `PermitAllPolicy`, `PermissionTablePolicy` (по диаграмме) | да |
| | `AcknowledgementStrategy` | `AckAfterProcessing`, `AutoAck`, `ManualAck` | да |
| Маршрутизатор | `RabbitRoutingStrategy` | `DirectRouting` (по умолч.), `TopicRouting` | да |
| | `RabbitUnroutablePolicy` | `RaiseOnUnroutable`, `DiscardUnroutable` | да |
| Обе очереди | `DeliveryOrderStrategy` | `FifoOrder`, `PriorityOrder(PriorityPolicy)` | да |
| | `OverflowStrategy` | `RejectPublishOverflow`, `DropHeadOverflow` | при объявлении очереди |
| reviews.labeling | `ValidationStrategy` | `StrictLabelingTaskValidation`, `LenientLabelingTaskValidation` | да |
| | `PriorityPolicy` | `NegativeReviewsFirstPolicy`, `SourcePriorityPolicy` | да |
| cases.events | `ValidationStrategy` | `CaseEventValidation(allowed_event_types)` | да |
| | `PriorityPolicy` | `CriticalCasesFirstPolicy`, `NearestSlaFirstPolicy` | да |

Предметные стратегии (валидация, приоритеты) общие для обеих реализаций.
Переполнение — аргумент очереди на сервере: RabbitMQ не даёт изменить его
у существующей очереди, поэтому оно задаётся при объявлении.

## Запуск на настоящем RabbitMQ (Windows)

Нужны Python 3.10+ и [Docker Desktop](https://www.docker.com/products/docker-desktop/).

```
cd /d D:\verisit3
pip install -r requirements.txt
docker compose up -d
python rabbit_cli.py setup
```

Панель RabbitMQ: http://localhost:15672, логин `feedback`, пароль `feedback`.

### Части системы в отдельных процессах

Откройте три окна командной строки в `D:\verisit3`:

```
окно 1:  python labeling_worker.py --slow 2
окно 2:  python background_worker.py
окно 3:  python rabbit_cli.py publish
```

В окне 1 задачи размечаются, начиная с негативных; в окне 2 заводятся
обращения. В панели (вкладка Queues) видно, как сообщения проходят через очереди.

Проверки надёжности:
* закройте окно 1 посреди работы (Ctrl+C) — неподтверждённая задача
  вернётся в очередь, перезапустите воркер — он её доделает;
* `python labeling_worker.py --fail` — каждая задача 3 раза падает
  и уходит в dead letter; посмотреть: `python rabbit_cli.py dlq`;
* `python rabbit_cli.py publish`, затем `docker compose restart rabbitmq`,
  затем `python rabbit_cli.py stats` — сообщения на месте.

### Пошаговая демонстрация для защиты

```
python show_rabbit.py
```

## Подключение в своих частях системы

```python
from message_broker.rabbitmq import build_rabbit_broker

broker = build_rabbit_broker()     # адрес и пароль из RABBITMQ_HOST / RABBITMQ_USER / RABBITMQ_PASSWORD
broker.setup()                     # при старте сервиса, безопасно повторять

# Backend API (FastAPI): публикация задачи
api = broker.connect("api_backend").channel()
api.basic_publish("reviews.labeling",
                  {"review_id": "r-1", "text": "Списали комиссию", "rating": 1, "source": "api_batch"})

# воркер: подписка
worker = broker.connect("labeling_worker").channel()
worker.basic_consume("reviews.labeling", lambda ch, d: print(d.body))
worker.start_consuming()           # блокирует, как обычный воркер
```

`pika.BlockingConnection` не потокобезопасен: одно соединение — один поток.
В FastAPI удобно держать отдельное соединение на процесс и публиковать
из синхронных обработчиков.

**Про Celery.** Воркеры здесь — обычные процессы на нашем слое. Celery
отправляет сообщения в собственном формате задач, поэтому смешивать в одной
очереди сообщения Celery и нашего слоя нельзя. Celery beat можно использовать
для запуска периодического сбора отзывов, который публикует задачи через этот слой.

## Модель в памяти

```
python show_broker.py         # пошаговая демонстрация без сервера
python demo.py
python process_reviews.py [мои_отзывы.csv] [--fifo]
```

## Тесты

```
python -m pytest -q
```

Тесты слоя над RabbitMQ работают на имитации сервера (`tests/fake_pika.py`)
и не требуют Docker. Поведение на живом сервере проверяется сценарием выше.
